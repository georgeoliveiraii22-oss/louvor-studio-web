-- Louvor Studio para o REAPER — internet pelo curl (já vem no Windows 10+ e no Mac). Nada de bibliotecas de fora.
--  * pedido(): curto (JSON), espera a resposta.
--  * baixar(): arquivo grande, em segundo plano; a tela pergunta depois se terminou (pronto()).
local json = require("louvor.json")
local M = {}

local WIN = reaper.GetOS():find("Win") ~= nil
M.WIN = WIN
local SEP = WIN and "\\" or "/"

function M.pasta(...)
  local p = reaper.GetResourcePath() .. SEP .. "LouvorStudio"
  for _, x in ipairs({ ... }) do p = p .. SEP .. x end
  reaper.RecursiveCreateDirectory(p, 0)
  return p
end

local function q(s) -- aspas para a linha de comando
  if WIN then return '"' .. tostring(s):gsub('"', '\\"') .. '"' end
  return "'" .. tostring(s):gsub("'", "'\\''") .. "'"
end

local CURL = WIN and (os.getenv("SystemRoot") or "C:\\Windows") .. "\\System32\\curl.exe" or "/usr/bin/curl"

local seq = 0
local function tmp(ext)
  seq = seq + 1
  return M.pasta("tmp") .. SEP .. string.format("p%d_%d.%s", os.time(), seq, ext)
end

local function ler(path)
  local f = io.open(path, "rb")
  if not f then return nil end
  local s = f:read("*a")
  f:close()
  return s
end
M.ler = ler

local function escrever(path, s)
  local f = assert(io.open(path, "wb"))
  f:write(s)
  f:close()
end
M.escrever = escrever

--- Pedido curto. opts: { method, headers = {k=v}, body = tabela/texto, timeout = s }. Devolve status, corpo (já lido como JSON se der).
function M.pedido(url, opts)
  opts = opts or {}
  local out, inp = tmp("json"), nil
  local args = { q(CURL), "-sS", "-X", opts.method or "GET", "-o", q(out), "-w", q("%{http_code}"), "--max-time", tostring(opts.timeout or 25) }
  for k, v in pairs(opts.headers or {}) do args[#args + 1] = "-H"; args[#args + 1] = q(k .. ": " .. v) end
  if opts.body ~= nil then
    inp = tmp("txt")
    escrever(inp, type(opts.body) == "string" and opts.body or json.encode(opts.body))
    args[#args + 1] = "--data-binary"; args[#args + 1] = q("@" .. inp)
  end
  args[#args + 1] = q(url)
  local r = reaper.ExecProcess(table.concat(args, " "), ((opts.timeout or 25) + 5) * 1000) or ""
  local code = tonumber(r:match("\n%s*(%d%d%d)%s*$") or r:match("^%d+\n(%d+)")) or 0
  local corpo = ler(out) or ""
  os.remove(out)
  if inp then os.remove(inp) end
  if code == 0 then return 0, nil, "Sem internet ou o servidor não respondeu." end
  local data = nil
  if corpo ~= "" then data = json.decode(corpo) end
  return code, data, corpo
end

-- Versão do curl (o do Windows 10 antigo não conhece algumas opções). Pergunta uma vez só.
local versao
local function curlVersao()
  if versao == nil then
    local r = reaper.ExecProcess(q(CURL) .. " -V", 10000) or ""
    local a, b = r:match("curl (%d+)%.(%d+)")
    versao = a and (tonumber(a) * 100 + tonumber(b)) or 0
  end
  return versao
end

--- Baixa em segundo plano para `destino` (grava num .part e só renomeia quando termina inteiro).
--- Se der errado, o curl escreve o motivo em `destino.erro` (a tela mostra). Desiste se a conexão não abrir em 30 s
--- ou se ficar 60 s parada (antes ficava "baixando" para sempre).
function M.baixar(url, destino)
  local part = destino .. ".part"
  local erro = destino .. ".erro"
  local log = destino .. ".log"
  os.remove(part); os.remove(erro); os.remove(log)
  local args = { q(CURL), "-sSfL", "--retry", "2", "--connect-timeout", "30", "--speed-limit", "1000", "--speed-time", "60",
    "--max-time", "3600" }
  -- Windows: em algumas redes a conferência de certificado revogado trava ou falha; "best effort" segue mesmo assim.
  if WIN and curlVersao() >= 770 then args[#args + 1] = "--ssl-revoke-best-effort" end
  args[#args + 1] = "-o"; args[#args + 1] = q(part); args[#args + 1] = q(url)
  local curl = table.concat(args, " ")
  local cmd
  if WIN then
    cmd = 'cmd.exe /S /C "' .. curl .. " 2>" .. q(log) .. ' && move /Y ' .. q(part) .. " " .. q(destino) .. ' >NUL || (type ' .. q(log) ..
      ' > ' .. q(erro) .. ' & echo falhou>> ' .. q(erro) .. ')"'
  else
    -- Mac/Linux: o próprio shell manda para o segundo plano (nohup … &) e volta na hora. O ExecProcess "sem esperar" (-1)
    -- do REAPER no Mac não iniciava o curl: o download ficava em "Baixando 0 de N" sem erro.
    local tarefa = curl .. " 2>" .. q(log) .. " && mv -f " .. q(part) .. " " .. q(destino) .. " || { cat " .. q(log) ..
      " > " .. q(erro) .. "; echo falhou >> " .. q(erro) .. "; }"
    cmd = "/bin/sh -c " .. q("nohup /bin/sh -c " .. q(tarefa) .. " >/dev/null 2>&1 &")
    reaper.ExecProcess(cmd, 10000)
    return
  end
  reaper.ExecProcess(cmd, -1)
end

--- Baixa um lote de arquivos AGORA (primeiro plano), vários ao mesmo tempo, numa chamada só do curl, sem shell no meio:
--- os links e os destinos vão num arquivo de configuração (-K), então nada de aspas dentro de aspas (era isso que o
--- REAPER do Mac não rodava). itens = { {url=, destino=}, ... } → { [destino] = true | "motivo do erro" }.
function M.baixarAgora(itens)
  local cfg = tmp("cfg")
  local function aspas(s) return '"' .. tostring(s):gsub("\\", "\\\\"):gsub('"', '\\"') .. '"' end
  local linhas = { "silent", "show-error", "location", "fail", "retry = 2", "connect-timeout = 30",
    "speed-limit = 1000", "speed-time = 60", "max-time = 3600", 'write-out = "\\n@@%{http_code} %{filename_effective}\\n"' }
  for _, it in ipairs(itens) do
    os.remove(it.destino .. ".part")
    linhas[#linhas + 1] = "url = " .. aspas(it.url)
    linhas[#linhas + 1] = "output = " .. aspas(it.destino .. ".part")
  end
  escrever(cfg, table.concat(linhas, "\n") .. "\n")
  local par = (curlVersao() >= 766 and #itens > 1) and " --parallel --parallel-max 6" or ""
  local r = reaper.ExecProcess(q(CURL) .. par .. " -K " .. q(cfg), 900000) or ""
  os.remove(cfg)
  local codigos = {}
  for code, arq in r:gmatch("@@(%d+) ([^\r\n]+)") do codigos[arq] = code end
  local motivoGeral = r:match("curl: %(%d+%)[^\r\n]*")
  local out = {}
  for _, it in ipairs(itens) do
    local part = it.destino .. ".part"
    local code = codigos[part]
    if (code == "200" or code == "206") and M.tamanho(part) > 0 then
      os.remove(it.destino)
      if os.rename(part, it.destino) then out[it.destino] = true else out[it.destino] = "não consegui gravar o arquivo" end
    else
      os.remove(part)
      out[it.destino] = code and code ~= "000" and ("o servidor respondeu " .. code) or (motivoGeral or "o download não começou")
    end
  end
  return out
end

--- "ok" (terminou), "erro" ou nil (ainda baixando). No erro, devolve também o motivo que o curl deu.
function M.pronto(destino)
  if reaper.file_exists(destino) then os.remove(destino .. ".log") return "ok" end
  if reaper.file_exists(destino .. ".erro") then
    local t = (ler(destino .. ".erro") or ""):gsub("falhou%s*$", ""):gsub("^%s+", ""):gsub("%s+$", "")
    os.remove(destino .. ".erro"); os.remove(destino .. ".log"); os.remove(destino .. ".part")
    return "erro", t ~= "" and t or nil
  end
  return nil
end

--- A pasta deixa gravar? (sem isso o download nunca começa nem dá erro)
function M.gravavel(pasta)
  local p = pasta .. SEP .. "teste_gravar.tmp"
  local f = io.open(p, "wb")
  if not f then return false end
  f:write("ok"); f:close(); os.remove(p)
  return true
end

--- Quanto já baixou (bytes), para a barra de progresso.
function M.tamanho(path)
  local f = io.open(path, "rb")
  if not f then f = io.open(path .. ".part", "rb") end
  if not f then return 0 end
  local n = f:seek("end")
  f:close()
  return n or 0
end

return M
