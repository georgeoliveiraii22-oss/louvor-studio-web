-- Louvor Studio para o REAPER — internet pelo curl (já vem no Windows 10+ e no Mac). Nada de bibliotecas de fora.
--  * pedido(): curto (JSON), espera a resposta.
--  * baixar(): arquivo grande, em segundo plano; a tela pergunta depois se terminou (pronto()).
local json = require("louvor.json")
local M = {}

local WIN = reaper.GetOS():find("Win") ~= nil
M.WIN = WIN
local SEP = WIN and "\\" or "/"

function M.pasta(...)
  local p = reaper.GetResourcePath() .. SEP .. "LouvorStudio"
  for _, x in ipairs({ ... }) do p = p .. SEP .. x end
  reaper.RecursiveCreateDirectory(p, 0)
  return p
end

local function q(s) -- aspas para a linha de comando
  if WIN then return '"' .. tostring(s):gsub('"', '\\"') .. '"' end
  return "'" .. tostring(s):gsub("'", "'\\''") .. "'"
end

local CURL = WIN and (os.getenv("SystemRoot") or "C:\\Windows") .. "\\System32\\curl.exe" or "/usr/bin/curl"

local seq = 0
local function tmp(ext)
  seq = seq + 1
  return M.pasta("tmp") .. SEP .. string.format("p%d_%d.%s", os.time(), seq, ext)
end

local function ler(path)
  local f = io.open(path, "rb")
  if not f then return nil end
  local s = f:read("*a")
  f:close()
  return s
end
M.ler = ler

local function escrever(path, s)
  local f = assert(io.open(path, "wb"))
  f:write(s)
  f:close()
end
M.escrever = escrever

--- Pedido curto. opts: { method, headers = {k=v}, body = tabela/texto, timeout = s }. Devolve status, corpo (já lido como JSON se der).
function M.pedido(url, opts)
  opts = opts or {}
  local out, inp = tmp("json"), nil
  local args = { q(CURL), "-sS", "-X", opts.method or "GET", "-o", q(out), "-w", q("%{http_code}"), "--max-time", tostring(opts.timeout or 25) }
  for k, v in pairs(opts.headers or {}) do args[#args + 1] = "-H"; args[#args + 1] = q(k .. ": " .. v) end
  if opts.body ~= nil then
    inp = tmp("txt")
    escrever(inp, type(opts.body) == "string" and opts.body or json.encode(opts.body))
    args[#args + 1] = "--data-binary"; args[#args + 1] = q("@" .. inp)
  end
  args[#args + 1] = q(url)
  local r = reaper.ExecProcess(table.concat(args, " "), ((opts.timeout or 25) + 5) * 1000) or ""
  local code = tonumber(r:match("\n%s*(%d%d%d)%s*$") or r:match("^%d+\n(%d+)")) or 0
  local corpo = ler(out) or ""
  os.remove(out)
  if inp then os.remove(inp) end
  if code == 0 then return 0, nil, "Sem internet ou o servidor não respondeu." end
  local data = nil
  if corpo ~= "" then data = json.decode(corpo) end
  return code, data, corpo
end

--- Baixa em segundo plano para `destino` (grava num .part e só renomeia quando termina inteiro).
function M.baixar(url, destino)
  local part = destino .. ".part"
  local erro = destino .. ".erro"
  os.remove(part); os.remove(erro)
  local curl = table.concat({ q(CURL), "-sSfL", "--retry", "2", "--max-time", "1800", "-o", q(part), q(url) }, " ")
  local cmd
  if WIN then
    cmd = 'cmd.exe /S /C "' .. curl .. ' && move /Y ' .. q(part) .. " " .. q(destino) .. ' >NUL || echo falhou > ' .. q(erro) .. '"'
  else
    cmd = "/bin/sh -c " .. q(curl .. " && mv -f " .. q(part) .. " " .. q(destino) .. " || echo falhou > " .. q(erro))
  end
  reaper.ExecProcess(cmd, -1)
end

--- "ok" (terminou), "erro" ou nil (ainda baixando).
function M.pronto(destino)
  if reaper.file_exists(destino) then return "ok" end
  if reaper.file_exists(destino .. ".erro") then return "erro" end
  return nil
end

--- Quanto já baixou (bytes), para a barra de progresso.
function M.tamanho(path)
  local f = io.open(path, "rb")
  if not f then f = io.open(path .. ".part", "rb") end
  if not f then return 0 end
  local n = f:seek("end")
  f:close()
  return n or 0
end

return M
