-- Louvor Studio para o REAPER — monta a escala no projeto:
--  * cada música é uma faixa-pasta vazia ("1. Ele Aqui Está") com as faixas da multitrack dentro;
--  * as músicas ficam uma depois da outra, com um espaço entre elas (padrão 12 s);
--  * as Partes viram regiões coloridas (as mesmas cores do app); o começo e o fim de cada música são marcadores;
--  * o áudio fica preso ao tempo do relógio (não estica quando o andamento do projeto muda);
--  * a régua segue cada batida do click (grade pelo click, como no app); sem click, usa o BPM da ficha;
--  * os ajustes publicados no estúdio do app (volume, atraso, aparar, entrada/saída suave) são aplicados.
local grade = require("louvor.grade")
local M = {}

M.ESPACO = 12
M.INICIO = "♪ "   -- marcador do começo da música
M.FIM = "■ fim"   -- marcador do fim da música (o modo ao vivo para aqui)

local function cor(hex)
  local r, g, b = hex:match("#?(%x%x)(%x%x)(%x%x)")
  return reaper.ColorToNative(tonumber(r, 16), tonumber(g, 16), tonumber(b, 16)) | 0x1000000
end
M.cor = cor

local function norm(s)
  s = tostring(s or ""):lower()
  local acentos = { ["á"] = "a", ["à"] = "a", ["â"] = "a", ["ã"] = "a", ["é"] = "e", ["ê"] = "e", ["í"] = "i", ["ó"] = "o", ["ô"] = "o", ["õ"] = "o", ["ú"] = "u", ["ç"] = "c" }
  return (s:gsub("[\195][\128-\191]", function(c) return acentos[c] or c end))
end
M.norm = norm

-- Cores das partes: as mesmas de web/sections.js (colorFor).
local CORES_PARTES = {
  { { "intro", "abertura", "entrada" }, "#7DBAE4" },
  { { "pre" }, "#DCC65F" },
  { { "refr", "coro", "chorus" }, "#FF6B73" },
  { { "vers", "estrofe", "verse" }, "#6CC4B0" },
  { { "ponte", "bridge" }, "#C59DE3" },
  { { "solo", "instrument", "interl", "virada" }, "#E9A863" },
  { { "final", "outro", "fim", "tag", "encerr" }, "#9BA7EC" },
}
function M.corDaParte(nome)
  local n = norm(nome)
  for _, c in ipairs(CORES_PARTES) do
    for _, k in ipairs(c[1]) do if n:find(k, 1, true) then return c[2] end end
  end
  return "#A0A0A0"
end

-- Tipo da faixa pelo nome (para a cor e, depois, para as saídas da placa).
local TIPOS = {
  { "click", { "click", "clique", "metron", "met " } },
  { "guia", { "guia", "guide", "cue", "contagem", "count" } },
  { "bateria", { "bateria", "drum", "bat ", "kick", "bumbo", "snare", "caixa", "tom", "prato", "overhead", "loop" } },
  { "percussao", { "perc", "shaker", "pandeiro", "conga" } },
  { "baixo", { "baixo", "bass", "bx" } },
  { "teclas", { "tecl", "key", "piano", "pad", "synth", "sint", "organ", "orgao", "rhodes", "string", "cordas" } },
  { "guitarras", { "guit", "gtr", "violao", "acoustic", "ag ", "eg " } },
  { "vozes", { "voz", "vox", "vocal", "back", "bv", "coro", "choir" } },
}
local CORES_TIPOS = { click = "#FF7A70", guia = "#FFB547", bateria = "#E9A863", percussao = "#DCC65F", baixo = "#6CC4B0",
  teclas = "#9BA7EC", guitarras = "#E384AE", vozes = "#7DBAE4", outros = "#8FA9BF" }
M.CORES_TIPOS = CORES_TIPOS
M.TIPOS_ORDEM = { "click", "guia", "bateria", "percussao", "baixo", "teclas", "guitarras", "vozes", "outros" }
M.NOMES_TIPOS = { click = "Click", guia = "Guia", bateria = "Bateria", percussao = "Percussão", baixo = "Baixo",
  teclas = "Teclados", guitarras = "Guitarras e violão", vozes = "Vozes", outros = "Outras faixas" }

function M.tipoDaFaixa(nome)
  local n = " " .. norm(nome) .. " "
  for _, t in ipairs(TIPOS) do
    for _, k in ipairs(t[2]) do if n:find(k, 1, true) then return t[1] end end
  end
  return "outros"
end

--- As partes da música, como no app: cada marcador vai até o próximo (ou até o fim marcado), sem passar do fim da música.
function M.partes(lista, fimMusica)
  local p = {}
  for _, x in ipairs(lista or {}) do p[#p + 1] = x end
  table.sort(p, function(a, b) return a.ini < b.ini end)
  local out = {}
  for i, x in ipairs(p) do
    local prox = p[i + 1] and p[i + 1].ini or fimMusica
    local fim = math.min(x.fim or prox, fimMusica)
    if fim > x.ini + 0.05 then out[#out + 1] = { nome = x.nome, ini = x.ini, fim = fim } end
  end
  return out
end

local function projetoVazio()
  return reaper.CountTracks(0) == 0 and reaper.CountMediaItems(0) == 0
end

--- Monta a escala. escala = { titulo, dia, id, musicas = { {projeto, tom}, ... } }; dados = M.musicas() da nuvem;
--- arquivo(faixa) = caminho local já baixado (ou nil). Devolve um resumo { musicas, faixas, faltando = {títulos} }.
function M.montar(escala, dados, arquivo, opts)
  opts = opts or {}
  local espaco = opts.espaco or M.ESPACO
  reaper.PreventUIRefresh(1)
  reaper.Undo_BeginBlock()
  if not projetoVazio() then reaper.Main_OnCommand(40859, 0) end   -- nova aba de projeto
  reaper.SetProjExtState(0, "LouvorStudio", "escala", escala.id or "")
  reaper.SetProjExtState(0, "LouvorStudio", "titulo", (escala.titulo or "") .. " · " .. (escala.dia or ""))
  local t = 0
  local regiao = 0
  local resumo = { musicas = 0, faixas = 0, faltando = {} }
  local n = 0
  for _, em in ipairs(escala.musicas) do
    local m = dados[em.projeto]
    if not m or #m.faixas == 0 then
      resumo.faltando[#resumo.faltando + 1] = (m and m.titulo or "Música") .. " (sem multitrack)"
    else
      n = n + 1
      local tom = em.tom or m.tom
      local nome = string.format("%d. %s%s", n, m.titulo, tom and ("  [" .. tom .. "]") or "")
      -- pasta da música
      local idx = reaper.CountTracks(0)
      reaper.InsertTrackAtIndex(idx, true)
      local pasta = reaper.GetTrack(0, idx)
      reaper.GetSetMediaTrackInfo_String(pasta, "P_NAME", nome, true)
      reaper.SetMediaTrackInfo_Value(pasta, "I_FOLDERDEPTH", 1)
      reaper.SetMediaTrackInfo_Value(pasta, "I_CUSTOMCOLOR", cor("#08A9F5"))
      local fimMusica = m.duracao or 0
      local criadas = 0
      local clickTake = nil
      for k, f in ipairs(m.faixas) do
        local caminho = arquivo(f)
        local ti = reaper.CountTracks(0)
        reaper.InsertTrackAtIndex(ti, true)
        local tr = reaper.GetTrack(0, ti)
        reaper.GetSetMediaTrackInfo_String(tr, "P_NAME", f.nome, true)
        local tipo = M.tipoDaFaixa(f.nome)
        reaper.GetSetMediaTrackInfo_String(tr, "P_EXT:louvor_tipo", tipo, true)
        reaper.SetMediaTrackInfo_Value(tr, "I_CUSTOMCOLOR", cor(CORES_TIPOS[tipo]))
        reaper.SetMediaTrackInfo_Value(tr, "I_FOLDERDEPTH", k == #m.faixas and -1 or 0)
        if caminho then
          local src = reaper.PCM_Source_CreateFromFile(caminho)
          local len = src and reaper.GetMediaSourceLength(src) or 0
          if src and len > 0 then
            local item = reaper.AddMediaItemToTrack(tr)
            local take = reaper.AddTakeToMediaItem(item)
            reaper.SetMediaItemTake_Source(take, src)
            local e = f.edicao
            local ini = e and e.ini or 0
            local fim = (e and e.fim and math.min(e.fim, len)) or len
            if fim <= ini then ini, fim = 0, len end
            reaper.SetMediaItemTakeInfo_Value(take, "D_STARTOFFS", ini)
            reaper.SetMediaItemTakeInfo_Value(take, "D_PLAYRATE", 1)
            reaper.SetMediaItemInfo_Value(item, "C_BEATATTACHMODE", 0)   -- tempo do relógio, não batidas
            pcall(reaper.SetMediaItemInfo_Value, item, "C_AUTOSTRETCH", 0)
            reaper.SetMediaItemInfo_Value(item, "D_POSITION", math.max(0, t + f.atraso + ini))
            reaper.SetMediaItemInfo_Value(item, "D_LENGTH", fim - ini)
            local vol = (f.ganho or 1) * 10 ^ ((e and e.db or 0) / 20)
            reaper.SetMediaItemInfo_Value(item, "D_VOL", vol)
            if e and e.fadeIn > 0 then reaper.SetMediaItemInfo_Value(item, "D_FADEINLEN", e.fadeIn) end
            if e and e.fadeOut > 0 then reaper.SetMediaItemInfo_Value(item, "D_FADEOUTLEN", e.fadeOut) end
            reaper.GetSetMediaItemTakeInfo_String(take, "P_NAME", f.nome, true)
            fimMusica = math.max(fimMusica, f.atraso + fim)
            criadas = criadas + 1
            if not clickTake and (tipo == "click" or grade.ehClick(f.nome)) then clickTake = { take = take, item = item, len = fim - ini } end
          end
        end
      end
      if criadas == 0 then resumo.faltando[#resumo.faltando + 1] = m.titulo .. " (áudio não baixou)" end
      reaper.SetMediaTrackInfo_Value(pasta, "I_FOLDERCOMPACT", 2)   -- pasta fechada: a tela fica limpa
      -- régua: segue o click; sem click (ou click que não deu para ler), o BPM da ficha
      local porClick = 0
      if clickTake and opts.gradePeloClick ~= false then
        local g = grade.detectar(clickTake.take, clickTake.len)
        if #g.beats >= 8 then
          local pos0 = reaper.GetMediaItemInfo_Value(clickTake.item, "D_POSITION")
          local proj = {}
          for i, b in ipairs(g.beats) do proj[i] = pos0 + b end
          porClick = grade.mapaDeAndamento(proj, g.downbeats, g.beatsPerBar, m.compasso)
          resumo.peloClick = (resumo.peloClick or 0) + 1
        end
      end
      if porClick == 0 and m.bpm and m.bpm > 0 then
        local num, den = (m.compasso or "4/4"):match("(%d+)/(%d+)")
        -- como na régua pelo click: primeiro o andamento no lugar exato, depois o compasso (sem puxar para o
        -- começo do compasso anterior, que deixaria o compasso errado no começo da música)
        reaper.SetTempoTimeSigMarker(0, -1, t, -1, -1, m.bpm, 0, 0, false)
        local idx = reaper.FindTempoTimeSigMarker(0, t + 1e-6)
        if idx >= 0 then
          if reaper.GetSetTempoTimeSigMarkerFlag then reaper.GetSetTempoTimeSigMarkerFlag(0, idx, 4, true) end
          reaper.SetTempoTimeSigMarker(0, idx, t, -1, -1, m.bpm, tonumber(num) or 4, tonumber(den) or 4, false)
        end
      end
      -- começo, partes e fim
      reaper.AddProjectMarker2(0, false, t, 0, M.INICIO .. nome, -1, cor("#08A9F5"))
      local partes = M.partes(m.partes, fimMusica)
      if #partes == 0 then partes = { { nome = "Música inteira", ini = 0, fim = fimMusica } } end
      for _, p in ipairs(partes) do
        regiao = regiao + 1
        reaper.AddProjectMarker2(0, true, t + p.ini, t + p.fim, p.nome, regiao, cor(M.corDaParte(p.nome)))
      end
      reaper.AddProjectMarker2(0, false, t + fimMusica, 0, M.FIM, -1, cor("#FF7A70"))
      -- para enviar as partes corrigidas de volta ao app (louvor/partes.lua); "aqui" é gravado depois de reler o projeto
      local partesMod = require("louvor.partes")
      partesMod.guardar(n, { projeto = m.id, titulo = m.titulo, dur = (m.duracao or 0) > 0 and m.duracao or nil,
        nuvem = partesMod.assinaturaNuvem(m.partes or {}),
        -- tom da multitrack (o tom original da ficha) e o tom do dia (o da escala; senão o da banda): LS Live › Tom
        tomMultitrack = m.tomOriginal or m.tom, tomDia = em.tom or m.tom })
      resumo.musicas = resumo.musicas + 1
      resumo.faixas = resumo.faixas + criadas
      t = t + fimMusica + espaco
    end
  end
  reaper.SetEditCurPos(0, true, false)
  -- como as regiões ficaram aqui (base para saber depois se alguém corrigiu as partes no REAPER)
  local av, partesMod = require("louvor.aovivo"), require("louvor.partes")
  for k, mm in ipairs(av.ler()) do partesMod.marcarAqui(k, mm) end
  -- saídas de áudio configuradas neste computador (Configurações › Saídas de áudio)
  local sd = require("louvor.saidas")
  local cfg = sd.carregar()
  if sd.configurado(cfg) then resumo.saidas = sd.aplicar(cfg) end
  -- contagem antes de cada música (Configurações › Ao vivo e celular)
  local okC, cont = pcall(require, "louvor.contagem")
  if okC and cont.ligada() then resumo.contagem = cont.aplicar(av.ler) end
  reaper.Undo_EndBlock("Louvor Studio: montar a escala", -1)
  reaper.PreventUIRefresh(-1)
  reaper.UpdateArrange()
  reaper.UpdateTimeline()
  return resumo
end

return M
