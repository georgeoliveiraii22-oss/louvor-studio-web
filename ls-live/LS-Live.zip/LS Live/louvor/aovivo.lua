-- Louvor Studio para o REAPER — o motor do modo ao vivo.
-- Regras (pedido do usuário):
--  * Pular para uma parte NUNCA é na hora: espera a parte atual terminar e só então vai (o próprio REAPER faz o pulo,
--    pela ação "ir para a região N depois que a região atual terminar (smooth seek)", sem corte no áudio).
--  * A escolha fica na fila (só uma); tocar de novo na parte da fila cancela.
--  * Repetir a parte: a parte atual volta ao começo dela quando termina, até desligar.
--  * No fim de cada música o REAPER para sozinho e o cursor vai para o começo da próxima.
--  * Parar é o único comando imediato.
local montar = require("louvor.montar")
local M = {}

local GOTO_REGIAO = 41761          -- 41761..41800 = região 01..40, depois que a atual terminar
local ANTECEDENCIA = 0.6           -- manda o pulo ao REAPER um pouco antes do fim da parte (ele mesmo espera o fim)

M.estado = { fila = nil, filaEnviada = false, repetir = false, musicas = {}, lidoEm = -1 }
local E = M.estado

--- Lê a estrutura do projeto: músicas (marcadores ♪ e ■ fim) e as partes (regiões) de cada uma.
function M.ler()
  local musicas, regioes = {}, {}
  local i = 0
  while true do
    local ok, isrgn, pos, fim, nome, num, cor = reaper.EnumProjectMarkers3(0, i)
    if ok == 0 then break end
    if isrgn then regioes[#regioes + 1] = { nome = nome, ini = pos, fim = fim, num = num, cor = cor, idx = i }
    elseif nome:sub(1, #montar.INICIO) == montar.INICIO then musicas[#musicas + 1] = { nome = nome:sub(#montar.INICIO + 1), ini = pos, partes = {} }
    elseif nome == montar.FIM and #musicas > 0 and not musicas[#musicas].fim then musicas[#musicas].fim = pos end
    i = i + 1
  end
  for k, m in ipairs(musicas) do
    m.fim = m.fim or (musicas[k + 1] and musicas[k + 1].ini) or reaper.GetProjectLength(0)
    for _, r in ipairs(regioes) do
      if r.ini >= m.ini - 0.001 and r.ini < m.fim then m.partes[#m.partes + 1] = r end
    end
    table.sort(m.partes, function(a, b) return a.ini < b.ini end)
  end
  E.musicas = musicas
  return musicas
end

function M.tocando() return reaper.GetPlayState() & 1 == 1 end
function M.posicao() return M.tocando() and reaper.GetPlayPosition2() or reaper.GetCursorPosition() end

--- Música e parte onde a posição está (no intervalo entre músicas, a música que vem depois).
function M.onde(pos)
  pos = pos or M.posicao()
  local mi
  for k, m in ipairs(E.musicas) do
    if pos >= m.ini - 0.001 and pos < m.fim then mi = k break end
    if pos < m.ini then mi = k break end
  end
  mi = mi or #E.musicas
  local m = E.musicas[mi]
  local pi
  if m then
    for k, p in ipairs(m.partes) do if pos >= p.ini - 0.001 and pos < p.fim then pi = k end end
  end
  return mi, pi, m, m and pi and m.partes[pi]
end

-- A ação nativa só tem as regiões 1 a 40: se o número for maior, troca de número com a 40 (só o número muda).
local function numeroUsavel(regiao)
  if regiao.num <= 40 then return regiao.num end
  local i = 0
  while true do
    local ok, isrgn, pos, fim, nome, num, cor = reaper.EnumProjectMarkers3(0, i)
    if ok == 0 then break end
    if isrgn and num == 40 then reaper.SetProjectMarkerByIndex2(0, i, true, pos, fim, 1000 + regiao.num, nome, cor, 0) break end
    i = i + 1
  end
  reaper.SetProjectMarkerByIndex2(0, regiao.idx, true, regiao.ini, regiao.fim, 40, regiao.nome, regiao.cor, 0)
  M.ler()
  return 40
end

local function enviarFila()
  local alvo = E.fila
  if not alvo then return end
  if E.repetir then E.repetir = false; reaper.GetSetRepeat(0) end
  local n = numeroUsavel(alvo)
  reaper.Main_OnCommand(GOTO_REGIAO + n - 1, 0)
  E.filaEnviada = true
end

--- Tocou num quadradinho (parte k da música atual, ou de outra música se `mi` vier).
function M.parte(k, mi)
  local cur_mi, cur_pi = M.onde()
  mi = mi or cur_mi
  local m = E.musicas[mi]
  local alvo = m and m.partes[k]
  if not alvo then return end
  if not M.tocando() then
    E.fila = nil
    reaper.SetEditCurPos(alvo.ini, true, false)
    return
  end
  if E.fila and E.fila.idx == alvo.idx then E.fila = nil; E.filaEnviada = false; return end   -- cancelar
  if E.filaEnviada then return end   -- o REAPER já está fazendo o pulo: espera
  E.fila = alvo
  E.filaEnviada = false
  -- sem parte tocando agora (no espaço antes da música, por exemplo): já manda, o REAPER vai no fim da região atual
  if not cur_pi then enviarFila() end
end

--- Repetir a parte atual (liga/desliga). Ligado: no fim da parte, volta ao começo dela.
function M.repetir()
  local _, pi, m, p = M.onde()
  if E.repetir then
    E.repetir = false
    reaper.GetSetRepeat(0)
    return
  end
  if not p then return end
  E.fila = nil; E.filaEnviada = false
  reaper.GetSet_LoopTimeRange2(0, true, true, p.ini, p.fim, false)
  reaper.GetSetRepeat(1)
  E.repetir = true
end

function M.tocarParar()
  if M.tocando() then M.parar() return end
  -- parado no espaço depois de uma música: começa da próxima
  local k = M.noIntervalo(reaper.GetCursorPosition())
  if k then
    if not E.musicas[k + 1] then return end
    reaper.SetEditCurPos(E.musicas[k + 1].ini, true, false)
  end
  reaper.OnPlayButton()
end

function M.parar()
  E.fila = nil; E.filaEnviada = false
  if E.repetir then E.repetir = false; reaper.GetSetRepeat(0) end
  local pos = reaper.GetPlayPosition2()
  reaper.OnStopButton()
  reaper.SetEditCurPos(pos, true, false)
end

--- Música anterior/próxima: parado, vai na hora; tocando, entra na fila (começa no fim da parte atual).
function M.musica(delta)
  local mi = M.onde()
  local alvo = E.musicas[mi + delta]
  if not alvo then return end
  if not M.tocando() then reaper.SetEditCurPos(alvo.ini, true, false) return end
  if alvo.partes[1] then M.parte(1, mi + delta) end
end

--- Voltar ao começo da parte atual (parado: na hora; tocando: no fim da parte, como qualquer pulo).
function M.comecoDaParte()
  local _, pi = M.onde()
  if pi then M.parte(pi) end
end

--- Chamado várias vezes por segundo pela tela: manda o pulo perto do fim da parte e para no fim da música.
function M.passo()
  if not M.tocando() then E.filaEnviada = false; return end
  local pos = reaper.GetPlayPosition2()
  local mi, pi, m, p = M.onde(pos)
  if E.fila and not E.filaEnviada and p and pos >= p.fim - ANTECEDENCIA then enviarFila() end
  if E.filaEnviada and E.fila and pos >= E.fila.ini - 0.01 and pos < E.fila.fim then E.fila = nil; E.filaEnviada = false end
  if E.repetir or E.fila then return end
  local k = M.noIntervalo(pos)
  if k then
    reaper.OnStopButton()
    local prox = E.musicas[k + 1]
    reaper.SetEditCurPos(prox and prox.ini or E.musicas[k].fim, true, false)
  end
end

--- Se a posição está no espaço depois do fim da música k (antes da próxima começar), devolve k.
function M.noIntervalo(pos)
  for k, s in ipairs(E.musicas) do
    local prox = E.musicas[k + 1]
    if pos >= s.fim - 0.001 and (not prox or pos < prox.ini - 0.001) then return k end
  end
  return nil
end

return M
