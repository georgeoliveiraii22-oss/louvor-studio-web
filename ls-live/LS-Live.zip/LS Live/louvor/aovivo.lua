-- Louvor Studio para o REAPER — o motor do modo ao vivo.
-- Regras (pedido do usuário):
--  * Pular para uma parte NUNCA é na hora: espera a parte atual terminar e só então vai (o próprio REAPER faz o pulo,
--    pela ação "ir para a região N depois que a região atual terminar (smooth seek)", sem corte no áudio).
--  * A escolha fica na fila (só uma); tocar de novo na parte da fila cancela.
--  * Repetir a parte: a parte atual volta ao começo dela quando termina, até desligar.
--  * No fim de cada música o REAPER para sozinho e o cursor vai para o começo da próxima.
--  * Parar é o único comando imediato.
--  * Final: no fim da parte atual vai para a parte final da música (Final, Outro…); sem parte final, para ali.
--  * Parar suave: abaixa o volume aos poucos e para (e o cursor vai para a próxima música).
--  * Ordem das partes (louvor/ordem.lua): tocando, no fim de cada parte a próxima da ordem entra na fila sozinha.
local montar = require("louvor.montar")
local ordem = require("louvor.ordem")
local M = {}

local GOTO_REGIAO = 41761          -- 41761..41800 = região 01..40, depois que a atual terminar
local ANTECEDENCIA = 0.6           -- manda o pulo ao REAPER um pouco antes do fim da parte (ele mesmo espera o fim)

M.estado = { fila = nil, filaEnviada = false, repetir = false, musicas = {}, lidoEm = -1,
  final = false, filaFinal = false, pararEm = nil, suave = nil, passoOrdem = nil, ordemEnviada = nil, mi = nil, ultPi = nil, ultPos = 0 }
local E = M.estado

--- Lê a estrutura do projeto: músicas (marcadores ♪ e ■ fim) e as partes (regiões) de cada uma.
function M.ler()
  local musicas, regioes = {}, {}
  local i = 0
  while true do
    local ok, isrgn, pos, fim, nome, num, cor = reaper.EnumProjectMarkers3(0, i)
    if ok == 0 then break end
    if isrgn then regioes[#regioes + 1] = { nome = nome, ini = pos, fim = fim, num = num, cor = cor, idx = i }
    elseif nome:sub(1, #montar.INICIO) == montar.INICIO then musicas[#musicas + 1] = { nome = nome:sub(#montar.INICIO + 1), ini = pos, partes = {} }
    elseif nome == montar.FIM and #musicas > 0 and not musicas[#musicas].fim then musicas[#musicas].fim = pos end
    i = i + 1
  end
  for k, m in ipairs(musicas) do
    m.fim = m.fim or (musicas[k + 1] and musicas[k + 1].ini) or reaper.GetProjectLength(0)
    for _, r in ipairs(regioes) do
      if r.ini >= m.ini - 0.001 and r.ini < m.fim then m.partes[#m.partes + 1] = r end
    end
    table.sort(m.partes, function(a, b) return a.ini < b.ini end)
  end
  E.musicas = musicas
  return musicas
end

function M.tocando() return reaper.GetPlayState() & 1 == 1 end
function M.posicao() return M.tocando() and reaper.GetPlayPosition2() or reaper.GetCursorPosition() end

--- Música e parte onde a posição está (no intervalo entre músicas, a música que vem depois).
function M.onde(pos)
  pos = pos or M.posicao()
  local mi
  for k, m in ipairs(E.musicas) do
    if pos >= m.ini - 0.001 and pos < m.fim then mi = k break end
    if pos < m.ini then mi = k break end
  end
  mi = mi or #E.musicas
  local m = E.musicas[mi]
  local pi
  if m then
    for k, p in ipairs(m.partes) do if pos >= p.ini - 0.001 and pos < p.fim then pi = k end end
  end
  return mi, pi, m, m and pi and m.partes[pi]
end

-- A ação nativa só tem as regiões 1 a 40: se o número for maior, troca de número com a 40 (só o número muda).
local function numeroUsavel(regiao)
  if regiao.num <= 40 then return regiao.num end
  local i = 0
  while true do
    local ok, isrgn, pos, fim, nome, num, cor = reaper.EnumProjectMarkers3(0, i)
    if ok == 0 then break end
    if isrgn and num == 40 then reaper.SetProjectMarkerByIndex2(0, i, true, pos, fim, 1000 + regiao.num, nome, cor, 0) break end
    i = i + 1
  end
  reaper.SetProjectMarkerByIndex2(0, regiao.idx, true, regiao.ini, regiao.fim, 40, regiao.nome, regiao.cor, 0)
  M.ler()
  return 40
end

local function enviarFila()
  local alvo = E.fila
  if not alvo then return end
  if E.repetir then E.repetir = false; reaper.GetSetRepeat(0) end
  local n = numeroUsavel(alvo)
  reaper.Main_OnCommand(GOTO_REGIAO + n - 1, 0)
  E.filaEnviada = true
end

--- Tocou num quadradinho (parte k da música atual, ou de outra música se `mi` vier).
function M.parte(k, mi)
  local cur_mi, cur_pi = M.onde()
  mi = mi or cur_mi
  local m = E.musicas[mi]
  local alvo = m and m.partes[k]
  if not alvo then return end
  if not M.tocando() then
    E.fila = nil
    reaper.SetEditCurPos(alvo.ini, true, false)
    return
  end
  if E.fila and E.fila.idx == alvo.idx then E.fila = nil; E.filaEnviada = false; return end   -- cancelar
  if E.filaEnviada then return end   -- o REAPER já está fazendo o pulo: espera
  E.fila = alvo
  E.filaEnviada = false
  -- sem parte tocando agora (no espaço antes da música, por exemplo): já manda, o REAPER vai no fim da região atual
  if not cur_pi then enviarFila() end
end

--- Repetir a parte atual (liga/desliga). Ligado: no fim da parte, volta ao começo dela.
function M.repetir()
  local _, pi, m, p = M.onde()
  if E.repetir then
    E.repetir = false
    reaper.GetSetRepeat(0)
    return
  end
  if not p then return end
  E.fila = nil; E.filaEnviada = false
  reaper.GetSet_LoopTimeRange2(0, true, true, p.ini, p.fim, false)
  reaper.GetSetRepeat(1)
  E.repetir = true
end

function M.tocarParar()
  if M.tocando() then M.parar() return end
  -- parado no espaço depois de uma música: começa da próxima
  local k = M.noIntervalo(reaper.GetCursorPosition())
  if k then
    if not E.musicas[k + 1] then return end
    reaper.SetEditCurPos(E.musicas[k + 1].ini, true, false)
  end
  reaper.OnPlayButton()
end

--- Parar suave: as faixas que descem. Não é o master: as faixas podem sair direto pela placa (louvor/saidas.lua,
--- "tirar do master"), e essas saídas vêm depois do volume da faixa. Por isso desce o volume de cada faixa montada
--- pelo LS Live (menos o pad) e cada uma volta ao seu volume no fim.
local function faixasDoSuave()
  local out = {}
  for i = 0, reaper.CountTracks(0) - 1 do
    local tr = reaper.GetTrack(0, i)
    local _, tipo = reaper.GetSetMediaTrackInfo_String(tr, "P_EXT:louvor_tipo", "", false)
    local _, ehPad = reaper.GetSetMediaTrackInfo_String(tr, "P_EXT:louvor_pad", "", false)
    if tipo ~= "" and ehPad ~= "1" then out[#out + 1] = { tr = tr, vol0 = reaper.GetMediaTrackInfo_Value(tr, "D_VOL") } end
  end
  return out
end

local function volumeDoSuave(fator)
  for _, f in ipairs(E.suave.faixas) do
    if reaper.ValidatePtr2(0, f.tr, "MediaTrack*") then reaper.SetMediaTrackInfo_Value(f.tr, "D_VOL", f.vol0 * fator) end
  end
end

local function volumeDeVolta()
  if E.suave then
    volumeDoSuave(1)
    E.suave = nil
  end
end

function M.parar()
  E.fila = nil; E.filaEnviada = false
  E.final, E.filaFinal, E.pararEm = false, false, nil
  volumeDeVolta()
  if E.repetir then E.repetir = false; reaper.GetSetRepeat(0) end
  local pos = reaper.GetPlayPosition2()
  reaper.OnStopButton()
  reaper.SetEditCurPos(pos, true, false)
end

--- Música anterior/próxima: parado, vai na hora; tocando, entra na fila (começa no fim da parte atual).
function M.musica(delta)
  local mi = M.onde()
  local alvo = E.musicas[mi + delta]
  if not alvo then return end
  if not M.tocando() then reaper.SetEditCurPos(alvo.ini, true, false) return end
  if alvo.partes[1] then M.parte(1, mi + delta) end
end

--- Voltar ao começo da parte atual (parado: na hora; tocando: no fim da parte, como qualquer pulo).
function M.comecoDaParte()
  local _, pi = M.onde()
  if pi then M.parte(pi) end
end

local FINAL = { "final", "outro", "fim", "encerr", "tag", "finaliz" }
--- A parte final da música (a última com nome de final), ou nil.
function M.parteFinal(m)
  local achou
  for k, p in ipairs(m and m.partes or {}) do
    local n = montar.norm(p.nome)
    for _, f in ipairs(FINAL) do if n:find(f, 1, true) then achou = k end end
  end
  return achou
end

--- Para (com o cursor na próxima música) assim que a posição passar de "fim".
local function pararNaPosicao(mi, fimMusica)
  E.pararEm = nil; E.final = false; E.filaFinal = false
  reaper.OnStopButton()
  local prox = E.musicas[mi + 1]
  reaper.SetEditCurPos(prox and prox.ini or fimMusica, true, false)
end

--- Final (liga/desliga). Tocando: no fim da parte atual vai para a parte final; sem parte final, para ali.
--- Parado: o cursor vai para o começo da parte final.
function M.final()
  if E.final then
    if E.filaFinal and E.fila and not E.filaEnviada then E.fila = nil end
    E.final, E.filaFinal, E.pararEm = false, false, nil
    return
  end
  local _, pi, m, p = M.onde()
  if not m then return end
  local k = M.parteFinal(m)
  if not M.tocando() then
    if k then reaper.SetEditCurPos(m.partes[k].ini, true, false) end
    return
  end
  if k and pi == k then return end   -- já está no final
  if E.repetir then E.repetir = false; reaper.GetSetRepeat(0) end
  E.final = true
  if k and (not pi or k > pi) then
    E.fila = m.partes[k]; E.filaEnviada = false; E.filaFinal = true
    if not pi then enviarFila() end
  else
    E.pararEm = p and p.fim or m.fim
  end
end

--- Parar suave: o volume desce aos poucos (em "dur" segundos) e o REAPER para.
function M.pararSuave(dur)
  if not M.tocando() or E.suave then return end
  E.suave = { t0 = reaper.time_precise(), dur = dur or 3, faixas = faixasDoSuave() }
end

--- As partes da ordem da música mi (índices em m.partes), ou lista vazia.
function M.sequencia(mi)
  local m = E.musicas[mi]
  if not m then return {} end
  return ordem.resolver(m, ordem.nomes(mi))
end

--- O passo atual na ordem (para a tela mostrar), ou nil.
function M.passoDaOrdem() return E.passoOrdem end

--- Chamado várias vezes por segundo pela tela: manda o pulo perto do fim da parte e para no fim da música.
function M.passo()
  -- parar suave: desce o volume; no fim, para e devolve o volume
  if E.suave then
    local f = (reaper.time_precise() - E.suave.t0) / E.suave.dur
    if f >= 1 or not M.tocando() then
      local mi = M.onde(reaper.GetPlayPosition2())
      local fimM = E.musicas[mi] and E.musicas[mi].fim or 0
      M.parar()   -- para e devolve o volume de cada faixa
      local prox = E.musicas[mi + 1]
      reaper.SetEditCurPos(prox and prox.ini or fimM, true, false)
      return
    end
    volumeDoSuave((1 - f) ^ 2)
  end
  if not M.tocando() then E.filaEnviada = false; E.ultPi = nil; return end
  local pos = reaper.GetPlayPosition2()
  local mi, pi, m, p = M.onde(pos)
  -- trocou de música: final e ordem recomeçam
  if mi ~= E.mi then
    E.mi = mi; E.passoOrdem = nil; E.ordemEnviada = nil
    if not E.filaFinal then E.final = false; E.pararEm = nil end
  end
  -- começou uma parte (outra, ou a mesma de novo): acompanha a ordem
  if pi and (pi ~= E.ultPi or pos < E.ultPos - 0.05) then
    local seq = M.sequencia(mi)
    if #seq > 0 then E.passoOrdem = ordem.acompanhar(seq, E.passoOrdem, pi) end
    E.ordemEnviada = nil
    if E.filaFinal and E.final and pi == M.parteFinal(m) then E.final, E.filaFinal = false, false end
  end
  E.ultPi, E.ultPos = pi, pos
  -- para no fim da parte (Final sem parte final, ou fim da ordem)
  if E.pararEm and pos >= E.pararEm - 0.02 then pararNaPosicao(mi, m and m.fim or pos) return end
  -- ordem: a próxima parte entra na fila sozinha perto do fim desta
  if ordem.ligada() and p and not E.fila and not E.repetir and not E.final and E.passoOrdem and E.ordemEnviada ~= E.passoOrdem then
    local seq = M.sequencia(mi)
    if seq[E.passoOrdem] == pi and pos >= p.fim - ANTECEDENCIA then
      local prox = seq[E.passoOrdem + 1]
      E.ordemEnviada = E.passoOrdem
      if prox then E.fila = m.partes[prox]; E.filaEnviada = false; enviarFila()
      elseif pi < #m.partes then E.pararEm = p.fim end   -- acabou a ordem antes do fim da música: para aqui
    end
  end
  if E.fila and not E.filaEnviada and p and pos >= p.fim - ANTECEDENCIA then enviarFila() end
  if E.filaEnviada and E.fila and pos >= E.fila.ini - 0.01 and pos < E.fila.fim then E.fila = nil; E.filaEnviada = false end
  if E.repetir or E.fila then return end
  local k = M.noIntervalo(pos)
  if k then
    reaper.OnStopButton()
    local prox = E.musicas[k + 1]
    reaper.SetEditCurPos(prox and prox.ini or E.musicas[k].fim, true, false)
  end
end

--- Se a posição está no espaço depois do fim da música k (antes da próxima começar), devolve k.
function M.noIntervalo(pos)
  for k, s in ipairs(E.musicas) do
    local prox = E.musicas[k + 1]
    if pos >= s.fim - 0.001 and (not prox or pos < prox.ini - 0.001) then return k end
  end
  return nil
end

return M
