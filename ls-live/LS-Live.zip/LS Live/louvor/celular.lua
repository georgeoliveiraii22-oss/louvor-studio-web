-- LS Live — a página do controle pelo celular (louvor/remoto.lua põe na pasta reaper_www_root como lslive.html).
-- Lê o estado do ao vivo pelo controle pelo navegador do REAPER e manda os comandos. Sem bibliotecas de fora.
return [==[<!doctype html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover, user-scalable=no">
<meta name="theme-color" content="#050B12">
<meta name="apple-mobile-web-app-capable" content="yes">
<title>LS Live</title>
<style>
:root { --bg:#050B12; --panel:#0A263A; --control:#123650; --sel:#0B3350; --line:#1B3A52; --text:#DCE8F2; --hi:#F5FAFF;
  --muted:#8FA9BF; --accent:#08A9F5; --on:#050B12; --ok:#34D399; --warn:#FFB547; --bad:#FF7A70; }
* { box-sizing:border-box; -webkit-tap-highlight-color:transparent; }
html,body { margin:0; background:var(--bg); color:var(--text); font:16px/1.3 system-ui,-apple-system,"Segoe UI",Roboto,sans-serif; }
body { padding:12px 14px calc(170px + env(safe-area-inset-bottom)); -webkit-user-select:none; user-select:none; touch-action:manipulation; }
button { font:inherit; color:inherit; border:0; cursor:pointer; }
.top { display:flex; align-items:center; gap:8px; color:var(--muted); font-size:13px; }
.dot { width:8px; height:8px; border-radius:50%; background:var(--bad); }
.dot.on { background:var(--ok); }
.n { color:var(--muted); font-size:13px; margin-top:12px; }
h1 { margin:2px 0 0; font-size:26px; line-height:1.15; color:var(--hi); letter-spacing:-.01em; }
.depois { color:var(--muted); font-size:13px; margin-top:4px; }
.ajustes { display:flex; gap:8px; margin-top:12px; flex-wrap:wrap; }
.aj { display:flex; align-items:center; background:var(--panel); border-radius:14px; height:44px; }
.aj button { width:44px; height:44px; font-size:22px; color:var(--accent); background:none; }
.aj span { min-width:74px; text-align:center; font-weight:700; color:var(--hi); font-size:15px; }
.aj span small { display:block; font-weight:500; color:var(--muted); font-size:11px; }
.dia { background:var(--control); color:var(--warn); border-radius:14px; padding:0 14px; height:44px; font-weight:600; font-size:14px; }
.card { background:var(--panel); border-radius:18px; padding:14px; margin-top:12px; }
.parte { display:flex; justify-content:space-between; align-items:baseline; gap:8px; }
.parte b { font-size:22px; color:var(--hi); }
.parte span { color:var(--muted); font-size:14px; }
.barra { height:6px; background:var(--control); border-radius:3px; margin-top:10px; overflow:hidden; }
.barra i { display:block; height:100%; width:0; background:var(--accent); border-radius:3px; }
.status { margin-top:8px; font-size:14px; font-weight:600; min-height:18px; }
.ordem { display:flex; gap:6px; overflow-x:auto; margin-top:10px; padding-bottom:2px; }
.ordem span { flex:none; font-size:12px; padding:5px 9px; border-radius:10px; background:var(--control); color:var(--muted); }
.ordem span.on { background:var(--accent); color:var(--on); font-weight:700; }
.partes { display:grid; grid-template-columns:1fr 1fr; gap:10px; margin-top:12px; }
.partes button { position:relative; min-height:72px; border-radius:18px; font-weight:700; font-size:17px; color:var(--hi);
  padding:10px; overflow:hidden; text-align:center; }
.partes button i { position:absolute; left:0; top:0; bottom:0; width:0; opacity:.55; }
.partes button em { position:relative; font-style:normal; }
.partes button.fila { outline:3px solid var(--hi); animation:pisca 1s steps(2) infinite; }
@keyframes pisca { 50% { outline-color:transparent; } }
.transporte { position:fixed; left:0; right:0; bottom:0; background:rgba(5,11,18,.94); border-top:1px solid var(--line);
  padding:10px 12px calc(10px + env(safe-area-inset-bottom)); -webkit-backdrop-filter:blur(14px); backdrop-filter:blur(14px); }
.linha { display:grid; grid-template-columns:repeat(5,1fr); gap:8px; align-items:center; }
.linha + .linha { margin-top:8px; grid-template-columns:repeat(4,1fr); }
.b { height:56px; border-radius:16px; background:var(--control); font-size:12px; font-weight:600; display:flex; flex-direction:column;
  align-items:center; justify-content:center; gap:2px; color:var(--text); }
.b svg { width:22px; height:22px; fill:currentColor; }
.b.on { background:var(--accent); color:var(--on); }
.tocar { height:68px; border-radius:22px; background:var(--accent); color:var(--on); }
.tocar svg { width:30px; height:30px; }
.b:active, .partes button:active, .aj button:active, .dia:active { transform:scale(.97); }
.vazio { color:var(--muted); text-align:center; margin-top:40px; font-size:15px; }
</style>
</head>
<body>
<div class="top"><span class="dot" id="dot"></span><span id="con">Conectando…</span><span style="margin-left:auto">LS Live</span></div>
<div id="tudo">
  <div class="n" id="n"></div>
  <h1 id="titulo">—</h1>
  <div class="depois" id="depois"></div>
  <div class="ajustes">
    <div class="aj"><button data-c="tom-" aria-label="Descer meio tom">−</button><span id="tom">Tom<small>—</small></span><button data-c="tom+" aria-label="Subir meio tom">+</button></div>
    <div class="aj"><button data-c="bpm-" aria-label="Mais devagar">−</button><span id="bpm">BPM<small>—</small></span><button data-c="bpm+" aria-label="Mais rápido">+</button></div>
    <button class="dia" id="dia" data-c="tomdia" hidden></button>
  </div>
  <div class="card">
    <div class="parte"><b id="parte">—</b><span id="faltam"></span></div>
    <div class="barra"><i id="prog"></i></div>
    <div class="status" id="status"></div>
    <div class="ordem" id="ordem"></div>
  </div>
  <div class="partes" id="partes"></div>
</div>
<div class="vazio" id="vazio" hidden>Abra o ao vivo do LS Live no computador.</div>
<div class="transporte">
  <div class="linha">
    <button class="b" data-c="musica-"><svg viewBox="0 0 24 24"><path d="M6 5h2v14H6zM20 5v14L9 12z"/></svg>Música</button>
    <button class="b" data-c="inicio"><svg viewBox="0 0 24 24"><path d="M5 5h2v14H5zM19 5v14L8 12z"/></svg>Começo</button>
    <button class="b tocar" data-c="tocar" id="tocar"><svg viewBox="0 0 24 24"><path id="ic" d="M7 4l13 8-13 8z"/></svg></button>
    <button class="b" data-c="repetir" id="rep"><svg viewBox="0 0 24 24"><path d="M17 3l4 4-4 4V8H7a3 3 0 00-3 3v1H2v-1a5 5 0 015-5h10zM7 21l-4-4 4-4v3h10a3 3 0 003-3v-1h2v1a5 5 0 01-5 5H7z"/></svg>Repetir</button>
    <button class="b" data-c="musica+"><svg viewBox="0 0 24 24"><path d="M16 5h2v14h-2zM4 5v14l11-7z"/></svg>Música</button>
  </div>
  <div class="linha">
    <button class="b" data-c="final" id="fin"><svg viewBox="0 0 24 24"><path d="M5 3h2v18H5zM9 4h10l-3 4 3 4H9z"/></svg>Final</button>
    <button class="b" data-c="suave" id="sua"><svg viewBox="0 0 24 24"><path d="M3 14h3v6H3zM8 11h3v9H8zM13 15h3v5h-3zM18 18h3v2h-3z"/></svg>Parar suave</button>
    <button class="b" data-c="pad" id="pad"><svg viewBox="0 0 24 24"><path d="M2 12c2-5 4-5 6 0s4 5 6 0 4-5 6 0l2 0v2h-1c-2 4-4 4-6 0s-4-5-6 0-4 5-6 0z"/></svg>Pad</button>
    <button class="b" data-c="ordem" id="ord"><svg viewBox="0 0 24 24"><path d="M4 5h3v3H4zM9 5h11v3H9zM4 10.5h3v3H4zM9 10.5h11v3H9zM4 16h3v3H4zM9 16h11v3H9z"/></svg>Ordem</button>
  </div>
</div>
<script>
(function () {
  var seq = Date.now() % 100000, ultimoT = null, mudouEm = 0, est = null;
  var $ = function (id) { return document.getElementById(id); };
  function mandar(c) {
    seq++;
    fetch('/_/SET/EXTSTATE/LouvorStudio/remoto_cmd/' + encodeURIComponent(seq + '_' + c), { cache: 'no-store' }).catch(function () {});
    if (navigator.vibrate) navigator.vibrate(12);
    setTimeout(ler, 120);
  }
  document.addEventListener('click', function (e) {
    var b = e.target.closest('[data-c]');
    if (b) mandar(b.getAttribute('data-c'));
  });
  function arr(x) { return Array.isArray(x) ? x : []; }
  function tempo(s) { s = Math.max(0, Math.round(s || 0)); return Math.floor(s / 60) + ':' + ('0' + s % 60).slice(-2); }
  function mostrar(e) {
    est = e;
    var ao = e && e.aovivo;
    $('tudo').hidden = !ao; $('vazio').hidden = !!ao;
    if (!ao) return;
    $('n').textContent = 'Música ' + e.mi + ' de ' + e.total;
    $('titulo').textContent = e.titulo || '—';
    $('depois').textContent = e.depois ? 'Depois: ' + e.depois : '';
    $('tom').innerHTML = 'Tom ' + (e.tom || '—') + '<small>' + (e.semi ? (e.semi > 0 ? '+' : '') + e.semi + ' meio tom' : 'original') + '</small>';
    $('bpm').innerHTML = (e.bpm ? e.bpm : '—') + ' BPM<small>' + (e.taxa && e.taxa !== 100 ? e.taxa + '%' : 'original') + '</small>';
    var dia = $('dia');
    dia.hidden = !e.tomDia; if (e.tomDia) dia.textContent = 'Tom do dia: ' + e.tomDia;
    $('parte').textContent = e.parte || (e.tocando ? '—' : 'Parado');
    $('faltam').textContent = e.parte ? 'faltam ' + tempo(e.faltam) : '';
    $('prog').style.width = Math.round((e.prog || 0) * 100) + '%';
    var st = $('status');
    st.textContent = e.status || ''; st.style.color = e.statusCor || 'var(--muted)';
    var o = $('ordem'); o.innerHTML = '';
    arr(e.ordem).forEach(function (nome, i) {
      var s = document.createElement('span'); s.textContent = (i + 1) + ' ' + nome;
      if (e.passo === i + 1) s.className = 'on';
      o.appendChild(s);
    });
    var g = $('partes'); g.innerHTML = '';
    arr(e.partes).forEach(function (p, i) {
      var b = document.createElement('button');
      b.setAttribute('data-c', 'p' + (i + 1));
      var atual = e.pi === i + 1;
      b.style.background = atual ? p.c : 'color-mix(in srgb, ' + p.c + ' 22%, #0A263A)';
      if (atual) b.style.color = '#050B12';
      if (e.fila === i + 1) b.className = 'fila';
      var bar = document.createElement('i'); bar.style.background = '#fff'; bar.style.width = atual ? Math.round((e.prog || 0) * 100) + '%' : '0';
      bar.style.opacity = atual ? '.25' : '0';
      var t = document.createElement('em'); t.textContent = p.n;
      b.appendChild(bar); b.appendChild(t); g.appendChild(b);
    });
    $('ic').setAttribute('d', e.tocando ? 'M6 6h12v12H6z' : 'M7 4l13 8-13 8z');
    $('rep').classList.toggle('on', !!e.repetir);
    $('fin').classList.toggle('on', !!e.final);
    $('sua').classList.toggle('on', !!e.suave);
    $('pad').classList.toggle('on', !!e.pad);
    $('ord').classList.toggle('on', !!e.ordemLigada && arr(e.ordem).length > 0);
  }
  function ler() {
    fetch('/_/GET/EXTSTATE/LouvorStudio/remoto_estado', { cache: 'no-store' }).then(function (r) { return r.text(); }).then(function (t) {
      var p = t.split('\t'); var v = p.slice(3).join('\t').trim();
      var e = null; try { e = JSON.parse(v); } catch (x) {}
      if (e && e.t !== ultimoT) { ultimoT = e.t; mudouEm = Date.now(); }
      var vivo = e && Date.now() - mudouEm < 2500;
      $('dot').className = 'dot' + (vivo ? ' on' : '');
      $('con').textContent = vivo ? 'Conectado' : 'O LS Live não está aberto no ao vivo';
      mostrar(vivo ? e : null);
    }).catch(function () {
      $('dot').className = 'dot'; $('con').textContent = 'Sem conexão com o computador';
    });
  }
  setInterval(ler, 300);
  setInterval(function () { fetch('/_/SET/EXTSTATE/LouvorStudio/remoto_visto/' + Date.now(), { cache: 'no-store' }).catch(function () {}); }, 2000);
  ler();
})();
</script>
</body>
</html>
]==]
