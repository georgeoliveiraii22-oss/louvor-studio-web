-- LS Live — pad entre as músicas: um som de fundo contínuo no tom da música que vem, enquanto o REAPER está parado.
--  * Uma faixa "LS Pad" com o sintetizador do próprio REAPER (ReaSynth), equalizador e reverb, que toca ao vivo
--    (não é um item na linha do tempo): o LS Live manda as notas pelo teclado virtual do REAPER.
--  * Ligado (botão Pad ou tecla P): com o REAPER parado, soa o acorde do tom da música onde o cursor está
--    (o tom que vai soar, já com o ajuste de tom). Ao tocar a música, o pad some devagar.
--  * Quem quiser outro som troca o ReaSynth da faixa "LS Pad" por qualquer instrumento: o LS Live só manda as notas.
local M = {}

local EXT = "LouvorStudio"
local VKB = 0                  -- StuffMIDIMessage modo 0 = fila do teclado virtual
local soando = {}              -- notas ligadas agora
local tomSoando = nil
local prontaEm = 0             -- a faixa recém-criada/armada só ouve depois de um instante (o áudio aplica no próximo ciclo)

function M.ligado() return reaper.GetExtState(EXT, "pad") == "1" end
function M.alternar()
  local on = not M.ligado()
  reaper.SetExtState(EXT, "pad", on and "1" or "0", true)
  if not on then M.silenciar() end
  return on
end

local function ehPad(tr)
  local _, v = reaper.GetSetMediaTrackInfo_String(tr, "P_EXT:louvor_pad", "", false)
  return v == "1"
end

function M.faixa()
  for i = 0, reaper.CountTracks(0) - 1 do
    local tr = reaper.GetTrack(0, i)
    if ehPad(tr) then return tr end
  end
end

--- Põe o parâmetro "nome" do efeito no valor mostrado "alvo" (ms, dB…), procurando o ponto certo da escala 0–1.
local function ajustar(tr, fx, nome, alvo)
  for p = 0, reaper.TrackFX_GetNumParams(tr, fx) - 1 do
    local _, n = reaper.TrackFX_GetParamName(tr, fx, p, "")
    if n == nome then
      local lo, hi = 0, 1
      local function valor(v)
        reaper.TrackFX_SetParamNormalized(tr, fx, p, v)
        local _, f = reaper.TrackFX_GetFormattedParamValue(tr, fx, p, "")
        if f:find("inf") then return f:find("%-") and -1e9 or 1e9 end
        return tonumber(f:match("[-%d%.]+")) or 0
      end
      for _ = 1, 24 do
        local mid = (lo + hi) / 2
        if valor(mid) < alvo then lo = mid else hi = mid end
      end
      reaper.TrackFX_SetParamNormalized(tr, fx, p, (lo + hi) / 2)
      return true
    end
  end
end

--- Cria a faixa do pad (uma vez por projeto), no fim, fora das pastas das músicas.
function M.garantirFaixa()
  local tr = M.faixa()
  if tr then return tr end
  reaper.PreventUIRefresh(1)
  local n = reaper.CountTracks(0)
  -- a última faixa pode estar fechando uma pasta: a nova fica depois, no nível de cima
  reaper.InsertTrackAtIndex(n, true)
  tr = reaper.GetTrack(0, n)
  reaper.GetSetMediaTrackInfo_String(tr, "P_NAME", "LS Pad", true)
  reaper.GetSetMediaTrackInfo_String(tr, "P_EXT:louvor_pad", "1", true)
  reaper.GetSetMediaTrackInfo_String(tr, "P_EXT:louvor_tipo", "teclas", true)
  reaper.SetMediaTrackInfo_Value(tr, "I_CUSTOMCOLOR", reaper.ColorToNative(155, 167, 236) | 0x1000000)
  reaper.SetMediaTrackInfo_Value(tr, "D_VOL", 10 ^ (-8 / 20))
  local s = reaper.TrackFX_AddByName(tr, "ReaSynth", false, -1)
  if s >= 0 then
    ajustar(tr, s, "Attack", 1800)
    ajustar(tr, s, "Release", 3000)
    ajustar(tr, s, "Decay", 4000)
    ajustar(tr, s, "Sustain", 0)
    ajustar(tr, s, "Saw mix", 0.18)
    ajustar(tr, s, "Triangle mix", 0.55)
    ajustar(tr, s, "Extra sine mix", 0.35)
    ajustar(tr, s, "Global detune", 8)
    ajustar(tr, s, "Volume", -12)
  end
  local eq = reaper.TrackFX_AddByName(tr, "ReaEQ", false, -1)
  if eq >= 0 then
    ajustar(tr, eq, "Freq-High Shelf 4", 2500)
    ajustar(tr, eq, "Gain-High Shelf 4", -12)
    ajustar(tr, eq, "Freq-Low Shelf", 120)
    ajustar(tr, eq, "Gain-Low Shelf", -6)
  end
  local rv = reaper.TrackFX_AddByName(tr, "ReaVerbate", false, -1)
  if rv >= 0 then
    ajustar(tr, rv, "Room size", 85)
    ajustar(tr, rv, "Wet", -4)
    ajustar(tr, rv, "Dry", -3)
  end
  -- ouve o teclado virtual (todos os canais), só monitorando: nunca grava nada
  reaper.SetMediaTrackInfo_Value(tr, "I_RECINPUT", 4096 + (62 << 5))
  reaper.SetMediaTrackInfo_Value(tr, "I_RECMODE", 2)
  reaper.SetMediaTrackInfo_Value(tr, "I_RECMON", 1)
  reaper.SetMediaTrackInfo_Value(tr, "I_RECARM", 1)
  prontaEm = reaper.time_precise() + 0.5
  -- saídas de áudio configuradas (o pad conta como teclado)
  local sd = require("louvor.saidas")
  local cfg = sd.carregar()
  if sd.configurado(cfg) then pcall(sd.aplicar, cfg) end
  reaper.PreventUIRefresh(-1)
  reaper.TrackList_AdjustWindows(false)
  return tr
end

--- Notas do acorde do tom (fundamental, quinta, oitava e quinta de cima: serve para maior e menor).
function M.notas(tom)
  local pc = require("louvor.tom").ler(tom)
  if not pc then return nil end
  local raiz = 48 + pc
  if raiz > 53 then raiz = raiz - 12 end   -- fica entre Lá 2 e Fá 3 (som cheio, sem embolar)
  return { raiz, raiz + 7, raiz + 12, raiz + 19 }
end

function M.silenciar()
  for n in pairs(soando) do reaper.StuffMIDIMessage(VKB, 0x80, n, 0) end
  soando = {}
  tomSoando = nil
end

--- Chamado sempre pela tela: "tom" = o tom que deve soar agora (nil = silêncio).
function M.sincronizar(tom)
  if tom == tomSoando then return end
  M.silenciar()
  local ns = tom and M.notas(tom)
  if not ns then return end
  local tr = M.garantirFaixa()
  if reaper.GetMediaTrackInfo_Value(tr, "I_RECARM") ~= 1 then
    reaper.SetMediaTrackInfo_Value(tr, "I_RECARM", 1)
    prontaEm = reaper.time_precise() + 0.5
  end
  if reaper.time_precise() < prontaEm then return end   -- tenta de novo no próximo quadro
  for _, n in ipairs(ns) do reaper.StuffMIDIMessage(VKB, 0x90, n, 84); soando[n] = true end
  tomSoando = tom
end

function M.tomSoando() return tomSoando end

return M
