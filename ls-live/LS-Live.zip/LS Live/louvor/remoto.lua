-- LS Live — controle pelo celular, pela rede da igreja.
--  * Usa o controle pelo navegador do próprio REAPER (Preferências › Control/OSC/web › Web browser interface):
--    o LS Live liga isso uma vez (escreve a linha no REAPER.ini; vale depois de fechar e abrir o REAPER) e põe a
--    página "lslive.html" na pasta do REAPER. Qualquer celular no mesmo Wi-Fi abre http://<ip do PC>:<porta>/lslive.html.
--  * A página lê o estado do ao vivo (ExtState "remoto_estado", escrito pelo LS Live 5 vezes por segundo) e manda os
--    comandos em "remoto_cmd" ("<número>_<comando>"). Só os comandos da lista abaixo valem.
--  * A janela do LS Live precisa estar aberta no ao vivo (é ela que executa).
local json = require("louvor.json")
local pagina = require("louvor.celular")
local M = {}

local EXT = "LouvorStudio"
M.PORTA = 8080
M.PERMITIDOS = { tocar = true, repetir = true, ["parte-"] = true, ["parte+"] = true, ["musica-"] = true, ["musica+"] = true,
  inicio = true, final = true, suave = true, pad = true, ["tom+"] = true, ["tom-"] = true, ["bpm+"] = true, ["bpm-"] = true,
  tomdia = true, ordem = true }

local function lerIni(caminho)
  local f = io.open(caminho or reaper.get_ini_file(), "r")
  if not f then return nil end
  local t = f:read("*a"); f:close()
  return t
end

--- Porta do controle pelo navegador, se já estiver ligado no REAPER.ini (ou nil).
function M.porta(caminho)
  local t = lerIni(caminho)
  if not t then return nil end
  for linha in t:gmatch("[^\r\n]+") do
    local porta = linha:match("^csurf_%d+=HTTP%s+%d+%s+(%d+)")
    if porta then return tonumber(porta) end
  end
end

--- Liga o controle pelo navegador no REAPER.ini (vale depois de fechar e abrir o REAPER). Devolve porta ou nil, erro.
function M.ligar(porta, caminho)
  porta = porta or M.PORTA
  caminho = caminho or reaper.get_ini_file()
  local ja = M.porta(caminho)
  if ja then return ja end
  local t = lerIni(caminho)
  if not t then return nil, "Não deu para abrir o arquivo de configuração do REAPER." end
  local nl = t:find("\r\n") and "\r\n" or "\n"
  local n = tonumber(t:match("\ncsurf_cnt=(%d+)")) or 0
  local linha = "csurf_" .. n .. "=HTTP 0 " .. porta .. " '' 'lslive.html' 0 ''"
  if t:find("\ncsurf_cnt=%d+") then
    t = t:gsub("(\ncsurf_cnt=)%d+", "%1" .. (n + 1), 1)
    t = t:gsub("(\ncsurf_cnt=%d+)", "%1" .. nl .. linha, 1)
  elseif t:find("%[reaper%]") then
    t = t:gsub("%[reaper%]", "[reaper]" .. nl .. "csurf_cnt=1" .. nl .. linha, 1)
  else
    return nil, "O arquivo de configuração do REAPER não tem a parte [reaper]."
  end
  -- cópia de segurança antes de mexer
  local b = io.open(caminho .. ".antes-lslive", "r")
  if b then b:close() else
    local c = io.open(caminho .. ".antes-lslive", "w"); if c then c:write(lerIni(caminho)); c:close() end
  end
  local f = io.open(caminho, "w")
  if not f then return nil, "Não deu para gravar o arquivo de configuração do REAPER." end
  f:write(t); f:close()
  return porta
end

--- Põe (ou atualiza) a página do celular na pasta do REAPER.
function M.instalarPagina()
  local dir = reaper.GetResourcePath() .. "/reaper_www_root"
  reaper.RecursiveCreateDirectory(dir, 0)
  local f = io.open(dir .. "/lslive.html", "w")
  if not f then return false end
  f:write(pagina)
  f:close()
  return true
end

local ipCache, ipEm = nil, -100
--- Endereço deste computador na rede (o do Wi-Fi/cabo; prefere 192.168…, 10…, 172.16–31…).
function M.ip()
  local agora = reaper.time_precise()
  if ipCache and agora - ipEm < 30 then return ipCache end
  ipEm = agora
  local lista = {}
  if reaper.GetOS():find("Win") and io.popen then
    local p = io.popen("ipconfig")
    if p then
      local t = p:read("*a") or ""; p:close()
      for ip in t:gmatch("IPv4[^:]*:%s*([%d%.]+)") do lista[#lista + 1] = ip end
    end
  elseif io.popen then
    local p = io.popen("ifconfig 2>/dev/null || ip addr")
    if p then
      local t = p:read("*a") or ""; p:close()
      for ip in t:gmatch("inet%s+([%d%.]+)") do if ip ~= "127.0.0.1" then lista[#lista + 1] = ip end end
    end
  end
  local function nota(ip)
    if ip:find("^192%.168%.") then return 3 end
    if ip:find("^10%.") then return 2 end
    if ip:find("^172%.") then return 1 end
    return 0
  end
  table.sort(lista, function(a, b) return nota(a) > nota(b) end)
  ipCache = lista[1]
  return ipCache
end

--- Endereço para abrir no celular (ou nil se o controle não está ligado).
function M.endereco()
  local porta = M.porta()
  local ip = M.ip()
  if not porta or not ip then return nil end
  return "http://" .. ip .. (porta == 80 and "" or (":" .. porta)) .. "/lslive.html"
end

local ultimoCmd = nil
local publicadoEm = -1
--- Escreve o estado do ao vivo para o celular (no máximo 5 vezes por segundo).
function M.publicar(estado)
  local agora = reaper.time_precise()
  if agora - publicadoEm < 0.2 then return end
  publicadoEm = agora
  estado.t = math.floor(agora * 10)
  reaper.SetExtState(EXT, "remoto_estado", json.encode(estado), false)
end

--- O comando novo que chegou do celular (ou nil). Na primeira leitura só guarda o que já estava (comando velho).
function M.comando()
  local v = reaper.GetExtState(EXT, "remoto_cmd")
  if ultimoCmd == nil then ultimoCmd = v; return nil end
  if v == "" or v == ultimoCmd then return nil end
  ultimoCmd = v
  local cmd = v:match("^%d+_(.+)$")
  if not cmd then return nil end
  if M.PERMITIDOS[cmd] or cmd:match("^p%d+$") then return cmd end
end

--- O celular avisa que está olhando (a página grava "remoto_visto" a cada 2 s). true = visto nos últimos 5 s.
local vistoValor, vistoEm = nil, -100
function M.celularConectado()
  local v = reaper.GetExtState(EXT, "remoto_visto")
  local agora = reaper.time_precise()
  if v ~= "" and v ~= vistoValor then vistoValor, vistoEm = v, agora end
  return agora - vistoEm < 5
end

return M
