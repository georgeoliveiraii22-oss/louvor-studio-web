-- Louvor Studio para o REAPER — conta, escalas, músicas e links de download (as mesmas consultas do site e dos apps).
-- Só usa a chave PÚBLICA do Supabase; quem decide o que cada um vê são as regras do banco (RLS).
local http = require("louvor.http")
local json = require("louvor.json")
local M = {}

M.URL = "https://mryuqpnkdkmmhmqrjixy.supabase.co"
M.KEY = "sb_publishable_kQ5b8gJER45UjhptOIYcpg_Z-dMsI-7"
local EXT = "LouvorStudio"

local sessao = { access = nil, ate = 0, refresh = nil, user = nil, email = nil }

local function salvar()
  reaper.SetExtState(EXT, "refresh", sessao.refresh or "", true)
  reaper.SetExtState(EXT, "user", sessao.user or "", true)
  reaper.SetExtState(EXT, "email", sessao.email or "", true)
end

--- Sessão guardada neste computador (fica até a pessoa sair da conta).
function M.carregar()
  sessao.refresh = reaper.GetExtState(EXT, "refresh")
  sessao.user = reaper.GetExtState(EXT, "user")
  sessao.email = reaper.GetExtState(EXT, "email")
  if sessao.refresh == "" then sessao.refresh = nil; sessao.user = nil end
  if sessao.user == "" then sessao.user = nil end
  return sessao.refresh ~= nil
end

function M.email() return sessao.email end
function M.userId() return sessao.user end

local function guardar(d)
  sessao.access = json.get(d, "access_token")
  sessao.refresh = json.get(d, "refresh_token")
  sessao.ate = os.time() + (tonumber(json.get(d, "expires_in")) or 3600) - 60
  local u = json.get(d, "user")
  if u then sessao.user = json.get(u, "id"); sessao.email = json.get(u, "email") or sessao.email end
  salvar()
end

local function msgErro(d, corpo)
  local m = (d and (json.get(d, "error_description") or json.get(d, "msg") or json.get(d, "message") or json.get(d, "error"))) or corpo or ""
  m = tostring(m)
  if m:find("Invalid login credentials") then return "E-mail ou senha errados." end
  if m:find("Email not confirmed") then return "Confirme seu e-mail antes de entrar." end
  if m:find("rate limit") then return "Muitas tentativas. Espere alguns minutos e tente de novo." end
  if m:find("row%-level security") or m:find("permission denied") then return "Você não tem permissão para isso." end
  return m ~= "" and m or "Não deu certo. Tente de novo."
end

local function post(caminho, body, token_)
  local h = { apikey = M.KEY, ["Content-Type"] = "application/json" }
  if token_ then h.Authorization = "Bearer " .. token_ end
  return http.pedido(M.URL .. caminho, { method = "POST", headers = h, body = body })
end

--- Entrar com e-mail e senha (a mesma conta do app e do site).
function M.entrar(email, senha)
  local code, d, corpo = post("/auth/v1/token?grant_type=password", { email = email, password = senha })
  if code ~= 200 then return false, code == 0 and corpo or msgErro(d, corpo) end
  guardar(d)
  return true
end

local function renovar()
  if not sessao.refresh then return false, "Entre na sua conta." end
  local code, d, corpo = http.pedido(M.URL .. "/auth/v1/token?grant_type=refresh_token", {
    method = "POST", headers = { apikey = M.KEY, ["Content-Type"] = "application/json" }, body = { refresh_token = sessao.refresh } })
  if code == 0 then return false, corpo end
  if code ~= 200 then
    sessao.refresh = nil; salvar()
    return false, "A conexão expirou. Entre de novo."
  end
  guardar(d)
  return true
end

function M.sair()
  sessao = { access = nil, ate = 0, refresh = nil, user = nil, email = sessao.email }
  salvar()
  reaper.SetExtState(EXT, "live_ok", "", true)
end

local function token()
  if sessao.access and os.time() < sessao.ate then return true end
  return renovar()
end

--- GET no banco (PostgREST). Devolve a lista ou nil + mensagem.
function M.consulta(tabela, query)
  local ok, e = token()
  if not ok then return nil, e end
  local function go()
    return http.pedido(M.URL .. "/rest/v1/" .. tabela .. "?" .. query, { headers = { apikey = M.KEY, Authorization = "Bearer " .. sessao.access } })
  end
  local code, d, corpo = go()
  if code == 401 then
    local ok2, e2 = renovar(); if not ok2 then return nil, e2 end
    code, d, corpo = go()
  end
  if code == 0 then return nil, corpo end
  if code >= 300 then return nil, msgErro(d, corpo) end
  return d or {}
end

--- POST/PATCH/DELETE no banco. Devolve as linhas afetadas (lista) ou nil + mensagem.
function M.escrever(metodo, tabela, query, body)
  local ok, e = token()
  if not ok then return nil, e end
  local function go()
    return http.pedido(M.URL .. "/rest/v1/" .. tabela .. (query and query ~= "" and ("?" .. query) or ""), {
      method = metodo, body = body,
      headers = { apikey = M.KEY, Authorization = "Bearer " .. sessao.access, ["Content-Type"] = "application/json",
        Prefer = "return=representation" } })
  end
  local code, d, corpo = go()
  if code == 401 then
    local ok2, e2 = renovar(); if not ok2 then return nil, e2 end
    code, d, corpo = go()
  end
  if code == 0 then return nil, corpo end
  if code >= 300 then return nil, msgErro(d, corpo), code end
  return type(d) == "table" and d or {}
end

--- LS Live: as bandas da pessoa e se cada uma tem o LS Live no plano (migração 0044). nil + mensagem se falhar.
function M.acessoLive()
  local ok, e = token()
  if not ok then return nil, e end
  local function go() return post("/rest/v1/rpc/ls_live_acesso", {}, sessao.access) end
  local code, d, corpo = go()
  if code == 401 then
    local ok2, e2 = renovar(); if not ok2 then return nil, e2 end
    code, d, corpo = go()
  end
  if code == 0 then return nil, corpo, true end
  if code == 404 then return nil, "O servidor ainda não tem o LS Live (falta a migração 0044)." end
  if code >= 300 then return nil, msgErro(d, corpo) end
  local out = {}
  for _, x in ipairs(d or {}) do
    out[#out + 1] = { id = x.org_id, nome = json.get(x, "nome") or "Banda", lider = x.lider == true, liberado = x.liberado == true }
  end
  return out
end

function M.funcao(nome, body)
  local ok, e = token()
  if not ok then return nil, e end
  local code, d, corpo = http.pedido(M.URL .. "/functions/v1/" .. nome, {
    method = "POST", headers = { apikey = M.KEY, Authorization = "Bearer " .. sessao.access, ["Content-Type"] = "application/json" }, body = body })
  if code == 0 then return nil, corpo end
  if code >= 300 then return nil, msgErro(d, corpo) end
  return d
end

local function enc(s)
  return (tostring(s):gsub("[^%w%-%._~]", function(c) return string.format("%%%02X", c:byte()) end))
end
local function lista(ids)
  local t = {}
  for _, id in ipairs(ids) do t[#t + 1] = enc(id) end
  return "in.(" .. table.concat(t, ",") .. ")"
end

-- Dados ------------------------------------------------------------------------------------------

function M.bandas()
  local r, e = M.consulta("memberships", "select=org_id,role,org:organizations(id,name)&user_id=eq." .. enc(sessao.user or ""))
  if not r then return nil, e end
  local out = {}
  for _, m in ipairs(r) do
    local o = json.get(m, "org")
    if o then out[#out + 1] = { id = json.get(o, "id"), nome = json.get(o, "name"), lider = json.get(m, "role") == "leader" } end
  end
  table.sort(out, function(a, b) return a.nome:lower() < b.nome:lower() end)
  return out
end

--- Próximas escalas da banda (de hoje em diante), com as músicas na ordem e o tom do dia.
function M.escalas(org)
  local hoje = os.date("%Y-%m-%d")
  local sv, e = M.consulta("services", "select=id,title,starts_on,start_time,kind,location&org_id=eq." .. enc(org) ..
    "&starts_on=gte." .. hoje .. "&order=starts_on,start_time&limit=40")
  if not sv then return nil, e end
  if #sv == 0 then return {} end
  local ids = {}
  for _, s in ipairs(sv) do ids[#ids + 1] = s.id end
  local ss = M.consulta("service_songs", "select=service_id,project_id,position,song_key&order=position&service_id=" .. lista(ids)) or {}
  local by = {}
  for _, x in ipairs(ss) do
    local l = by[x.service_id] or {}
    l[#l + 1] = { projeto = x.project_id, pos = tonumber(json.get(x, "position")) or 0, tom = json.get(x, "song_key") }
    by[x.service_id] = l
  end
  local out = {}
  for _, s in ipairs(sv) do
    local musicas = by[s.id] or {}
    table.sort(musicas, function(a, b) return a.pos < b.pos end)
    out[#out + 1] = { id = s.id, titulo = s.title, dia = s.starts_on, hora = (json.get(s, "start_time") or ""):sub(1, 5),
      tipo = json.get(s, "kind") or "culto", local_ = json.get(s, "location"), musicas = musicas }
  end
  return out
end

--- Tudo o que é preciso para montar as músicas: ficha, faixas (com o arquivo), partes e ajustes publicados do estúdio.
function M.musicas(ids)
  if #ids == 0 then return {} end
  local ps, e = M.consulta("projects", "select=id,name,song_title,artist,bpm,time_signature,musical_key,band_key,session_duration_ms&id=" .. lista(ids))
  if not ps then return nil, e end
  local tr = M.consulta("tracks", "select=id,project_id,name,gain,timeline_offset_ms,sort_order,source_file:files(id,object_key,bucket,size_bytes)&order=sort_order&project_id=" .. lista(ids)) or {}
  local mk = M.consulta("song_markers", "select=project_id,name,at_ms,end_ms,updated_at&order=at_ms&project_id=" .. lista(ids)) or {}
  local ed = M.consulta("audio_edits", "select=track_id,trim_start_ms,trim_end_ms,offset_ms,gain_db,fade_in_ms,fade_out_ms&published=eq.true&project_id=" .. lista(ids)) or {}
  local edits = {}
  for _, x in ipairs(ed) do if json.get(x, "track_id") then edits[x.track_id] = x end end
  local out = {}
  for _, p in ipairs(ps) do
    local titulo = json.get(p, "song_title") or json.get(p, "name") or "Música"
    out[p.id] = { id = p.id, titulo = titulo, artista = json.get(p, "artist"), bpm = tonumber(json.get(p, "bpm")),
      compasso = json.get(p, "time_signature"), tom = json.get(p, "band_key") or json.get(p, "musical_key"),
      duracao = (tonumber(json.get(p, "session_duration_ms")) or 0) / 1000, faixas = {}, partes = {} }
  end
  for _, t in ipairs(tr) do
    local m = out[t.project_id]
    local f = json.get(t, "source_file")
    if m and f then
      local ed1 = edits[t.id]
      m.faixas[#m.faixas + 1] = {
        id = t.id, nome = json.get(t, "name") or "Faixa", ganho = tonumber(json.get(t, "gain")) or 1,
        atraso = ((tonumber(json.get(t, "timeline_offset_ms")) or 0) + (ed1 and tonumber(json.get(ed1, "offset_ms")) or 0)) / 1000,
        edicao = ed1 and { ini = (tonumber(json.get(ed1, "trim_start_ms")) or 0) / 1000, fim = json.get(ed1, "trim_end_ms") and tonumber(ed1.trim_end_ms) / 1000 or nil,
          db = tonumber(json.get(ed1, "gain_db")) or 0, fadeIn = (tonumber(json.get(ed1, "fade_in_ms")) or 0) / 1000,
          fadeOut = (tonumber(json.get(ed1, "fade_out_ms")) or 0) / 1000 } or nil,
        arquivo = { id = json.get(f, "id"), chave = json.get(f, "object_key"), bucket = json.get(f, "bucket") or "audio",
          bytes = tonumber(json.get(f, "size_bytes")) or 0 } }
    end
  end
  for _, x in ipairs(mk) do
    local m = out[x.project_id]
    if m then
      m.partes[#m.partes + 1] = { nome = json.get(x, "name") or "Parte", ini = (tonumber(x.at_ms) or 0) / 1000, fim = json.get(x, "end_ms") and tonumber(x.end_ms) / 1000 or nil }
      local u = json.get(x, "updated_at") or ""
      if u > (m.partesEm or "") then m.partesEm = u end
    end
  end
  return out
end

--- Links temporários (1 h) para baixar os arquivos. arquivos = { {id, chave, bucket}, ... } → { [id] = url }
function M.links(arquivos)
  local r2, out = {}, {}
  for _, a in ipairs(arquivos) do
    if a.bucket == "r2" then r2[#r2 + 1] = a.id
    else
      local ok, e = token()
      if not ok then return nil, e end
      local code, d = http.pedido(M.URL .. "/storage/v1/object/sign/audio/" .. a.chave:gsub(" ", "%%20"), {
        method = "POST", headers = { apikey = M.KEY, Authorization = "Bearer " .. sessao.access, ["Content-Type"] = "application/json" },
        body = { expiresIn = 3600 } })
      local u = code == 200 and d and (json.get(d, "signedURL") or json.get(d, "signedUrl"))
      if u then out[a.id] = M.URL .. "/storage/v1" .. u end
    end
  end
  for i = 1, #r2, 50 do
    local chunk = {}
    for j = i, math.min(#r2, i + 49) do chunk[#chunk + 1] = r2[j] end
    local d, e = M.funcao("r2", { action = "download", file_ids = chunk })
    if not d then return nil, e end
    for id, u in pairs(json.get(d, "urls") or {}) do out[id] = u end
  end
  return out
end

return M
