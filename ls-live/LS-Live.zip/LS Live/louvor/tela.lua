-- Louvor Studio para o REAPER — a janela: Entrar, Escalas, Preparar e Ao vivo. Desenhada pelo próprio REAPER (gfx),
-- no visual escuro e azul do app. Botões grandes, com nome, para usar de longe no culto.
local nuvem = require("louvor.nuvem")
local http = require("louvor.http")
local montar = require("louvor.montar")
local aovivo = require("louvor.aovivo")
local controles = require("louvor.controles")
local instalar = require("louvor.instalar")
local contagem = require("louvor.contagem")
local partes = require("louvor.partes")
local saidas = require("louvor.saidas")
local tom = require("louvor.tom")
local ordem = require("louvor.ordem")
local pad = require("louvor.pad")
local remoto = require("louvor.remoto")
local luzes = require("louvor.luzes")

local T = {}

-- Cores (tokens do DESIGN.md)
local C = { bg = "#050B12", panel = "#0A263A", control = "#123650", sel = "#0B3350", line = "#1B3A52", text = "#DCE8F2",
  hi = "#F5FAFF", muted = "#8FA9BF", accent = "#08A9F5", onAccent = "#050B12", ok = "#34D399", warn = "#FFB547", bad = "#FF7A70" }

-- Transparência vira cor sólida (misturada no fundo): as formas arredondadas são feitas de pedaços que se sobrepõem,
-- e com transparência as emendas ficariam manchadas.
local FUNDO = { 5, 11, 18 }
local function solida(r, g, b, a)
  a = a or 1
  gfx.set((FUNDO[1] + (r - FUNDO[1]) * a) / 255, (FUNDO[2] + (g - FUNDO[2]) * a) / 255, (FUNDO[3] + (b - FUNDO[3]) * a) / 255, 1)
end
local function cor(hex, a)
  local r, g, b = hex:match("#(%x%x)(%x%x)(%x%x)")
  solida(tonumber(r, 16), tonumber(g, 16), tonumber(b, 16), a)
end
local function corNativa(n, a)
  local r, g, b = reaper.ColorFromNative(n & 0xFFFFFF)
  solida(r, g, b, a)
end

-- Escala: a tela é desenhada num tamanho "de projeto" (VW × VH) e tudo é multiplicado por ESC. Assim, ao mudar o
-- tamanho da janela, os botões e os textos diminuem ou crescem juntos, em vez de sumirem.
local ESC, VW, VH = 1, 1000, 660
local function R(x, y, w, h, f) gfx.rect(x * ESC, y * ESC, w * ESC, h * ESC, f) end
local function RR(x, y, w, h, r, a) gfx.roundrect(x * ESC, y * ESC, w * ESC, h * ESC, r * ESC, a) end
local function CI(x, y, r, f, a) gfx.circle(x * ESC, y * ESC, r * ESC, f, a) end

local FONTE = reaper.GetOS():find("Win") and "Segoe UI" or "Helvetica"
local FONTES = { [1] = { 16, "" }, [2] = { 13, "" }, [3] = { 24, "b" }, [4] = { 22, "b" }, [5] = { 34, "b" }, [6] = { 15, "b" } }
local carregada = {}
local function fonte(n)
  local s = FONTES[n]
  local tam = math.max(7, math.floor(s[1] * ESC + 0.5))
  if carregada[n] == tam then gfx.setfont(n) return end
  carregada[n] = tam
  gfx.setfont(n, FONTE, tam, s[2] == "b" and string.byte("b") or 0)
end
local function medir(s) local w, h = gfx.measurestr(s) return w / ESC, h / ESC end

local S = {
  tela = "entrar", msg = nil, msgCor = C.muted, bandas = {}, banda = nil, escalas = {}, escala = nil, dados = nil,
  jobs = {}, baixando = false, espaco = 12, scroll = 0, carregando = false,
}
T.S = S

-- Mouse -------------------------------------------------------------------------------------------
local mouse = { down = false, clicked = false, rdown = false, rclicked = false, x = 0, y = 0 }
local function lerMouse()
  local d = gfx.mouse_cap & 1 == 1
  mouse.clicked = mouse.down and not d
  mouse.down = d
  local r = gfx.mouse_cap & 2 == 2
  mouse.rclicked = mouse.rdown and not r
  mouse.rdown = r
  mouse.x, mouse.y = gfx.mouse_x / ESC, gfx.mouse_y / ESC
  mouse.roda = gfx.mouse_wheel or 0
  gfx.mouse_wheel = 0
end
local function dentro(x, y, w, h) return mouse.x >= x and mouse.x < x + w and mouse.y >= y and mouse.y < y + h end

--- Retângulo arredondado cheio. Calculado em pixels inteiros da tela (sem riscos nas emendas em qualquer escala).
local function retangulo(x, y, w, h, raio)
  local X, Y = math.floor(x * ESC + 0.5), math.floor(y * ESC + 0.5)
  local W, H = math.floor((x + w) * ESC + 0.5) - X, math.floor((y + h) * ESC + 0.5) - Y
  if W <= 0 or H <= 0 then return end
  local r = math.floor(math.min((raio or 10) * ESC, H / 2, W / 2))
  if r < 2 then gfx.rect(X, Y, W, H, 1) return end
  gfx.rect(X, Y + r, W, H - 2 * r, 1)
  gfx.rect(X + r, Y, W - 2 * r, r, 1)
  gfx.rect(X + r, Y + H - r, W - 2 * r, r, 1)
  -- o círculo do REAPER sai 1 px maior que o raio: raio − 1 para as pontas não passarem do corpo
  gfx.circle(X + r, Y + r, r - 1, 1, 1)
  gfx.circle(X + W - r - 1, Y + r, r - 1, 1, 1)
  gfx.circle(X + r, Y + H - r - 1, r - 1, 1, 1)
  gfx.circle(X + W - r - 1, Y + H - r - 1, r - 1, 1, 1)
end

local function texto(s, x, y, f, hex, a)
  fonte(f or 1); cor(hex or C.text, a); gfx.x, gfx.y = x * ESC, y * ESC; gfx.drawstr(s)
end
local function largura(s, f) fonte(f or 1); return (medir(s)) end
local function centro(s, x, y, w, h, f, hex)
  fonte(f or 1); local tw, th = medir(s); cor(hex or C.text)
  gfx.x, gfx.y = (x + (w - tw) / 2) * ESC, (y + (h - th) / 2) * ESC; gfx.drawstr(s)
end
local function cortar(s, f, w)
  if largura(s, f) <= w then return s end
  while #s > 1 and largura(s .. "…", f) > w do s = s:sub(1, -2) end
  return s .. "…"
end

--- Botão. estilo: "primario" (azul cheio) | "secundario" (vidro) | "perigo". Devolve true no clique.
local function botao(rotulo, x, y, w, h, estilo, ativo)
  if ativo == false then
    cor(C.control, 0.5); retangulo(x, y, w, h, h / 2)
    centro(rotulo, x, y, w, h, 6, C.muted)
    return false
  end
  local sobre = dentro(x, y, w, h)
  if estilo == "primario" then cor(C.accent, sobre and 0.85 or 1) else cor(sobre and C.sel or C.control) end
  retangulo(x, y, w, h, h / 2)
  centro(rotulo, x, y, w, h, 6, estilo == "primario" and C.onAccent or (estilo == "perigo" and C.bad or C.accent))
  return sobre and mouse.clicked
end

local function aviso(msg, hex) S.msg = msg; S.msgCor = hex or C.muted end

-- Encaixar no REAPER (docker) e modo compacto ------------------------------------------------------
local TAM_NORMAL, TAM_MINI = { 1000, 660 }, { 720, 210 }
local BASE_NORMAL, BASE_MINI = { 1000, 660 }, { 720, 210 }
local function encaixada() return gfx.dock(-1) & 1 == 1 end
local function alternarEncaixe()
  if encaixada() then
    gfx.dock(0)
    local t = S.mini and TAM_MINI or TAM_NORMAL
    gfx.init("", t[1], t[2])
  else
    gfx.dock(1)
  end
  reaper.SetExtState("LouvorStudio", "dock", tostring(gfx.dock(-1)), true)
end
local function alternarMini()
  S.mini = not S.mini
  reaper.SetExtState("LouvorStudio", "mini", S.mini and "1" or "0", true)
  if not encaixada() then
    local t = S.mini and TAM_MINI or TAM_NORMAL
    gfx.init("", t[1], t[2])
  end
end
--- Compacto quando a pessoa minimizou ou quando a janela/painel ficou baixo e comprido (encaixado embaixo).
--- Depois escolhe a escala: o layout é pensado em BASE_* e cresce ou diminui junto com a janela.
local function atualizarEscala()
  local w, h = math.max(1, gfx.w), math.max(1, gfx.h)
  local mini = S.mini or h < 240 or w / h > 2.4
  S.compactoAgora = mini
  local b = mini and BASE_MINI or BASE_NORMAL
  ESC = math.max(0.5, math.min(mini and 1.8 or 2.0, math.min(w / b[1], h / b[2])))
  VW, VH = w / ESC, h / ESC
end
T.atualizarEscala = atualizarEscala
local function compacto() return S.compactoAgora end
T.alternarMini, T.alternarEncaixe = alternarMini, alternarEncaixe

-- Ícones desenhados (no lugar de símbolos de texto), no tamanho s, centrados em (cx, cy).
local function icone(nome, cx, cy, s, hex)
  cor(hex or C.text)
  local t = math.max(1.5, s * 0.14)  -- espessura do traço
  local function tri(x1, y1, x2, y2, x3, y3) gfx.triangle(x1 * ESC, y1 * ESC, x2 * ESC, y2 * ESC, x3 * ESC, y3 * ESC) end
  local function arco(r, a1, a2)
    for k = 0, math.max(1, math.floor(t * ESC)) do gfx.arc(cx * ESC, cy * ESC, r * ESC - k, a1, a2, 1) end
  end
  if nome == "tocar" then tri(cx - s * 0.32, cy - s * 0.42, cx - s * 0.32, cy + s * 0.42, cx + s * 0.42, cy)
  elseif nome == "parar" then retangulo(cx - s * 0.34, cy - s * 0.34, s * 0.68, s * 0.68, s * 0.1)
  elseif nome == "repetir" then
    arco(s * 0.38, math.rad(20), math.rad(300))
    tri(cx + s * 0.40, cy - s * 0.42, cx + s * 0.40, cy - s * 0.02, cx + s * 0.06, cy - s * 0.24)
  elseif nome == "musica-" or nome == "musica+" then
    local d = nome == "musica+" and 1 or -1
    tri(cx - d * s * 0.30, cy - s * 0.36, cx - d * s * 0.30, cy + s * 0.36, cx + d * s * 0.22, cy)
    R(cx + d * s * 0.26 - (d > 0 and 0 or t), cy - s * 0.36, t, s * 0.72, 1)
  elseif nome == "inicio" then
    R(cx - s * 0.36, cy - s * 0.34, t, s * 0.68, 1)
    tri(cx + s * 0.34, cy - s * 0.34, cx + s * 0.34, cy + s * 0.34, cx - s * 0.18, cy)
  elseif nome == "voltar" then
    local x1, y1, x2, y2, x3, y3 = (cx + s * 0.14) * ESC, (cy - s * 0.36) * ESC, (cx - s * 0.22) * ESC, cy * ESC, (cx + s * 0.14) * ESC, (cy + s * 0.36) * ESC
    local e = math.max(1, math.floor(t * ESC / 2))
    for k = -e, e do gfx.line(x1 + k, y1, x2 + k, y2, 1); gfx.line(x2 + k, y2, x3 + k, y3, 1) end
  elseif nome == "final" then
    R(cx - s * 0.32, cy - s * 0.42, t, s * 0.84, 1)
    tri(cx - s * 0.32 + t, cy - s * 0.40, cx + s * 0.38, cy - s * 0.20, cx - s * 0.32 + t, cy + s * 0.02)
  elseif nome == "suave" then
    for k = 0, 3 do
      local hh = s * (0.78 - k * 0.2)
      R(cx - s * 0.40 + k * s * 0.22, cy + s * 0.38 - hh, s * 0.15, hh, 1)
    end
  elseif nome == "opcoes" then
    for k = -1, 1 do CI(cx + k * s * 0.32, cy, math.max(1.5, s * 0.09), 1, 1) end
  elseif nome == "minimizar" then
    R(cx - s * 0.36, cy + s * 0.18, s * 0.72, t * 1.2, 1)
  elseif nome == "expandir" then
    local w = s * 0.7
    local x, y = cx - w / 2, cy - w / 2
    R(x, y, w, t * 1.6, 1); R(x, y + w - t, w, t, 1); R(x, y, t, w, 1); R(x + w - t, y, t, w, 1)
  elseif nome == "encaixar" or nome == "soltar" then
    local w, h = s * 0.8, s * 0.64
    local x, y = cx - w / 2, cy - h / 2
    R(x, y, w, t, 1); R(x, y + h - t, w, t, 1); R(x, y, t, h, 1); R(x + w - t, y, t, h, 1)
    if nome == "encaixar" then R(x, y + h * 0.58, w, h * 0.42, 1) else R(x + w * 0.5, y, w * 0.5, h * 0.45, 1) end
  end
end

--- Botões quadrados só com ícone (janela, transporte compacto).
local function botaoIcone(ic, x, y, w, h, estilo, hexIcone)
  local sobre = dentro(x, y, w, h)
  if estilo == "primario" then cor(C.accent, sobre and 0.85 or 1) else cor(sobre and C.sel or C.control) end
  retangulo(x, y, w, h, math.min(w, h) * 0.28)
  icone(ic, x + w / 2, y + h / 2, math.min(w, h) * 0.46, hexIcone or (estilo == "primario" and C.onAccent or C.text))
  return sobre and mouse.clicked
end

--- Botõezinhos do canto: opções, encaixar/soltar e minimizar/expandir.
local function botoesJanela(xFim, y, h)
  local w = h + 4
  if botaoIcone("opcoes", xFim - 3 * w - 16, y, w, h, "secundario") then S.abrirOpcoes = true end
  if botaoIcone(encaixada() and "soltar" or "encaixar", xFim - 2 * w - 8, y, w, h, "secundario") then alternarEncaixe() end
  if botaoIcone(S.mini and "expandir" or "minimizar", xFim - w, y, w, h, "secundario") then alternarMini() end
  return xFim - 3 * w - 24
end

-- Ações ---------------------------------------------------------------------------------------------
-- LS Live só para bandas com o plano que inclui (migração 0044) ------------------------------------
local DIAS_SEM_INTERNET = 7   -- sem internet no culto: vale a última confirmação de até 7 dias
local PLANOS_URL = "https://louvorstudio.app.br/#planos"

--- Pergunta ao servidor quais bandas da pessoa têm o LS Live. Devolve true se alguma tem.
local function verificarAcesso()
  S.semAcessoMsg = nil
  local lista, e, semNet = nuvem.acessoLive()
  if not lista then
    -- sem internet: vale a última conferência (até 7 dias, e nunca depois do fim do teste grátis)
    local ok = tonumber(reaper.GetExtState("LouvorStudio", "live_ok")) or 0
    local fimTeste = tonumber(reaper.GetExtState("LouvorStudio", "live_teste_ate"))
    if semNet and os.time() - ok < DIAS_SEM_INTERNET * 86400 and (not fimTeste or os.time() < fimTeste) then
      S.liberado = true; S.liberadas = nil; return true
    end
    S.liberado = false; S.semAcessoMsg = e
    return false
  end
  S.acesso = lista
  local lib, alguma, pago, fimTeste = {}, false, false, nil
  for _, b in ipairs(lista) do
    if b.liberado then
      lib[b.id] = true; alguma = true
      if b.emTeste then fimTeste = math.max(fimTeste or 0, b.testeAte or 0) else pago = true end
    end
  end
  S.liberadas, S.liberado = lib, alguma
  S.testeAte = (not pago) and fimTeste or nil
  reaper.SetExtState("LouvorStudio", "live_ok", alguma and tostring(os.time()) or "", true)
  reaper.SetExtState("LouvorStudio", "live_teste_ate", S.testeAte and tostring(math.floor(S.testeAte)) or "", true)
  return alguma
end

--- "Teste grátis do LS Live: faltam 5 dias." (nil se a banda já tem o LS Live de verdade)
local function textoTeste()
  if not S.testeAte then return nil end
  local dias = math.max(0, math.ceil((S.testeAte - os.time()) / 86400))
  return "Teste grátis do LS Live: " .. (dias <= 1 and "último dia." or ("faltam " .. dias .. " dias.")) .. " Para continuar, adicione o LS Live em Planos no site."
end
T.textoTeste = textoTeste
T.verificarAcesso = verificarAcesso

local function abrirLink(url)
  if http.WIN then reaper.ExecProcess('cmd.exe /C start "" "' .. url .. '"', -1)
  else reaper.ExecProcess('/usr/bin/open "' .. url .. '"', -1) end
end

local function carregarBandas()
  local b, e = nuvem.bandas()
  if not b then aviso(e, C.bad) return end
  -- só as bandas com o LS Live liberado
  if S.liberadas then
    local f = {}
    for _, x in ipairs(b) do if S.liberadas[x.id] then f[#f + 1] = x end end
    b = f
  end
  S.bandas = b
  local salva = reaper.GetExtState("LouvorStudio", "banda")
  S.banda = nil
  for _, x in ipairs(b) do if x.id == salva then S.banda = x end end
  S.banda = S.banda or b[1]
  if not S.banda then aviso("Sua conta ainda não está em nenhuma banda. Entre numa banda pelo app ou pelo site.", C.warn) return end
end

local function carregarEscalas()
  if not S.banda then return end
  local e, err = nuvem.escalas(S.banda.id)
  if not e then aviso(err, C.bad) return end
  S.escalas = e
  aviso(#e == 0 and "Nenhuma escala marcada a partir de hoje." or nil)
end

local function entrar()
  local ok, vals = reaper.GetUserInputs("LS Live · Entrar", 2, "E-mail da sua conta,*Senha,extrawidth=220", (nuvem.email() or "") .. ",")
  if not ok then return end
  local email, senha = vals:match("^(.-),(.*)$")
  email = (email or ""):gsub("%s", "")
  if email == "" or (senha or "") == "" then aviso("Escreva o e-mail e a senha.", C.warn) return end
  aviso("Entrando…")
  local okE, e = nuvem.entrar(email, senha)
  if not okE then aviso(e, C.bad) return end
  T.depoisDeEntrar()
end

--- Depois de entrar: confere o plano e segue para as escalas (ou para a tela do plano).
local function depoisDeEntrar()
  aviso(nil)
  if not verificarAcesso() then S.tela = "semPlano" return end
  carregarBandas()
  carregarEscalas()
  S.tela = "escalas"
  local t = textoTeste()
  if t then aviso(t, C.warn) end
end
T.depoisDeEntrar = depoisDeEntrar

local function caminhoLocal(f)
  local ext = (f.arquivo.chave or ""):match("%.(%w+)$") or "mp3"
  return http.pasta("musicas") .. (http.WIN and "\\" or "/") .. f.arquivo.id .. "." .. ext:lower()
end

local function abrirEscala(e)
  S.escala = e
  S.dados = nil
  S.montada = false   -- outra escala: o botão volta a ser "montar" (no projeto aberto), não "abrir o ao vivo"
  S.tela = "preparar"
  aviso("Buscando as músicas…")
  local ids = {}
  for _, m in ipairs(e.musicas) do ids[#ids + 1] = m.projeto end
  local d, err = nuvem.musicas(ids)
  if not d then aviso(err, C.bad) return end
  S.dados = d
  aviso(nil)
end

local function faltam()
  local lista = {}
  if not S.dados then return lista end
  for _, em in ipairs(S.escala.musicas) do
    local m = S.dados[em.projeto]
    for _, f in ipairs(m and m.faixas or {}) do
      if not reaper.file_exists(caminhoLocal(f)) then lista[#lista + 1] = f end
    end
  end
  return lista
end

local function comecarDownload()
  local lista = faltam()
  if #lista == 0 then return true end
  local pasta = http.pasta("musicas")
  if not http.gravavel(pasta) then
    aviso("Não consigo gravar na pasta " .. pasta .. ". Abra o REAPER normalmente (não pela pasta do programa) ou libere a pasta no antivírus.", C.bad)
    return false
  end
  local arqs = {}
  for _, f in ipairs(lista) do arqs[#arqs + 1] = f.arquivo end
  aviso("Pedindo os links de download…")
  local links, e = nuvem.links(arqs)
  if not links then aviso(e, C.bad) return false end
  S.jobs = {}
  for _, f in ipairs(lista) do
    S.jobs[#S.jobs + 1] = { faixa = f, url = links[f.arquivo.id], destino = caminhoLocal(f), estado = links[f.arquivo.id] and "fila" or "erro" }
  end
  S.baixando = true
  aviso(nil)
  return false
end

local function passoDownload()
  if not S.baixando then return end
  local rodando, pendentes, erros = 0, 0, 0
  local agora = reaper.time_precise()
  for _, j in ipairs(S.jobs) do
    if j.estado == "baixando" then
      local r, motivo = http.pronto(j.destino)
      if r == "ok" then j.estado = "ok"
      elseif r == "erro" then j.estado = "erro"; S.motivoErro = S.motivoErro or motivo
      else
        -- o curl nem começou (nada no disco depois de 45 s): sem isso ficava "Baixando 0 de N" para sempre
        local n = http.tamanho(j.destino)
        if n > (j.bytes or 0) then j.bytes = n; j.mexeu = agora end
        if n == 0 and agora - (j.inicio or agora) > 45 then
          j.estado = "erro"; S.motivoErro = S.motivoErro or "O download não começou (o Windows ou o antivírus pode ter bloqueado o curl)."
        else rodando = rodando + 1 end
      end
    end
  end
  for _, j in ipairs(S.jobs) do
    if j.estado == "fila" and rodando < 3 then http.baixar(j.url, j.destino); j.estado = "baixando"; j.inicio = agora; rodando = rodando + 1 end
    if j.estado == "fila" or j.estado == "baixando" then pendentes = pendentes + 1 end
    if j.estado == "erro" then erros = erros + 1 end
  end
  if pendentes == 0 then
    S.baixando = false
    if erros > 0 then
      local m = S.motivoErro; S.motivoErro = nil
      aviso(erros .. " arquivo(s) não baixaram. " .. (m and ("Motivo: " .. m:sub(1, 160) .. "  ") or "") ..
        "Confira a internet e toque de novo em Baixar e montar.", C.bad)
      return
    end
    local r = montar.montar(S.escala, S.dados, function(f) local p = caminhoLocal(f); return reaper.file_exists(p) and p or nil end, { espaco = S.espaco, novaAba = S.novaAba })
    S.novaAba = nil
    aviso(string.format("Pronto! %d música(s) e %d faixa(s) montadas.", r.musicas, r.faixas) ..
      (#r.faltando > 0 and ("  Ficaram de fora: " .. table.concat(r.faltando, "; ")) or ""), #r.faltando > 0 and C.warn or C.ok)
    aovivo.ler()
    S.montada = true
    -- montou: vai direto para o modo ao vivo
    if r.musicas > 0 then
      S.tela = "aovivo"
      S.avisoAoVivo = { texto = #r.faltando > 0 and ("Ficaram de fora: " .. table.concat(r.faltando, "; ")) or
        string.format("Pronto! %d música(s) montadas.", r.musicas), cor = #r.faltando > 0 and C.warn or C.ok, ate = reaper.time_precise() + 8 }
    end
  end
end

--- Baixa o que falta (se faltar) e monta.
local function baixarEMontar()
  if comecarDownload() then S.jobs = {}; S.baixando = true end
end

T.baixarEMontar = baixarEMontar

--- O projeto aberto já é desta escala (montada antes)?
local function projetoDestaEscala()
  if not (S.escala and #aovivo.ler() > 0) then return false end
  for _, id in ipairs(montar.escalasDoProjeto()) do if id == S.escala.id then return true end end
  return false
end

--- Seta de voltar do ao vivo: volta para a escala deste projeto (ou a lista de escalas). Só pede para entrar se a
--- pessoa realmente não estiver com a conta aberta.
function T.sairDoAoVivo()
  aviso(nil)
  if S.escala then S.tela = "preparar" return end
  if not (nuvem.userId() and nuvem.carregar()) then S.tela = "entrar" return end
  S.tela = "escalas"
  if #S.escalas == 0 then
    local ok, e = pcall(function() carregarBandas(); carregarEscalas() end)
    if not ok then aviso(tostring(e), C.bad) return end
  end
  -- a escala que foi montada neste projeto, se ainda estiver na lista
  local _, id = reaper.GetProjExtState(0, "LouvorStudio", "escala")
  for _, e in ipairs(S.escalas) do
    if e.id == id and #e.musicas > 0 then abrirEscala(e) return end
  end
end

-- Telas ---------------------------------------------------------------------------------------------
local MESES = { "jan", "fev", "mar", "abr", "mai", "jun", "jul", "ago", "set", "out", "nov", "dez" }
local SEMANA = { "domingo", "segunda", "terça", "quarta", "quinta", "sexta", "sábado" }
local function dataBonita(dia)
  local a, m, d = dia:match("(%d+)-(%d+)-(%d+)")
  a, m, d = tonumber(a), tonumber(m), tonumber(d)
  if not a then return dia, "", "" end
  local t = os.time({ year = a, month = m, day = d, hour = 12 })
  return tostring(d), MESES[m] or "", SEMANA[tonumber(os.date("%w", t)) + 1] or ""
end

--- Cabeçalho das telas: voltar (se houver), título grande, uma linha embaixo, e os botões do canto.
local function topo(titulo, sub, voltar)
  local x = 24
  if voltar then
    if botaoIcone("voltar", 16, 20, 40, 40, "secundario") then voltar() end
    x = 72
  end
  local xFim = botoesJanela(VW - 16, 22, 36)
  texto(cortar(titulo, 5, math.max(80, xFim - x - 12)), x, sub and 12 or 22, 5, C.hi)
  if sub then texto(cortar(sub, 1, math.max(80, xFim - x - 12)), x, 52, 1, C.muted) end
  cor(C.line); R(0, 84, VW, 1, 1)
end

--- Faixa compacta das telas que não são o ao vivo.
local function telaMiniSimples(titulo)
  cor(C.bg); R(0, 0, VW, VH, 1)
  local logo = 30
  cor(C.accent); retangulo(16, 16, logo, logo, 9)
  for k, a in ipairs({ 0.35, 0.7, 1, 0.6, 0.3 }) do
    cor(C.onAccent); R(16 + 6 + (k - 1) * 4.2, 16 + logo / 2 - a * 8, 2.4, a * 16, 1)
  end
  texto("LS Live", 56, 14, 6, C.hi)
  texto(cortar(titulo, 2, VW - 200), 56, 34, 2, C.muted)
  botoesJanela(VW - 12, 16, 34)
  if S.mini and VH >= 120 and botao("Abrir a janela inteira", 16, 72, math.min(300, VW - 32), 48, "primario") then alternarMini() end
end

local function rodape()
  if not S.msg then return end
  cor(C.bg); R(0, VH - 40, VW, 40, 1)
  cor(C.line); R(0, VH - 40, VW, 1, 1)
  if S.msgCor ~= C.muted then cor(S.msgCor); CI(24, VH - 20, 4, 1, 1) end
  texto(cortar(S.msg, 1, VW - 60), S.msgCor ~= C.muted and 38 or 24, VH - 30, 1, S.msgCor)
end

local function telaEntrar()
  topo("LS Live", "Louvor Studio Live para o REAPER")
  local w = math.min(560, VW - 48)
  local x = (VW - w) / 2
  local y = math.max(110, (VH - 400) / 2 + 30)
  texto("Leve a escala para o REAPER", x, y, 5, C.hi)
  texto("Entre com o e-mail e a senha da sua conta do Louvor Studio.", x, y + 52, 1, C.text)
  -- o caminho, em três passos (a ordem importa)
  local py = y + 96
  local passos = { "Entre na sua conta do Louvor Studio", "Escolha a escala do culto", "Toque ao vivo pelos quadradinhos" }
  for i, s in ipairs(passos) do
    local yy = py + (i - 1) * 36
    cor(C.control); CI(x + 13, yy + 12, 13, 1, 1)
    centro(tostring(i), x, yy - 1, 26, 26, 6, C.accent)
    texto(s, x + 40, yy + 3, 1, C.text)
  end
  if botao("Entrar", x, py + 124, w, 52, "primario") then entrar() end
  texto("Entrou no app com o Google? Crie uma senha em \"Esqueci minha senha\" no app.", x, py + 188, 2, C.muted)
end

--- A banda da pessoa ainda não tem o LS Live no plano.
local function telaSemPlano()
  topo("LS Live", "Louvor Studio Live para o REAPER")
  local w = math.min(620, VW - 48)
  local x = (VW - w) / 2
  local y = math.max(110, (VH - 440) / 2 + 30)
  local lider, testar, terminou = false, {}, false
  for _, b in ipairs(S.acesso or {}) do
    if b.lider then lider = true end
    if b.podeTestar then testar[#testar + 1] = b end
    if b.testeAte and not b.liberado then terminou = true end
  end
  if #testar > 0 and not S.semAcessoMsg then
    -- ainda dá para experimentar: 7 dias grátis, uma vez por banda
    texto("Experimente o LS Live por 7 dias", x, y, 5, C.hi)
    texto("Grátis, sem cartão. Os 7 dias começam agora e valem para a banda toda.", x, y + 52, 1, C.text)
    texto("Depois, R$ 19,90 por mês em qualquer plano pago, ou já incluso no plano Igreja.", x, y + 78, 2, C.muted)
    local by = y + 116
    for i, b in ipairs(testar) do
      if i > 3 then break end
      local rot = #testar == 1 and "Começar os 7 dias grátis" or ("Começar os 7 dias grátis · " .. b.nome)
      if botao(cortar(rot, 6, w - 40), x, by, w, 52, "primario") then
        aviso("Começando o teste…")
        local okT, e = nuvem.comecarTeste(b.id)
        if okT and verificarAcesso() then depoisDeEntrar() else aviso(e or "Não deu para começar o teste.", C.bad) end
      end
      by = by + 62
    end
    local bw = (w - 10) / 2
    if botao("Ver os planos", x, by + 4, bw, 44, "secundario") then abrirLink(PLANOS_URL) end
    if botao("Sair da conta", x + bw + 10, by + 4, bw, 44, "secundario") then nuvem.sair(); S.liberado = false; S.tela = "entrar"; aviso(nil) end
    return
  end
  texto(terminou and "O teste grátis do LS Live terminou" or "O LS Live faz parte de um plano", x, y, 5, C.hi)
  if S.semAcessoMsg then
    texto(cortar(S.semAcessoMsg, 1, w), x, y + 52, 1, C.warn)
  elseif #(S.acesso or {}) == 0 then
    texto("Sua conta ainda não está em nenhuma banda.", x, y + 52, 1, C.text)
  else
    local nomes = {}
    for _, b in ipairs(S.acesso) do nomes[#nomes + 1] = b.nome end
    texto(cortar((#nomes == 1 and "A banda " or "As bandas ") .. table.concat(nomes, ", ") ..
      (#nomes == 1 and " ainda não tem" or " ainda não têm") .. " o LS Live.", 1, w), x, y + 52, 1, C.text)
  end
  texto("R$ 19,90 por mês em qualquer plano pago, ou já incluso no plano Igreja.", x, y + 80, 1, C.text)
  texto(lider and "Como líder, você pode adicionar o LS Live pelo site do Louvor Studio (Planos)."
    or "Peça ao líder da sua banda para adicionar o LS Live pelo site do Louvor Studio.", x, y + 104, 2, C.muted)
  if botao("Ver os planos", x, y + 140, w, 52, "primario") then abrirLink(PLANOS_URL) end
  local bw = (w - 10) / 2
  if botao("Já assinei · conferir de novo", x, y + 204, bw, 44, "secundario") then
    aviso("Conferindo…")
    if verificarAcesso() then depoisDeEntrar() else aviso("Ainda não aparece o LS Live na sua banda.", C.warn) end
  end
  if botao("Sair da conta", x + bw + 10, y + 204, bw, 44, "secundario") then nuvem.sair(); S.liberado = false; S.tela = "entrar"; aviso(nil) end
end

local function telaEscalas()
  topo("Escalas", S.banda and ("Banda " .. S.banda.nome) or nil)
  local y = 104
  -- bandas (só quando a pessoa está em mais de uma)
  if #S.bandas > 1 then
    local x = 24
    for _, b in ipairs(S.bandas) do
      local w = largura(b.nome, 6) + 32
      local on = S.banda and S.banda.id == b.id
      local sobre = dentro(x, y, w, 34)
      if on then cor(C.accent) else cor(sobre and C.sel or C.control) end
      retangulo(x, y, w, 34, 17)
      centro(b.nome, x, y, w, 34, 6, on and C.onAccent or C.text)
      if sobre and mouse.clicked then
        S.banda = b; S.scroll = 0; reaper.SetExtState("LouvorStudio", "banda", b.id, true); carregarEscalas()
      end
      x = x + w + 8
    end
  end
  if botao("Atualizar", VW - 24 - 120, y, 120, 34, "secundario") then carregarEscalas() end
  y = y + 52
  local fim = VH - (S.msg and 48 or 12)
  local h, gap = 76, 10
  local cabem = math.max(1, math.floor((fim - y + gap) / (h + gap)))
  local maxScroll = math.max(0, #S.escalas - cabem)
  if mouse.roda ~= 0 and dentro(0, y, VW, fim - y) then S.scroll = math.max(0, math.min(maxScroll, (S.scroll or 0) - (mouse.roda > 0 and 1 or -1))) end
  S.scroll = math.min(S.scroll or 0, maxScroll)
  for i = 1 + S.scroll, math.min(#S.escalas, S.scroll + cabem) do
    local e = S.escalas[i]
    local n = #e.musicas
    local sobre = dentro(24, y, VW - 48, h) and n > 0
    cor(sobre and C.sel or C.panel); retangulo(24, y, VW - 48, h, 16)
    local d, mes, sem = dataBonita(e.dia)
    -- data em bloco
    cor(C.bg); retangulo(36, y + 10, 64, h - 20, 12)
    centro(d, 36, y + 12, 64, 30, 4, C.hi)
    centro(mes, 36, y + 40, 64, 18, 2, C.accent)
    texto(cortar(e.titulo, 4, VW - 360), 120, y + 14, 4, C.hi)
    local info = sem .. ((e.hora or "") ~= "" and (" · " .. e.hora) or "") .. "  ·  " ..
      (n == 0 and "sem músicas ainda" or (n .. (n == 1 and " música" or " músicas")))
    texto(cortar(info, 1, VW - 360), 120, y + 44, 1, C.muted)
    if n > 0 then
      local s = "Abrir"
      local bw = largura(s, 6) + 40
      cor(sobre and C.accent or C.control); retangulo(VW - 48 - bw - 8, y + (h - 34) / 2, bw, 34, 17)
      centro(s, VW - 48 - bw - 8, y + (h - 34) / 2, bw, 34, 6, sobre and C.onAccent or C.accent)
    end
    if sobre and mouse.clicked then abrirEscala(e) end
    y = y + h + gap
  end
  if maxScroll > 0 then
    texto(string.format("%d–%d de %d · role para ver mais", S.scroll + 1, math.min(#S.escalas, S.scroll + cabem), #S.escalas),
      24, math.min(y, fim - 18), 2, C.muted)
  end
end

local function telaPreparar()
  local e = S.escala
  local d, mes, sem = dataBonita(e.dia)
  topo(e.titulo, sem .. ", " .. d .. " de " .. mes .. ((e.hora or "") ~= "" and (" · " .. e.hora) or "") .. "  ·  " ..
    #e.musicas .. (#e.musicas == 1 and " música" or " músicas"), function() S.tela = "escalas"; aviso(nil) end)
  if not S.dados then return end
  local porFaixa = {}
  for _, j in ipairs(S.jobs) do porFaixa[j.faixa.id] = j end
  local y = 104
  local baseY = VH - (S.msg and 40 or 0) - 150
  local h = 52
  for i, em in ipairs(e.musicas) do
    if y + h > baseY - 10 then
      texto("+ " .. (#e.musicas - i + 1) .. " música(s)", 24, y, 2, C.muted)
      break
    end
    local m = S.dados[em.projeto]
    cor(C.panel); retangulo(24, y, VW - 48, h, 14)
    centro(tostring(i), 24, y, 48, h, 6, C.muted)
    texto(cortar(m and m.titulo or "Música", 6, VW - 480), 72, y + 9, 6, C.hi)
    local info = {}
    if m and m.bpm then info[#info + 1] = m.bpm .. " BPM" end
    if m and m.faixas and #m.faixas > 0 then info[#info + 1] = #m.faixas .. " faixas" end
    texto(table.concat(info, " · "), 72, y + 30, 2, C.muted)
    -- tom em selo
    local tom = em.tom or (m and m.tom)
    local xs = VW - 48 - 170
    if tom then
      local tw = largura("Tom " .. tom, 6) + 20
      cor(C.control); retangulo(xs - tw - 12, y + (h - 26) / 2, tw, 26, 13)
      centro("Tom " .. tom, xs - tw - 12, y + (h - 26) / 2, tw, 26, 6, C.accent)
    end
    -- estado
    local st, stc, frac
    if not m or #m.faixas == 0 then st, stc = "Sem multitrack", C.warn
    else
      local ok, total, baix = 0, #m.faixas, false
      for _, f in ipairs(m.faixas) do
        if reaper.file_exists(caminhoLocal(f)) then ok = ok + 1 end
        local j = porFaixa[f.id]; if j and j.estado == "baixando" then baix = true end
      end
      if ok == total then st, stc = "Baixada", C.ok
      elseif baix then st, stc, frac = "Baixando " .. ok .. "/" .. total, C.accent, ok / total
      else st, stc = (total - ok) .. " faixa(s) para baixar", C.muted end
    end
    cor(stc); CI(xs + 8, y + h / 2, 4, 1, 1)
    texto(cortar(st, 2, 150), xs + 20, y + h / 2 - 8, 2, stc)
    if frac then
      cor(C.control); retangulo(xs + 20, y + h / 2 + 10, 130, 4, 2)
      cor(C.accent); retangulo(xs + 20, y + h / 2 + 10, math.max(4, 130 * frac), 4, 2)
    end
    y = y + h + 8
  end
  -- espaço entre as músicas (controle segmentado)
  local by = baseY
  texto("Espaço entre as músicas", 24, by + 8, 1, C.text)
  local sx = 24 + largura("Espaço entre as músicas", 1) + 16
  local opc = { 10, 12, 15 }
  cor(C.panel); retangulo(sx, by, 3 * 64 + 8, 36, 18)
  for k, s in ipairs(opc) do
    local x = sx + 4 + (k - 1) * 64
    local on = S.espaco == s
    if on then cor(C.accent); retangulo(x, by + 4, 64, 28, 14) end
    centro(s .. " s", x, by + 4, 64, 28, 6, on and C.onAccent or C.text)
    if dentro(x, by, 64, 36) and mouse.clicked then S.espaco = s end
  end
  local w = VW - 48
  local yb = by + 56
  if S.baixando then
    local feitos, mb = 0, 0
    for _, j in ipairs(S.jobs) do
      if j.estado == "ok" or j.estado == "erro" then feitos = feitos + 1 end
      if j.estado == "ok" then mb = mb + (j.total or http.tamanho(j.destino)); j.total = j.total or http.tamanho(j.destino)
      elseif j.estado == "baixando" then mb = mb + (j.bytes or 0) end
    end
    cor(C.control); retangulo(24, yb, w, 56, 28)
    cor(C.accent); retangulo(24, yb, math.max(56, w * feitos / math.max(1, #S.jobs)), 56, 28)
    centro(string.format("Baixando %d de %d…  %.1f MB", feitos, #S.jobs, mb / 1048576), 24, yb, w, 56, 6, C.hi)
  elseif S.montada or projetoDestaEscala() then
    if botao("Abrir o modo ao vivo", 24, yb, w * 0.62, 56, "primario") then aovivo.ler(); S.tela = "aovivo" end
    if botao("Montar de novo (nova aba)", 24 + w * 0.62 + 10, yb, w * 0.38 - 10, 56, "secundario") then S.montada = false; S.novaAba = true; baixarEMontar() end
  else
    local falta = #faltam()
    -- projeto já com músicas (outra escala): esta entra no fim dele, com o mesmo espaço entre as músicas
    local somar = #aovivo.ler() > 0
    local rot = somar and (falta > 0 and ("Baixar " .. falta .. " faixa(s) e pôr no fim deste projeto") or "Pôr no fim deste projeto")
      or (falta > 0 and ("Baixar " .. falta .. " faixa(s) e montar no REAPER") or "Montar no REAPER")
    if botao(rot, 24, yb, w, 56, "primario") then
      baixarEMontar()
    end
  end
end

-- Ao vivo -------------------------------------------------------------------------------------------
local pisca = 0
local function executar(cmd)
  local E = aovivo.estado
  local mi, pi, m = aovivo.onde()
  local n = cmd:match("^p(%d+)$")
  local nome = cmd:match("^n:(.+)$")
  if nome then
    -- pelo nome: a próxima parte com esse nome na música atual (se não houver depois, a primeira)
    if m then
      local alvo, primeira = nil, nil
      for k, parte in ipairs(m.partes) do
        if montar.norm(parte.nome) == montar.norm(nome) then
          primeira = primeira or k
          if not alvo and pi and k > pi then alvo = k end
        end
      end
      if alvo or primeira then aovivo.parte(alvo or primeira) end
    end
  elseif n then aovivo.parte(tonumber(n))
  elseif cmd == "tocar" then aovivo.tocarParar()
  elseif cmd == "repetir" then aovivo.repetir()
  elseif cmd == "inicio" then aovivo.comecoDaParte()
  elseif cmd == "parte+" then if m and pi and m.partes[pi + 1] then aovivo.parte(pi + 1) end
  elseif cmd == "parte-" then if m and pi and pi > 1 then aovivo.parte(pi - 1) end
  elseif cmd == "musica+" then aovivo.musica(1)
  elseif cmd == "musica-" then aovivo.musica(-1)
  elseif cmd == "final" then aovivo.final()
  elseif cmd == "suave" then aovivo.pararSuave()
  elseif cmd == "marcar" then T.marcarParteAqui()
  elseif cmd == "pad" then
    local on = pad.alternar()
    S.ligou = { texto = on and "Pad ligado: com o REAPER parado, soa o tom da próxima música." or "Pad desligado.", ate = reaper.time_precise() + 4 }
  elseif cmd == "ordem" then
    ordem.alternar()
    S.ligou = { texto = ordem.ligada() and "Seguindo a ordem das partes." or "Ordem das partes desligada (as partes seguem a música).", ate = reaper.time_precise() + 4 }
  elseif m and (cmd == "tom+" or cmd == "tom-") then
    tom.mudarTom(mi, m, cmd == "tom+" and 1 or -1)
    S.ligou = { texto = "Tom: " .. (tom.soando(mi) or ((tom.ajuste(mi).semi > 0 and "+" or "") .. tom.ajuste(mi).semi)), ate = reaper.time_precise() + 3 }
  elseif m and cmd == "tomdia" then
    local d = tom.paraOTomDoDia(mi)
    if d then tom.definirSemi(mi, m, d); S.ligou = { texto = "No tom do dia: " .. (tom.soando(mi) or ""), ate = reaper.time_precise() + 3 } end
  elseif m and (cmd == "bpm+" or cmd == "bpm-") then
    tom.mudarAndamento(mi, m, cmd == "bpm+" and 1 or -1)
    local b = tom.bpm(mi, m)
    S.ligou = { texto = "Andamento: " .. (b and (math.floor(b + 0.5) .. " BPM") or (math.floor(tom.ajuste(mi).taxa * 100 + 0.5) .. "%")), ate = reaper.time_precise() + 3 }
  end
end
T.executar = executar

-- Nome do comando para a pessoa: o quadradinho diz qual parte está nele agora.
local function nomeDoComando(cmd)
  local k = tonumber(cmd:match("^p(%d+)$") or "")
  if k then
    local _, _, m = aovivo.onde()
    local parte = m and m.partes[k]
    return "Quadradinho " .. k .. (parte and (" (agora: " .. parte.nome .. ")") or "")
  end
  return controles.nome(cmd)
end

--- Botão direito num quadradinho ou num botão do ao vivo: guarda para abrir o menu no fim do quadro.
local function ligavel(x, y, w, h, cmd)
  if mouse.rclicked and dentro(x, y, w, h) then S.menuPara = cmd end
end

--- Clique esquerdo: no modo "Ligar controlador", escolhe o que ligar; senão, executa.
local function acionar(cmd)
  if S.aprenderModo then controles.aprendendo = cmd; S.esperandoTecla = nil return end
  local k = tonumber(cmd:match("^p(%d+)$") or "")
  if S.editOrdem and k then
    local _, _, m = aovivo.onde()
    local parte = m and m.partes[k]
    if parte then
      local nomes = ordem.nomes(S.editOrdem)
      nomes[#nomes + 1] = parte.nome
      ordem.salvar(S.editOrdem, nomes)
    end
    return
  end
  executar(cmd)
end

-- Trava contra toque sem querer: tocando, os botões da tela pedem segurar meio segundo (teclas, pads e celular não).
local SEGURAR = 0.6
local function travaAtiva()
  return reaper.GetExtState("LouvorStudio", "trava") == "1" and aovivo.tocando() and not S.aprenderModo and not S.editOrdem
end
--- Clique (ou toque segurado, com a trava) num botão do ao vivo.
local function toque(cmd, x, y, w, h)
  local sobre = dentro(x, y, w, h)
  if not travaAtiva() then
    if sobre and mouse.clicked then acionar(cmd) end
    return
  end
  local agora = reaper.time_precise()
  if sobre and mouse.down and not S.segura then S.segura = { cmd = cmd, t0 = agora, x = x, y = y } end
  local sg = S.segura
  if sg and sg.cmd == cmd and sg.x == x and sg.y == y then
    if not mouse.down or not sobre then
      if not sg.feito then S.dicaTrava = agora end
      S.segura = nil
    else
      local f = math.min(1, (agora - sg.t0) / SEGURAR)
      cor(C.hi); R(x + 10, y + h - 7, math.max(1, (w - 20) * f), 4, 1)
      if f >= 1 and not sg.feito then sg.feito = true; acionar(cmd) end
    end
  end
end

--- O menu do botão direito: ligar tecla do computador, ligar pad/botão do controlador, tirar, voltar ao padrão.
local function menuLigar()
  local cmd = S.menuPara
  S.menuPara = nil
  local k = tonumber(cmd:match("^p(%d+)$") or "")
  local _, _, m = aovivo.onde()
  local parte = k and m and m.partes[k]
  local cmdNome = parte and ("n:" .. parte.nome)
  local atual = controles.rotulo(cmd, 6)
  local atualN = cmdNome and controles.rotulo(cmdNome, 6) or ""
  local limpo = function(x) return (x:gsub("|", "/"):gsub("^[#!<>]", "")) end
  local titulo = limpo(nomeDoComando(cmd))
  local itens, acoes = {}, {}
  local function item(t, f) itens[#itens + 1] = t; acoes[#itens] = f end
  item("#" .. titulo .. "  —  " .. (atual ~= "" and atual or "sem tecla"), nil)
  item("Ligar a uma tecla do computador (este quadradinho, em qualquer música)…", function() S.esperandoTecla = cmd; controles.aprendendo = nil end)
  item("Ligar a um pad / botão do controlador (este quadradinho)…", function() controles.aprendendo = cmd; S.esperandoTecla = nil end)
  if parte then
    local np = limpo(parte.nome)
    item("Ligar uma tecla ao nome \"" .. np .. "\" (vale em todas as músicas)…" .. (atualN ~= "" and ("  —  " .. atualN) or ""),
      function() S.esperandoTecla = cmdNome; controles.aprendendo = nil end)
    item("Ligar um pad ao nome \"" .. np .. "\" (vale em todas as músicas)…", function() controles.aprendendo = cmdNome; S.esperandoTecla = nil end)
  end
  item(((atual ~= "" or atualN ~= "") and "" or "#") .. "Tirar as teclas e os pads deste botão", function()
    controles.tirar(cmd); if cmdNome then controles.tirar(cmdNome) end
    S.ligou = { texto = "Sem teclas: " .. titulo, ate = reaper.time_precise() + 3 }
  end)
  item("Voltar as teclas do computador ao padrão", function()
    controles.teclasPadrao(); S.ligou = { texto = "Teclas do computador de volta ao padrão.", ate = reaper.time_precise() + 3 }
  end)
  gfx.x, gfx.y = gfx.mouse_x, gfx.mouse_y
  local r = gfx.showmenu(table.concat(itens, "|"))
  if acoes[r] then acoes[r]() end
end

-- Partes corrigidas no REAPER → app (e o caminho de volta) ------------------------------------------
local function avisarTudo(t, hex)
  aviso(t, hex)
  S.avisoAoVivo = { texto = t, cor = hex, ate = reaper.time_precise() + 8 }
end

--- Envia as partes das músicas que mudaram aqui. Pergunta antes se alguém mudou no app nesse meio-tempo.
local function enviarPartes()
  S.enviarPartes = false
  if not nuvem.userId() then avisarTudo("Entre na sua conta para enviar as partes.", C.warn) return end
  local lista = partes.mudadas(aovivo.estado.musicas)
  if #lista == 0 then avisarTudo("As partes daqui já estão iguais às do app.", C.ok) return end
  local feitas, erro = {}, nil
  for _, x in ipairs(lista) do
    local titulo = x.info.titulo or x.m.nome
    if partes.mudouNaNuvem(x.n) then
      local r = reaper.ShowMessageBox("Alguém mudou as partes de \"" .. titulo .. "\" no app depois que você montou aqui.\n\n" ..
        "Enviar mesmo assim troca as partes do app pelas daqui. Continuar?", "LS Live", 4)
      if r ~= 6 then goto proxima end
    end
    do
      local ok, e = partes.enviar(x.n, x.m)
      if ok then feitas[#feitas + 1] = titulo else erro = e; break end
    end
    ::proxima::
  end
  S.partesMudadas = partes.mudadas(aovivo.estado.musicas)
  if erro then avisarTudo("Não enviou: " .. erro, C.bad)
  elseif #feitas > 0 then avisarTudo("Partes enviadas para o app: " .. table.concat(feitas, ", ") .. ". Já aparecem no app e no site.", C.ok) end
end
T.enviarPartes = enviarPartes

--- Troca as regiões pelas partes do app (só a música atual, ou todas).
local function atualizarPartes(todas)
  if not nuvem.userId() then avisarTudo("Entre na sua conta para buscar as partes.", C.warn) return end
  local E = aovivo.estado
  local mi = aovivo.onde()
  local alvos = {}
  for n, m in ipairs(E.musicas) do if todas or n == mi then alvos[#alvos + 1] = n end end
  local mudadasAqui = {}
  for _, x in ipairs(partes.mudadas(E.musicas)) do mudadasAqui[x.n] = true end
  for _, n in ipairs(alvos) do
    if mudadasAqui[n] then
      local r = reaper.ShowMessageBox("Você mudou as partes de \"" .. (E.musicas[n].nome:gsub("^%d+%. ", "")) .. "\" aqui e ainda não enviou.\n\n" ..
        "Atualizar pela nuvem troca as daqui pelas do app. Continuar?", "LS Live", 4)
      if r ~= 6 then return end
    end
  end
  local n0, erro = 0, nil
  for i = #alvos, 1, -1 do   -- de trás para frente: apagar regiões não mexe nas músicas anteriores
    local n = alvos[i]
    local ok, e = partes.atualizar(n, aovivo.ler()[n])
    if ok then n0 = n0 + 1 else erro = e end
  end
  local lidas = aovivo.ler()
  for _, n in ipairs(alvos) do if lidas[n] then partes.marcarAqui(n, lidas[n]) end end
  S.partesMudadas = partes.mudadas(lidas)
  if erro then avisarTudo("Não atualizou: " .. erro, C.bad) else avisarTudo("Partes atualizadas pela nuvem (" .. n0 .. " música(s)).", C.ok) end
end
T.atualizarPartes = atualizarPartes


T.menuLigar = menuLigar

--- Tecla do computador no ao vivo: ligar (se esperando), cancelar (Esc) ou executar.
local function teclaAoVivo(ch)
  if ch <= 0 then return end
  if S.esperandoTecla then
    if ch ~= 27 then
      controles.ligarTecla(ch, S.esperandoTecla)
      S.ligou = { texto = controles.nomeTecla(ch) .. " → " .. nomeDoComando(S.esperandoTecla), ate = reaper.time_precise() + 4 }
    end
    S.esperandoTecla = nil
  elseif ch == 27 and (controles.aprendendo or S.aprenderModo) then
    controles.aprendendo = nil; S.aprenderModo = false
  elseif controles.TECLAS[ch] then
    executar(controles.TECLAS[ch])
  end
end
T.teclaAoVivo = teclaAoVivo

--- Recado do ao vivo (esperando tecla/pad, ligação feita, aviso da montagem). Sem recado: dica em cinza (só na janela inteira).
local function recadoAoVivo()
  local agora = reaper.time_precise()
  if S.esperandoTecla then return "Aperte a tecla do computador para " .. nomeDoComando(S.esperandoTecla) .. "   ·   Esc cancela", C.warn end
  if controles.aprendendo then return "Aperte o pad ou botão do controlador para " .. nomeDoComando(controles.aprendendo) .. "   ·   Esc cancela", C.warn end
  if S.aprenderModo then return "Ligar controlador: clique num quadradinho ou botão e depois aperte o pad   ·   Esc sai", C.warn end
  if S.editOrdem then return "Ordem: toque nas partes na ordem em que a banda vai tocar. Toque num número da ordem para tirar.", C.warn end
  if S.dicaTrava and agora - S.dicaTrava < 2.5 then return "Trava ligada: segure o botão meio segundo para confirmar (dá para desligar em Configurações › Ao vivo).", C.warn end
  if controles.ligou and agora < controles.ligou.ate then return "Ligado: " .. controles.ligou.texto, C.ok end
  if S.ligou and agora < S.ligou.ate then return S.ligou.texto, C.ok end
  if S.avisoAoVivo and agora < S.avisoAoVivo.ate then return S.avisoAoVivo.texto, S.avisoAoVivo.cor end
  local mud = S.partesMudadas or {}
  if #mud > 0 then
    local t = mud[1].info.titulo or mud[1].m.nome
    return "Você mudou as partes de \"" .. t .. "\"" .. (#mud > 1 and (" e de mais " .. (#mud - 1) .. " música(s)") or "") ..
      ". Envie para atualizar o app.", C.warn, true
  end
end

local function faixaAoVivo(dica)
  local s, hex, comBotao = recadoAoVivo()
  if not s and dica then s, hex = dica, C.muted end
  if not s then return end
  local h = compacto() and 26 or 30
  cor(C.bg); R(0, VH - h, VW, h, 1)
  cor(C.line); R(0, VH - h, VW, 1, 1)
  if hex ~= C.muted then cor(hex); CI(18, VH - h / 2, 3.5, 1, 1) end
  local larg = VW - 48
  if comBotao then
    local bw = largura("Enviar para o app", 6) + 28
    local bx, by, bh = VW - 8 - bw, VH - h + 3, h - 6
    local sobre = dentro(bx, by, bw, bh)
    cor(C.accent, sobre and 0.85 or 1); retangulo(bx, by, bw, bh, bh / 2)
    centro("Enviar para o app", bx, by, bw, bh, 6, C.onAccent)
    if sobre and mouse.clicked then S.enviarPartes = true end
    larg = bx - 40
  end
  texto(cortar(s, 2, larg), hex ~= C.muted and 30 or 16, VH - h + (h - 15) / 2, 2, hex)
end

-- Cor da parte misturada no painel (t = 0 painel, 1 cor pura).
local function misturar(n, t, base)
  local r, g, b = reaper.ColorFromNative(n & 0xFFFFFF)
  local br, bg, bb = 0x0A, 0x26, 0x3A
  if base then br, bg, bb = base[1], base[2], base[3] end
  gfx.set((br + (r - br) * t) / 255, (bg + (g - bg) * t) / 255, (bb + (b - bb) * t) / 255, 1)
end

--- Teclinha com o nome da tecla/pad. Devolve a largura.
local function teclinha(s, x, y, sobreCor)
  fonte(2)
  local w = largura(s, 2) + 12
  if type(sobreCor) == "number" then misturar(sobreCor, 0.5, FUNDO) elseif sobreCor then cor(C.accent, 0.55) else cor(C.bg) end
  retangulo(x, y, w, 19, 5)
  texto(s, x + 6, y + 2, 2, sobreCor and C.hi or C.text)
  return w
end

local function tempo(s) s = math.max(0, s) return string.format("%d:%02d", math.floor(s / 60), math.floor(s % 60)) end

--- Nome da música sem o número e o tom separado: "1. Bondade de Deus  [G]" → "Bondade de Deus", "G".
local function tituloETom(nome)
  local t = nome:gsub("^%d+%. ", "")
  local tom = t:match("%[(.-)%]%s*$")
  return (t:gsub("%s*%[.-%]%s*$", "")), tom
end

--- Mapa da música: as partes em sequência, do tamanho de cada uma, com o cursor andando. Clicar = escolher a parte.
local function mapaDaMusica(m, pi, pos, x, y, w, h, E, comNomes)
  local dur = math.max(0.01, m.fim - m.ini)
  cor(C.panel); retangulo(x, y, w, h, math.min(8, h / 2))
  for k, p in ipairs(m.partes) do
    local px = x + (p.ini - m.ini) / dur * w
    local pw = math.max(3, (p.fim - p.ini) / dur * w - 3)
    local atual = k == pi
    local naFila = E.fila and E.fila.idx == p.idx
    local sobre = dentro(px, y, pw, h)
    misturar(p.cor, atual and 1 or (sobre and 0.55 or 0.38))
    retangulo(px, y, pw, h, math.min(6, h / 2))
    if naFila and pisca < 18 then cor(C.hi); RR(px - 1, y - 1, pw + 1, h + 1, math.min(6, h / 2), 1) end
    if comNomes and pw > 46 then centro(cortar(p.nome, 2, pw - 10), px, y, pw, h, 2, atual and C.onAccent or C.hi) end
    toque("p" .. k, px, y, pw, h)
    ligavel(px, y, pw, h, "p" .. k)
  end
  if pos >= m.ini and pos <= m.fim then
    local cx = x + (pos - m.ini) / dur * w
    cor(C.hi); R(cx - 1, y - 3, 2, h + 6, 1)
  end
end

--- Um quadradinho de parte. O que está tocando se enche da esquerda para a direita conforme a parte anda.
local function quadradinho(k, parte, x, y, w, h, atual, naFila, repetindo, f, pos)
  local raio = math.min(16, h * 0.2)
  local sobre = dentro(x, y, w, h)
  if atual then
    misturar(parte.cor, 0.62); retangulo(x, y, w, h, raio)
    local fr = math.max(0, math.min(1, (pos - parte.ini) / math.max(0.01, parte.fim - parte.ini)))
    if w * fr >= raio * 2 then corNativa(parte.cor); retangulo(x, y, w * fr, h, raio) end
  else
    misturar(parte.cor, sobre and 0.30 or 0.18); retangulo(x, y, w, h, raio)
    corNativa(parte.cor); retangulo(x + 12, y + h - 6, w - 24, 3, 1.5)
  end
  if naFila and pisca < 18 then cor(C.hi); for t = 1, 2 do RR(x - t, y - t, w + 2 * t - 1, h + 2 * t - 1, raio + t, 1) end end
  local escuro = atual and C.onAccent or nil
  local rot = controles.rotulo("p" .. k, 2)
  local rotN = controles.rotulo("n:" .. parte.nome, 2)
  if rotN ~= "" then rot = rot ~= "" and (rot .. " · " .. rotN) or rotN end
  local chip = h >= 44 and rot ~= ""
  if chip then teclinha(cortar(rot, 2, w - 30), x + 8, y + 8, atual and parte.cor or nil) end
  if atual and repetindo and h >= 44 then icone("repetir", x + w - 20, y + 18, 16, C.onAccent) end
  local rodape = h >= 74 and naFila
  centro(cortar(parte.nome, f, w - 16), x, y + (chip and 6 or 0), w, h - (rodape and 20 or 0), f, escuro or C.hi)
  if rodape then centro("na fila", x, y + h - 30, w, 18, 2, C.warn) end
  toque("p" .. k, x, y, w, h)
  ligavel(x, y, w, h, "p" .. k)
end

--- Distribui n quadradinhos na área (colunas e linhas que melhor cabem). Devolve cols, pw, ph.
local function grade(n, W, H, gap, proporcao, hMax)
  local melhor, bc, bw, bh = -1, 1, W, H
  for cols = 1, math.max(1, n) do
    local rows = math.ceil(n / cols)
    local pw = (W - gap * (cols - 1)) / cols
    local ph = math.min(hMax, (H - gap * (rows - 1)) / rows)
    local nota = math.min(pw / proporcao, ph)
    if nota > melhor + 0.5 then melhor, bc, bw, bh = nota, cols, pw, ph end
  end
  return bc, bw, bh
end

--- Botão do transporte: ícone em cima, nome embaixo e a teclinha. Botão direito liga outra tecla.
local function botaoTransporte(ic, rotulo, cmd, x, y, w, h, ligado)
  local sobre = dentro(x, y, w, h)
  if ligado then cor(C.accent, sobre and 0.85 or 1) else cor(sobre and C.sel or C.panel) end
  retangulo(x, y, w, h, 16)
  local hex = ligado and C.onAccent or C.text
  icone(ic, x + w / 2, y + 22, 20, hex)
  centro(cortar(rotulo, 6, w - 12), x, y + 36, w, 20, 6, hex)
  local rot = controles.rotulo(cmd, 1)
  if rot ~= "" and h >= 76 then
    fonte(2); local tw = largura(rot, 2) + 12
    teclinha(rot, x + (w - tw) / 2, y + h - 25, ligado)
  end
  toque(cmd, x, y, w, h)
  ligavel(x, y, w, h, cmd)
end

--- O que está para acontecer (fila, final, parar, suave), em texto e cor; nil se nada.
local function statusAoVivo(E, p, pos)
  if E.suave then return "Parando devagar…", C.warn end
  if E.fila and E.filaFinal then return "Final: vai para " .. E.fila.nome .. " no fim desta parte", C.warn end
  if E.fila then return "Próxima: " .. E.fila.nome .. " · no fim desta parte", C.warn end
  if E.pararEm then return E.final and "Final: para no fim desta parte" or "Fim da ordem: para no fim desta parte", C.warn end
  if E.repetir then return "Repetindo esta parte", C.accent end
end

--- Grupo − valor + (tom, andamento). Os botões − e + aceitam botão direito para ligar tecla/pad.
local function grupoAjuste(x, y, w, h, rotulo, cmdMenos, cmdMais, mudado)
  cor(C.panel); retangulo(x, y, w, h, h / 2)
  for i, c in ipairs({ cmdMenos, cmdMais }) do
    local bx = i == 1 and x or x + w - h
    if dentro(bx, y, h, h) then cor(C.sel); retangulo(bx, y, h, h, h / 2) end
    centro(i == 1 and "−" or "+", bx, y - 1, h, h, 4, C.accent)
    toque(c, bx, y, h, h)
    ligavel(bx, y, h, h, c)
  end
  centro(cortar(rotulo, 6, w - 2 * h - 4), x + h, y, w - 2 * h, h, 6, mudado and C.accent or C.hi)
end

--- Linha da ordem: os passos em selos (o atual em azul). Editando: tocar num selo tira o passo.
local function linhaOrdem(mi, m, x, y, w, h)
  local nomes = ordem.nomes(mi)
  local editando = S.editOrdem == mi
  fonte(2)
  texto(editando and "Nova ordem:" or (ordem.ligada() and "Ordem:" or "Ordem (desligada):"), x, y + (h - 15) / 2, 2, editando and C.warn or C.muted)
  local cx = x + largura(editando and "Nova ordem:" or (ordem.ligada() and "Ordem:" or "Ordem (desligada):"), 2) + 10
  local fimX = x + w
  if editando then
    local bw = 86
    if botao("Pronto", fimX - bw, y, bw, h, "primario") then S.editOrdem = nil end
    if botao("Limpar", fimX - 2 * bw - 8, y, bw, h, "secundario") then ordem.salvar(mi, {}) end
    fimX = fimX - 2 * bw - 20
  end
  if #nomes == 0 then texto(editando and "toque nas partes abaixo…" or "", cx, y + (h - 15) / 2, 2, C.muted) return end
  local passo = (not editando) and aovivo.passoDaOrdem() or nil
  local seq = aovivo.sequencia(mi)
  -- começa um pouco antes do passo atual, para ele sempre aparecer
  local ini = 1
  if passo then
    local larg = 0
    for j = passo, math.max(1, passo - 6), -1 do
      larg = larg + largura(j .. " " .. nomes[j], 2) + 22
      if larg > (fimX - cx) * 0.45 then break end
      ini = j
    end
  end
  if ini > 1 then texto("…", cx, y + (h - 15) / 2, 2, C.muted); cx = cx + 16 end
  for j = ini, #nomes do
    local t = j .. " " .. nomes[j]
    local tw = largura(t, 2) + 16
    if cx + tw > fimX then texto("…", cx, y + (h - 15) / 2, 2, C.muted) break end
    local on = passo == j
    local sobre = dentro(cx, y, tw, h)
    local cnat = seq[j] and m.partes[seq[j]] and m.partes[seq[j]].cor
    if on then cor(C.accent) elseif cnat then misturar(cnat, sobre and 0.5 or 0.3, FUNDO) else cor(C.control) end
    retangulo(cx, y, tw, h, h / 2)
    centro(t, cx, y, tw, h, 2, on and C.onAccent or C.hi)
    if editando and sobre and mouse.clicked then table.remove(nomes, j); ordem.salvar(mi, nomes); return end
    cx = cx + tw + 6
  end
end

--- Menu do botão Ordem: editar, ligar/desligar, apagar.
local function menuOrdem(mi)
  local tem = #ordem.nomes(mi) > 0
  if not tem then S.editOrdem = mi return end
  local itens = { "Editar a ordem desta música", (ordem.ligada() and "!" or "") .. "Seguir a ordem (todas as músicas)", "Apagar a ordem desta música" }
  gfx.x, gfx.y = gfx.mouse_x, gfx.mouse_y
  local r = gfx.showmenu(table.concat(itens, "|"))
  if r == 1 then S.editOrdem = mi
  elseif r == 2 then executar("ordem")
  elseif r == 3 then ordem.salvar(mi, {}) end
end

-- Ao vivo compacto: uma barra de comando em cima, o mapa da música e os quadradinhos embaixo (cabem todos).
local function telaAoVivoMini()
  local E = aovivo.estado
  if #E.musicas == 0 then aovivo.ler() end
  local pos = aovivo.posicao()
  local mi, pi, m, p = aovivo.onde(pos)
  cor(C.bg); R(0, 0, VW, VH, 1)
  local y, h = 8, 46
  local tocando = aovivo.tocando()
  local sobreT = dentro(8, y, 58, h)
  cor(C.accent, sobreT and 0.85 or 1); retangulo(8, y, 58, h, 14)
  icone(tocando and "parar" or "tocar", 37, y + h / 2, 22, C.onAccent)
  toque("tocar", 8, y, 58, h)
  ligavel(8, y, 58, h, "tocar")
  -- direita: janela, música ◀ ▶, repetir
  local dir = botoesJanela(VW - 8, y + 5, 36) + 4
  local bw = 44
  dir = dir - bw
  botaoIcone("musica+", dir, y, bw, h, "secundario"); toque("musica+", dir, y, bw, h)
  ligavel(dir, y, bw, h, "musica+")
  dir = dir - bw - 6
  botaoIcone("musica-", dir, y, bw, h, "secundario"); toque("musica-", dir, y, bw, h)
  ligavel(dir, y, bw, h, "musica-")
  local rw = 112
  dir = dir - rw - 6
  local sobre = dentro(dir, y, rw, h)
  if E.repetir then cor(C.accent, sobre and 0.85 or 1) else cor(sobre and C.sel or C.control) end
  retangulo(dir, y, rw, h, 14)
  local ich = E.repetir and C.onAccent or C.text
  icone("repetir", dir + 24, y + h / 2, 20, ich)
  texto("Repetir", dir + 42, y + (h - 17) / 2, 6, ich)
  toque("repetir", dir, y, rw, h)
  ligavel(dir, y, rw, h, "repetir")
  -- meio: música e parte
  local x, infoW = 78, dir - 78 - 12
  if m then
    local titulo = tituloETom(m.nome)
    local soa = tom.soando(mi)
    texto(cortar(titulo .. (soa and ("  ·  " .. soa) or ""), 6, infoW), x, y + 3, 6, C.hi)
    local linha, hex = "", C.muted
    local st, sth = statusAoVivo(E, p, pos)
    if st then linha, hex = st, sth
    elseif p then
      linha = p.nome .. " · faltam " .. tempo(p.fim - pos)
      if E.repetir then linha = linha .. " · repetindo"; hex = C.accent end
    else linha = mi .. " de " .. #E.musicas end
    texto(cortar(linha, 2, infoW), x, y + 26, 2, hex)
  else
    texto("Sem músicas montadas neste projeto.", x, y + 14, 1, C.muted)
  end
  if not m then faixaAoVivo() return end
  pisca = (pisca + 1) % 30
  -- mapa da música (fino)
  local my = y + h + 8
  mapaDaMusica(m, pi, pos, 8, my, VW - 16, 8, E, false)
  -- quadradinhos
  local top = my + 16
  local H = VH - top - (recadoAoVivo() and 32 or 8)
  local cols, pw, ph = grade(#m.partes, VW - 16, H, 6, 1.6, 96)
  for k, parte in ipairs(m.partes) do
    local c, r = (k - 1) % cols, math.floor((k - 1) / cols)
    quadradinho(k, parte, 8 + c * (pw + 6), top + r * (ph + 6), pw, ph, k == pi, E.fila and E.fila.idx == parte.idx,
      E.repetir, ph >= 44 and 6 or 2, pos)
  end
  faixaAoVivo()
end

--- Marca uma parte no lugar do cursor (pergunta o nome). Também pela tecla M.
function T.marcarParteAqui()
  local pos = aovivo.posicao()
  local _, _, m = aovivo.onde(pos)
  if not m then return end
  local ok, nome = reaper.GetUserInputs("LS Live · Marcar parte aqui", 1, "Nome da parte (ex.: Refrão),extrawidth=120", "")
  if not ok then return end
  local okM, e = partes.marcarParte(m, pos, nome)
  aovivo.ler()
  if okM then S.ligou = { texto = "Parte \"" .. nome .. "\" marcada. Para levar ao app: Enviar para o app.", ate = reaper.time_precise() + 5 }
  else S.ligou = nil; S.avisoAoVivo = { texto = e, cor = C.bad, ate = reaper.time_precise() + 4 } end
end

local function telaAoVivo()
  if compacto() then return telaAoVivoMini() end
  local E = aovivo.estado
  if #E.musicas == 0 then aovivo.ler() end
  local pos = aovivo.posicao()
  local mi, pi, m, p = aovivo.onde(pos)
  -- cabeçalho: voltar, música (grande) com o tom, e a seguinte
  if botaoIcone("voltar", 16, 20, 40, 40, "secundario") then T.sairDoAoVivo() end
  local xFim = botoesJanela(VW - 16, 22, 36)
  if not m then centro("Este projeto não tem músicas montadas pelo LS Live.", 0, 80, VW, VH - 80, 1, C.muted) return end
  local lw = S.aprenderModo and 96 or 168
  if botao(S.aprenderModo and "Pronto" or "Ligar controlador", xFim - lw, 22, lw, 36, S.aprenderModo and "primario" or "secundario") then
    controles.aprendendo = nil
    S.aprenderModo = not S.aprenderModo
  end
  -- Ordem e Pad (liga/desliga)
  local temOrdem = #ordem.nomes(mi) > 0
  local ow, pw0 = 96, 76
  local ox = xFim - lw - 8 - ow
  if botao(S.editOrdem and "Ordem…" or "Ordem", ox, 22, ow, 36, (temOrdem and ordem.ligada() or S.editOrdem) and "primario" or "secundario") then
    if S.editOrdem then S.editOrdem = nil else menuOrdem(mi) end
  end
  local px0 = ox - 8 - pw0
  if botao("Pad", px0, 22, pw0, 36, pad.ligado() and "primario" or "secundario") then executar("pad") end
  ligavel(px0, 22, pw0, 36, "pad")
  local titulo = tituloETom(m.nome)
  local maxT = px0 - 16 - 72
  titulo = cortar(titulo, 5, math.max(80, maxT))
  texto(titulo, 72, 12, 5, C.hi)
  -- tom e andamento desta música (− +), e o atalho para o tom do dia
  local aj = tom.ajuste(mi)
  local soa = tom.soando(mi)
  local rotTom = soa and ("Tom " .. soa) or (aj.semi == 0 and "Tom" or ("Tom " .. (aj.semi > 0 and "+" or "") .. aj.semi))
  if soa and aj.semi ~= 0 then rotTom = rotTom .. " (" .. (aj.semi > 0 and "+" or "") .. aj.semi .. ")" end
  local bpm = tom.bpm(mi, m)
  local rotBpm = bpm and (math.floor(bpm + 0.5) .. " BPM") or (math.floor(aj.taxa * 100 + 0.5) .. "%")
  local gw, gh, gy = 168, 30, 64
  local gx = xFim - gw
  grupoAjuste(gx, gy, gw, gh, rotBpm, "bpm-", "bpm+", math.abs(aj.taxa - 1) > 0.001)
  gx = gx - 8 - gw
  grupoAjuste(gx, gy, gw, gh, rotTom, "tom-", "tom+", aj.semi ~= 0)
  local dDia = tom.paraOTomDoDia(mi)
  if dDia then
    local _, dia = tom.tons(mi)
    local t = "Tom do dia: " .. dia
    local tw = largura(t, 6) + 26
    gx = gx - 8 - tw
    if botao(t, gx, gy, tw, gh, "secundario") then executar("tomdia") end
  end
  local prox = E.musicas[mi + 1]
  texto(cortar("Música " .. mi .. " de " .. #E.musicas .. (prox and ("   ·   Depois: " .. tituloETom(prox.nome)) or ""), 1, gx - 72 - 12),
    72, 56, 1, C.muted)
  pisca = (pisca + 1) % 30
  -- mapa da música
  local my = 106
  local mw = VW - 40 - 170
  mapaDaMusica(m, pi, pos, 20, my, mw, 30, E, true)
  if botao("+ Marcar parte", 20 + mw + 10, my, 160, 30, "secundario") then executar("marcar") end
  ligavel(20 + mw + 10, my, 160, 30, "marcar")
  -- linha da parte: nome e quanto falta | fila ou repetindo
  local iy = my + 40
  if p then
    texto(p.nome, 20, iy, 6, C.hi)
    texto("faltam " .. tempo(p.fim - pos), 20 + largura(p.nome, 6) + 10, iy + 1, 1, C.muted)
  end
  local s, hex = statusAoVivo(E, p, pos)
  if not s and ordem.ligada() and aovivo.passoDaOrdem() then
    local seq = aovivo.sequencia(mi)
    local prox = seq[aovivo.passoDaOrdem() + 1]
    if prox and m.partes[prox] then s, hex = "Pela ordem, depois vem: " .. m.partes[prox].nome, C.muted end
  end
  if s then s = cortar(s, 6, VW * 0.5); texto(s, VW - 20 - largura(s, 6), iy, 6, hex) end
  -- ordem das partes (se a música tem, ou se está editando)
  local y0, gap = iy + 34, 12
  if S.editOrdem and S.editOrdem ~= mi then S.editOrdem = nil end
  if S.editOrdem or #ordem.nomes(mi) > 0 then
    linhaOrdem(mi, m, 20, y0 - 2, VW - 40, 28)
    y0 = y0 + 36
  end
  -- quadradinhos (todos cabem: diminuem se forem muitos)
  local tH = 104
  local yT = VH - 30 - 14 - tH
  local cols, pw, ph = grade(#m.partes, VW - 40, yT - 18 - y0, gap, 1.7, 150)
  for k, parte in ipairs(m.partes) do
    local c, r = (k - 1) % cols, math.floor((k - 1) / cols)
    quadradinho(k, parte, 20 + c * (pw + gap), y0 + r * (ph + gap), pw, ph, k == pi, E.fila and E.fila.idx == parte.idx,
      E.repetir, ph >= 64 and 4 or 6, pos)
  end
  -- transporte: Tocar redondo no meio; começo da parte e música anterior à esquerda; repetir e próxima à direita
  cor(C.line); R(20, yT - 10, VW - 40, 1, 1)
  local cx, cyT, raio = VW / 2, yT + tH / 2, 44
  local tocando = aovivo.tocando()
  local sobre = (mouse.x - cx) ^ 2 + (mouse.y - cyT) ^ 2 <= raio ^ 2
  cor(C.accent, sobre and 0.85 or 1); CI(cx, cyT, raio, 1, 1)
  icone(tocando and "parar" or "tocar", cx + (tocando and 0 or 3), cyT, 34, C.onAccent)
  toque("tocar", cx - raio, cyT - raio, raio * 2, raio * 2)
  if mouse.rclicked and sobre then S.menuPara = "tocar" end
  local rotT = controles.rotulo("tocar", 1)
  if rotT ~= "" then fonte(2); local tw = largura(rotT, 2) + 12; teclinha(rotT, cx - tw / 2, cyT + raio + 2, false) end
  local bwT = math.min(150, (VW / 2 - raio - 20 - 20 - 2 * 10) / 3)
  local xl = cx - raio - 20 - bwT
  botaoTransporte("inicio", "Começo da parte", "inicio", xl, yT, bwT, tH - 10, false)
  botaoTransporte("suave", E.suave and "Parando…" or "Parar suave", "suave", xl - 10 - bwT, yT, bwT, tH - 10, E.suave ~= nil)
  botaoTransporte("musica-", "Música anterior", "musica-", xl - 2 * (10 + bwT), yT, bwT, tH - 10, false)
  local xr = cx + raio + 20
  botaoTransporte("repetir", E.repetir and "Repetindo" or "Repetir parte", "repetir", xr, yT, bwT, tH - 10, E.repetir)
  botaoTransporte("final", "Final", "final", xr + bwT + 10, yT, bwT, tH - 10, E.final)
  botaoTransporte("musica+", "Próxima música", "musica+", xr + 2 * (bwT + 10), yT, bwT, tH - 10, false)
  faixaAoVivo("Dica: clique com o botão direito num quadradinho ou botão para ligar uma tecla ou um pad do controlador.")
end

-- Configurações -------------------------------------------------------------------------------------
local ABAS = { { "geral", "Geral" }, { "aovivo", "Ao vivo e celular" }, { "saidas", "Saídas de áudio" }, { "faixas", "Faixas" },
  { "partes", "Partes" }, { "conferencia", "Antes do culto" } }

--- Interruptor (liga/desliga). Devolve true no clique.
local function interruptor(x, y, ligado)
  local w, h = 52, 30
  local sobre = dentro(x, y, w, h)
  if ligado then cor(C.accent, sobre and 0.85 or 1) else cor(sobre and C.sel or C.control) end
  retangulo(x, y, w, h, h / 2)
  cor(ligado and C.onAccent or C.muted)
  CI(ligado and (x + w - h / 2) or (x + h / 2), y + h / 2, h / 2 - 5, 1, 1)
  return sobre and mouse.clicked
end

--- Selo clicável (escolha de um menu). Devolve true no clique.
local function selo(t, x, y, w, h, hex, vazio)
  local sobre = dentro(x, y, w, h)
  cor(sobre and C.sel or (vazio and C.bg or C.control)); retangulo(x, y, w, h, 10)
  if vazio then cor(C.line); RR(x, y, w - 1, h - 1, 10, 1) end
  texto(cortar(t, 6, w - 36), x + 12, y + (h - 17) / 2, 6, hex or C.text)
  -- setinha
  local cx, cy = x + w - 18, y + h / 2
  gfx.triangle((cx - 5) * ESC, (cy - 2) * ESC, (cx + 5) * ESC, (cy - 2) * ESC, cx * ESC, (cy + 4) * ESC)
  return sobre and mouse.clicked
end

--- Menu do REAPER no lugar do mouse. itens = { {texto, valor} | "-" }. Devolve o valor escolhido (ou nil).
local function escolher(itens)
  local partes_, valores = {}, {}
  for _, it in ipairs(itens) do
    if type(it) == "table" then partes_[#partes_ + 1] = it[1]:gsub("|", "/"); valores[#partes_] = it[2] end
  end
  gfx.x, gfx.y = gfx.mouse_x, gfx.mouse_y
  local r = gfx.showmenu(table.concat(partes_, "|"))
  return valores[r]
end

--- Linha de configuração: título e explicação à esquerda; devolve o x onde o controle da direita termina.
local function linhaConfig(y, h, titulo, explica)
  cor(C.panel); retangulo(24, y, VW - 48, h, 16)
  texto(titulo, 44, y + 14, 6, C.hi)
  if explica then texto(cortar(explica, 2, VW - 420), 44, y + 38, 2, C.muted) end
  return VW - 44
end

local cfgSaidas = nil
local function cfg()
  cfgSaidas = cfgSaidas or saidas.carregar()
  return cfgSaidas
end
--- Grava e já aplica nas faixas deste projeto (se houver).
local function mudouSaidas()
  saidas.salvar(cfgSaidas)
  if #saidas.faixas() > 0 then S.saidasAplicadas = saidas.aplicar(cfgSaidas) end
end

local function abaGeral(y)
  local h, gap = 60, 8
  -- abrir junto
  local xr = linhaConfig(y, h, "Abrir junto com o REAPER", "A janela do LS Live abre sozinha quando você abre o REAPER.")
  local on = instalar.inicioLigado()
  if interruptor(xr - 52, y + (h - 30) / 2, on) then
    local _, e = instalar.alternarInicio()
    if e then aviso(e, C.bad) end
  end
  y = y + h + gap
  -- botão na barra
  xr = linhaConfig(y, h, "Botão na barra do REAPER", "Uma barrinha com o ícone do LS Live. Um clique abre esta janela.")
  local inst = instalar.botaoInstalado()
  local bw = 190
  if botao(inst and "Mostrar a barrinha" or "Pôr o botão", xr - bw, y + (h - 38) / 2, bw, 38, inst and "secundario" or "primario") then
    local ok, e = instalar.instalarBotao()
    aviso(ok and "Pronto: a barrinha com o ícone está aberta. Arraste para onde quiser." or e, ok and C.ok or C.bad)
  end
  if inst then cor(C.ok); CI(xr - bw - 24, y + h / 2, 4, 1, 1); texto("instalado", xr - bw - 96, y + h / 2 - 8, 2, C.ok) end
  y = y + h + gap
  -- atalho
  local at = instalar.atalho()
  xr = linhaConfig(y, h, "Atalho para abrir", at and ("Hoje: " .. at .. " (funciona em qualquer lugar do REAPER)") or "Nenhum atalho ainda.")
  if botao("Trocar", xr - 120, y + (h - 38) / 2, 120, 38, "secundario") then instalar.trocarAtalho() end
  y = y + h + gap
  -- teclas do ao vivo
  xr = linhaConfig(y, h, "Teclas do ao vivo", "1 a 0 = partes · Espaço = tocar · R = repetir · E = final · S = parar suave · P = pad · ↑ ↓ = música. Botão direito liga outra tecla.")
  if botao("Voltar ao padrão", xr - 170, y + (h - 38) / 2, 170, 38, "secundario") then
    controles.teclasPadrao(); aviso("Teclas do ao vivo de volta ao padrão.", C.ok)
  end
  y = y + h + gap
  -- versão
  xr = linhaConfig(y, h, "Versão do LS Live", S.versaoNova and ("Você tem a " .. instalar.VERSAO .. ". Já saiu a " .. S.versaoNova .. ".")
    or ("Você tem a " .. instalar.VERSAO .. "."))
  if S.versaoNova then
    if botao("Atualizar agora", xr - 170, y + (h - 38) / 2, 170, 38, "primario") then
      aviso("Baixando a versão nova…")
      local ok, e = instalar.atualizar()
      if ok then
        S.versaoNova = nil
        aviso("Pronto! Feche a janela do LS Live e abra de novo para usar a versão nova.", C.ok)
        reaper.ShowMessageBox("O LS Live foi atualizado.\n\nFeche a janela do LS Live e abra de novo para usar a versão nova.", "LS Live", 0)
      else aviso(e, C.bad) end
    end
  elseif botao("Procurar atualização", xr - 190, y + (h - 38) / 2, 190, 38, "secundario") then
    local ok, v = pcall(instalar.verificarVersao, true)
    S.versaoNova = ok and v or nil
    aviso(S.versaoNova and ("Saiu a versão " .. S.versaoNova .. ".") or "Você já está com a versão mais nova.", S.versaoNova and C.warn or C.ok)
  end
  y = y + h + gap
  -- conta
  xr = linhaConfig(y, h, "Conta", nuvem.email() and ("Entrou como " .. nuvem.email()) or "Você não entrou.")
  if nuvem.email() and botao("Sair da conta", xr - 150, y + (h - 38) / 2, 150, 38, "perigo") then
    nuvem.sair(); S.tela = "entrar"; aviso(nil)
  end
end

local function abaAoVivo(y)
  local h, gap = 56, 8
  -- celular
  local porta = remoto.porta()
  local url = remoto.endereco()
  local conectado = remoto.celularConectado()
  local explica
  if porta and url then
    explica = (conectado and "Celular conectado. " or "") .. "No celular, no mesmo Wi-Fi do computador, abra: " .. url
  elseif porta then
    explica = "Ligado. Conecte o computador ao Wi-Fi (ou cabo) da igreja para ver o endereço."
  else
    explica = "Use o celular como controle remoto, pela rede da igreja (sem instalar nada no celular)."
  end
  local xr = linhaConfig(y, h, "Controle pelo celular", explica)
  if not porta then
    if botao("Ligar", xr - 120, y + (h - 38) / 2, 120, 38, "primario") then
      local ok, e = remoto.ligar()
      if ok then
        remoto.instalarPagina()
        reaper.ShowMessageBox("Pronto. Feche o REAPER e abra de novo: o controle pelo celular começa a funcionar.\n\n" ..
          "Na primeira vez, o Windows pode perguntar se o REAPER pode usar a rede: clique em Permitir (redes privadas).\n\n" ..
          "Depois, aqui mesmo aparece o endereço para abrir no celular.", "LS Live", 0)
        aviso("Controle pelo celular ligado. Feche e abra o REAPER uma vez.", C.ok)
      else aviso(e, C.bad) end
    end
  elseif url then
    if botao("Abrir aqui", xr - 130, y + (h - 38) / 2, 130, 38, "secundario") then
      remoto.instalarPagina(); abrirLink("http://127.0.0.1:" .. porta .. "/lslive.html")
    end
    if conectado then cor(C.ok); CI(xr - 150, y + h / 2, 5, 1, 1) end
  end
  y = y + h + gap
  -- trava
  xr = linhaConfig(y, h, "Trava contra toque sem querer", "Tocando, os botões da tela pedem segurar meio segundo. Teclas, pads e celular, não.")
  if interruptor(xr - 52, y + (h - 30) / 2, reaper.GetExtState("LouvorStudio", "trava") == "1") then
    reaper.SetExtState("LouvorStudio", "trava", reaper.GetExtState("LouvorStudio", "trava") == "1" and "0" or "1", true)
  end
  y = y + h + gap
  -- luzes
  local saida = luzes.saida()
  xr = linhaConfig(y, h, "Acender os pads do controlador",
    saida and ("O pad da parte que está tocando acende (" .. (luzes.nomeSaida() or "controlador") .. ").")
      or "Para acender, ligue o controlador também como saída em Preferências › Áudio › Dispositivos MIDI.")
  if interruptor(xr - 52, y + (h - 30) / 2, luzes.ligado()) then luzes.alternar() end
  y = y + h + gap
  -- pad
  xr = linhaConfig(y, h, "Pad entre as músicas", "Com o REAPER parado, um som no tom da próxima música (faixa \"LS Pad\").")
  if interruptor(xr - 52, y + (h - 30) / 2, pad.ligado()) then executar("pad") end
  y = y + h + gap
  -- contagem
  xr = linhaConfig(y, h, "Contagem antes da música", "Um compasso de 1-2-3-4 no andamento da música, junto com o click (só no fone da banda).")
  if interruptor(xr - 52, y + (h - 30) / 2, contagem.ligada()) then
    local liga = not contagem.ligada()
    contagem.ligar(liga)
    if #aovivo.ler() > 0 then
      if liga then
        local n, sem = contagem.aplicar(aovivo.ler)
        aviso("Contagem posta em " .. n .. " música(s)" .. (#sem > 0 and (". Sem espaço antes de: " .. table.concat(sem, ", ")) or "."), #sem > 0 and C.warn or C.ok)
      else
        contagem.tirar(aovivo.estado.musicas); aviso("Contagem tirada deste projeto.", C.ok)
      end
    end
  end
  y = y + h + gap
  -- tela do ministro
  xr = linhaConfig(y, h, "Tela grande do ministro", "Uma janela só com a parte de agora, bem grande, e a próxima. Arraste para o segundo monitor ou a TV.")
  if botao("Abrir", xr - 120, y + (h - 38) / 2, 120, 38, "secundario") then
    local ok, e = instalar.abrirMinistro()
    if not ok then aviso(e, C.bad) end
  end
  y = y + h + gap
  -- ordem
  xr = linhaConfig(y, h, "Seguir a ordem das partes", "Se a música tem uma ordem (botão Ordem no ao vivo), o LS Live segue sozinho.")
  if interruptor(xr - 52, y + (h - 30) / 2, ordem.ligada()) then executar("ordem") end
end

local function nomeDoDestino(c, nome)
  if not nome or nome == saidas.MASTER then return "Master (sem saída direta)", C.muted end
  local _, porNome = saidas.destinos(c)
  local d = porNome[nome]
  if not d then return nome .. " (não existe mais)", C.warn end
  return nome .. "  ·  saída " .. saidas.canais(d), C.text
end

local function menuDestinos(c, extra)
  local itens = extra or {}
  for _, d in ipairs((saidas.destinos(c))) do itens[#itens + 1] = { d.nome .. "  (saída " .. saidas.canais(d) .. ")", d.nome } end
  itens[#itens + 1] = { "Master (sem saída direta)", saidas.MASTER }
  return escolher(itens)
end

local function abaSaidas(y)
  local c = cfg()
  local colW = (VW - 48 - 24) / 2
  local x1, x2 = 24, 24 + colW + 24
  local fimY = VH - (S.msg and 40 or 0) - 70
  -- esquerda: as saídas do computador e o nome de cada uma
  texto("Saídas do computador", x1, y, 6, C.hi)
  local placa = saidas.saidasDaPlaca()
  local n = math.max(#placa, 2)
  for k in pairs(c.nomes) do if k > n then n = k end end
  texto(#placa > 0 and ("A placa de som tem " .. #placa .. " saídas. Dê um nome a cada uma que você usa.")
    or "A placa de som está fechada no REAPER (Options › Preferences › Audio › Device).", x1, y + 22, 2, #placa > 0 and C.muted or C.warn)
  local ly, rh = y + 50, 40
  local cabem = math.max(1, math.floor((fimY - ly - 50) / (rh + 6)))
  S.scrollSaidas = math.max(0, math.min(S.scrollSaidas or 0, n - cabem))
  if mouse.roda ~= 0 and dentro(x1, ly, colW, cabem * (rh + 6)) then
    S.scrollSaidas = math.max(0, math.min(n - cabem, S.scrollSaidas - (mouse.roda > 0 and 1 or -1)))
  end
  for i = 1 + S.scrollSaidas, math.min(n, S.scrollSaidas + cabem) do
    local yy = ly + (i - 1 - S.scrollSaidas) * (rh + 6)
    cor(C.panel); retangulo(x1, yy, colW, rh, 12)
    cor(C.bg); retangulo(x1 + 6, yy + 6, 28, rh - 12, 8)
    centro(tostring(i), x1 + 6, yy + 6, 28, rh - 12, 6, C.accent)
    local nomePlaca = placa[i] and placa[i].nome or ("Saída " .. i)
    texto(cortar(nomePlaca, 2, colW * 0.42), x1 + 44, yy + 12, 2, C.muted)
    local nome = c.nomes[i]
    local sw = colW * 0.5
    if selo(nome or "Não usada", x1 + colW - sw - 6, yy + 4, sw, rh - 8, nome and C.hi or C.muted, not nome) then
      local itens = {}
      for _, s in ipairs(saidas.SUGESTOES) do itens[#itens + 1] = { (s == nome and "!" or "") .. s, s } end
      itens[#itens + 1] = { "Escrever outro nome…", "#outro" }
      itens[#itens + 1] = { "Não usar esta saída", "#nada" }
      local v = escolher(itens)
      if v == "#outro" then
        local ok, t = reaper.GetUserInputs("Nome da saída " .. i, 1, "Nome (termine com L ou R para par estéreo),extrawidth=120", nome or "")
        if ok and t:gsub("%s", "") ~= "" then c.nomes[i] = t:sub(1, 30); mudouSaidas() end
      elseif v == "#nada" then c.nomes[i] = nil; mudouSaidas()
      elseif v then c.nomes[i] = v; mudouSaidas() end
    end
  end
  if n > cabem then texto("role para ver as outras saídas", x1, ly + cabem * (rh + 6), 2, C.muted) end
  if botao("Usar o modelo: 1 Click/Guia · 2 VS · 3-4 Teclado", x1, fimY - 42, colW, 38, "secundario") then
    cfgSaidas = saidas.modelo4(); mudouSaidas()
    aviso("Modelo aplicado: 1 Click/Guia, 2 VS, 3 Teclado L, 4 Teclado R.", C.ok)
  end
  -- direita: para onde vai cada tipo de faixa
  texto("Para onde vai cada tipo de faixa", x2, y, 6, C.hi)
  texto("Nomes que terminam em L e R viram um par estéreo (ex.: Teclado L + R).", x2, y + 22, 2, C.muted)
  local ty = y + 50
  local th = math.min(40, (fimY - ty - 10) / #montar.TIPOS_ORDEM - 6)
  for k, tp in ipairs(montar.TIPOS_ORDEM) do
    local yy = ty + (k - 1) * (th + 6)
    cor(C.panel); retangulo(x2, yy, colW, th, 12)
    cor(montar.CORES_TIPOS[tp]); CI(x2 + 18, yy + th / 2, 5, 1, 1)
    texto(montar.NOMES_TIPOS[tp], x2 + 34, yy + (th - 17) / 2, 6, C.text)
    local t, hex = nomeDoDestino(c, c.tipos[tp])
    local sw = colW * 0.52
    if selo(t, x2 + colW - sw - 6, yy + 4, sw, th - 8, hex) then
      local v = menuDestinos(c)
      if v then c.tipos[tp] = v ~= saidas.MASTER and v or nil; mudouSaidas() end
    end
  end
  -- embaixo: tirar do master
  local by = fimY + 8
  cor(C.line); R(24, by - 8, VW - 48, 1, 1)
  if interruptor(24, by + 8, c.semMaster) then c.semMaster = not c.semMaster; mudouSaidas() end
  texto("Tirar as faixas do master", 90, by + 6, 6, C.hi)
  texto("Cada faixa sai só pela saída escolhida. Faixa sem saída escolhida continua no master, para não ficar muda.", 90, by + 28, 2, C.muted)
  local a = S.saidasAplicadas
  if a then
    local s = "Aplicado neste projeto: " .. a.ligadas .. " faixa(s) nas saídas" .. (a.semDestino > 0 and (", " .. a.semDestino .. " só no master") or "")
    texto(cortar(s, 2, VW * 0.35), VW - 24 - math.min(VW * 0.35, largura(s, 2)), by + 6, 2, C.ok)
  end
end

local function abaFaixas(y)
  local c = cfg()
  local lista = saidas.faixas()
  if #lista == 0 then
    centro("Este projeto ainda não tem faixas montadas pelo LS Live.", 24, y + 40, VW - 48, 40, 1, C.muted)
    return
  end
  texto("Mude a saída de uma faixa só, quando ela não segue o tipo (ex.: um pad que deve ir para o teclado).", 24, y, 2, C.muted)
  local ly, rh = y + 28, 40
  local fimY = VH - (S.msg and 44 or 8)
  local cabem = math.max(1, math.floor((fimY - ly) / (rh + 6)))
  S.scrollFaixas = math.max(0, math.min(S.scrollFaixas or 0, #lista - cabem))
  if mouse.roda ~= 0 then S.scrollFaixas = math.max(0, math.min(#lista - cabem, S.scrollFaixas - (mouse.roda > 0 and 2 or -2))) end
  for i = 1 + S.scrollFaixas, math.min(#lista, S.scrollFaixas + cabem) do
    local tr = lista[i]
    local yy = ly + (i - 1 - S.scrollFaixas) * (rh + 6)
    local _, nome = reaper.GetSetMediaTrackInfo_String(tr, "P_NAME", "", false)
    local pai = reaper.GetParentTrack(tr)
    local musica = ""
    if pai then local _, s = reaper.GetSetMediaTrackInfo_String(pai, "P_NAME", "", false); musica = s end
    local tp = saidas.tipo(tr)
    cor(C.panel); retangulo(24, yy, VW - 48, rh, 12)
    cor(montar.CORES_TIPOS[tp] or C.muted); CI(42, yy + rh / 2, 5, 1, 1)
    texto(cortar(nome, 6, VW * 0.22), 58, yy + 4, 6, C.hi)
    texto(cortar((musica or ""):gsub("^%d+%. ", ""), 2, VW * 0.22), 58, yy + 22, 2, C.muted)
    -- tipo
    local tw = VW * 0.2
    local tx = VW * 0.36
    if selo(montar.NOMES_TIPOS[tp] or tp, tx, yy + 5, tw, rh - 10) then
      local itens = {}
      for _, t in ipairs(montar.TIPOS_ORDEM) do itens[#itens + 1] = { (t == tp and "!" or "") .. montar.NOMES_TIPOS[t], t } end
      local v = escolher(itens)
      if v then
        reaper.GetSetMediaTrackInfo_String(tr, "P_EXT:louvor_tipo", v, true)
        reaper.SetMediaTrackInfo_Value(tr, "I_CUSTOMCOLOR", montar.cor(montar.CORES_TIPOS[v]))
        mudouSaidas()
      end
    end
    -- saída
    local dest, proprio = saidas.destinoDaFaixa(c, tr)
    local t, hex = nomeDoDestino(c, dest)
    if not proprio then t = "Pelo tipo: " .. t; hex = C.muted end
    local sw = VW - 48 - (tx + tw + 12 - 24) - 12
    if selo(t, tx + tw + 12, yy + 5, sw, rh - 10, hex) then
      local v = menuDestinos(c, { { "Seguir o tipo (" .. (montar.NOMES_TIPOS[tp] or tp) .. ")", "#tipo" } })
      if v == "#tipo" then saidas.destinoDaFaixaDefinir(tr, nil); mudouSaidas()
      elseif v then saidas.destinoDaFaixaDefinir(tr, v); mudouSaidas() end
    end
  end
end

local function abaPartes(y)
  local E = aovivo.estado
  local agora = reaper.time_precise()
  if agora - (S.partesLidas or 0) > 1 then
    S.partesLidas = agora
    aovivo.ler()
    S.partesMudadas = partes.mudadas(E.musicas)
  end
  if #E.musicas == 0 or not partes.info(1) then
    centro("Monte uma escala pelo LS Live para enviar ou atualizar as partes.", 24, y + 40, VW - 48, 40, 1, C.muted)
    return
  end
  local h, gap = 68, 10
  local mud = S.partesMudadas or {}
  local nomes = {}
  for _, x in ipairs(mud) do nomes[#nomes + 1] = x.info.titulo or x.m.nome end
  local xr = linhaConfig(y, h, "Enviar as partes corrigidas para o app",
    #mud > 0 and ("Mudou aqui: " .. table.concat(nomes, ", ")) or "Nada mudou aqui desde a montagem ou o último envio.")
  if botao("Enviar", xr - 130, y + (h - 38) / 2, 130, 38, "primario", #mud > 0) then enviarPartes() end
  y = y + h + gap
  local mi, _, m = aovivo.onde()
  xr = linhaConfig(y, h, "Atualizar as partes desta música pela nuvem",
    "Troca as regiões de \"" .. (m and m.nome:gsub("^%d+%. ", "") or "") .. "\" pelas partes que estão no app.")
  if botao("Atualizar", xr - 130, y + (h - 38) / 2, 130, 38, "secundario") then atualizarPartes(false) end
  y = y + h + gap
  xr = linhaConfig(y, h, "Atualizar as partes de todas as músicas", "Para todas as " .. #E.musicas .. " músicas deste projeto.")
  if botao("Atualizar todas", xr - 160, y + (h - 38) / 2, 160, 38, "secundario") then atualizarPartes(true) end
  y = y + h + gap
  texto("Corrija as partes no próprio REAPER: arraste as pontas das regiões, dois cliques para renomear, crie ou apague.", 24, y + 6, 2, C.muted)
  texto("Só o líder da banda pode mudar as partes no app.", 24, y + 26, 2, C.muted)
end

-- Aba Antes do culto: confere tudo de uma vez ---------------------------------------------------------
local function conferir()
  local itens = {}
  local function add(estado, titulo, detalhe) itens[#itens + 1] = { estado = estado, titulo = titulo, detalhe = detalhe } end
  local nOut = reaper.GetNumAudioOutputs() or 0
  if nOut > 0 then add("ok", "Placa de som aberta", nOut .. " saídas")
  else add("ruim", "A placa de som está fechada", "Options › Preferences › Audio › Device") end
  local musicas = aovivo.ler()
  if #musicas == 0 then add("ruim", "Nenhuma música montada neste projeto", "Escolha a escala e monte no REAPER") return itens end
  local _, tituloEscala = reaper.GetProjExtState(0, "LouvorStudio", "titulo")
  add("ok", #musicas .. " música(s) montadas", tituloEscala ~= "" and tituloEscala or nil)
  -- áudio de cada faixa
  local semAudio = {}
  for _, tr in ipairs(saidas.faixas()) do
    local _, nome = reaper.GetSetMediaTrackInfo_String(tr, "P_NAME", "", false)
    local _, ehPad = reaper.GetSetMediaTrackInfo_String(tr, "P_EXT:louvor_pad", "", false)
    local temItem = reaper.CountTrackMediaItems(tr) > 0
    if temItem then
      local tk = reaper.GetActiveTake(reaper.GetTrackMediaItem(tr, 0))
      local src = tk and reaper.GetMediaItemTake_Source(tk)
      local arq = src and reaper.GetMediaSourceFileName(src, "") or ""
      if arq ~= "" and not reaper.file_exists(arq) then temItem = false end
    end
    if not temItem and nome ~= "Contagem (LS Live)" and ehPad ~= "1" then semAudio[#semAudio + 1] = nome end
  end
  if #semAudio == 0 then add("ok", "Todas as faixas têm áudio", nil)
  else add("ruim", #semAudio .. " faixa(s) sem áudio", table.concat(semAudio, ", ")) end
  -- partes
  local semPartes = {}
  for _, m in ipairs(musicas) do
    if #m.partes == 0 or (#m.partes == 1 and m.partes[1].nome == "Música inteira") then semPartes[#semPartes + 1] = (m.nome:gsub("^%d+%. ", "")) end
  end
  if #semPartes == 0 then add("ok", "Todas as músicas têm partes", nil)
  else add("aviso", "Música(s) sem partes marcadas", table.concat(semPartes, ", ") .. " (use + Marcar parte)") end
  if #partes.mudadas(musicas) > 0 then add("aviso", "Partes corrigidas aqui e ainda não enviadas ao app", "Configurações › Partes › Enviar") end
  -- saídas
  local cfg = saidas.carregar()
  if saidas.configurado(cfg) then
    local maior = 0
    for _, d in ipairs((saidas.destinos(cfg))) do maior = math.max(maior, d.l, d.r or 0) end
    if nOut > 0 and maior > nOut then add("ruim", "Saída " .. maior .. " não existe nesta placa", "A placa tem " .. nOut .. " saídas")
    else add("ok", "Saídas configuradas", cfg.semMaster and "faixas fora do master" or "faixas também no master") end
  else
    add("aviso", "Saídas não configuradas", "Tudo sai pelo master (Configurações › Saídas de áudio)")
  end
  -- tom e andamento mudados
  local mudados = {}
  for n, m in ipairs(musicas) do
    local aj = tom.ajuste(n)
    local t = {}
    if aj.semi ~= 0 then t[#t + 1] = (aj.semi > 0 and "+" or "") .. aj.semi .. " tom" end
    if math.abs(aj.taxa - 1) > 0.001 then t[#t + 1] = math.floor(aj.taxa * 100 + 0.5) .. "%" end
    if #t > 0 then mudados[#mudados + 1] = (tituloETom(m.nome)) .. " " .. table.concat(t, " ") end
  end
  if #mudados > 0 then add("aviso", "Tom ou andamento mudados", table.concat(mudados, " · ")) end
  -- contagem
  if contagem.ligada() then
    local sem = 0
    for n = 1, #musicas do if not contagem.inicio(n) then sem = sem + 1 end end
    if sem == 0 then add("ok", "Contagem antes de cada música", nil)
    else add("aviso", "Contagem ligada, mas falta em " .. sem .. " música(s)", "Desligue e ligue de novo em Ao vivo e celular") end
  end
  -- controlador
  local nMidi = 0
  for _ in pairs(controles.mapa) do nMidi = nMidi + 1 end
  if nMidi > 0 then
    add(controles.ultimo and "ok" or "aviso", nMidi .. " botão(ões) do controlador ligados",
      controles.ultimo and ("último sinal: " .. controles.ultimo.aparelho) or "aperte um pad para conferir se chega")
  end
  -- celular
  if remoto.porta() then add("ok", "Controle pelo celular ligado", remoto.endereco() or "conecte o computador à rede da igreja") end
  -- plano e internet
  local ok = tonumber(reaper.GetExtState("LouvorStudio", "live_ok")) or 0
  if ok > 0 then
    local dias = math.max(0, 7 - math.floor((os.time() - ok) / 86400))
    add("ok", "Funciona sem internet", "por mais " .. dias .. " dia(s) (depois precisa conferir o plano)")
  end
  return itens
end
T.conferir = conferir

local function abaConferencia(y)
  local agora = reaper.time_precise()
  if not S.conferencia or agora - (S.conferidoEm or 0) > 2 then S.conferencia, S.conferidoEm = conferir(), agora end
  local ruins, avisos = 0, 0
  for _, x in ipairs(S.conferencia) do
    if x.estado == "ruim" then ruins = ruins + 1 elseif x.estado == "aviso" then avisos = avisos + 1 end
  end
  local resumo = ruins > 0 and (ruins .. " coisa(s) para resolver antes do culto") or (avisos > 0 and ("Tudo certo, com " .. avisos .. " aviso(s)") or "Tudo pronto para o culto")
  texto(resumo, 24, y, 4, ruins > 0 and C.bad or (avisos > 0 and C.warn or C.ok))
  local rh, gap = 44, 6
  local yy = y + 40
  for _, x in ipairs(S.conferencia) do
    if yy + rh > VH - 8 then break end
    cor(C.panel); retangulo(24, yy, VW - 48, rh, 12)
    local hex = x.estado == "ok" and C.ok or (x.estado == "aviso" and C.warn or C.bad)
    cor(hex); CI(44, yy + rh / 2, 6, 1, 1)
    texto(cortar(x.titulo, 6, VW * 0.45), 62, yy + (rh - 17) / 2, 6, C.hi)
    if x.detalhe then
      local d = cortar(x.detalhe, 2, VW * 0.45 - 40)
      texto(d, VW - 44 - largura(d, 2), yy + (rh - 15) / 2, 2, C.muted)
    end
    yy = yy + rh + gap
  end
end

local function telaConfig()
  topo("Configurações", "LS Live · Louvor Studio Live para o REAPER", function()
    local volta = S.telaAntes
    if volta == "aovivo" then S.tela = "aovivo"
    elseif volta == "entrar" or not volta then
      if nuvem.userId() then T.sairDoAoVivo() else S.tela = "entrar" end
    else S.tela = volta end
    aviso(nil)
  end)
  -- abas (controle segmentado)
  local y = 102
  local x = 24
  fonte(6)
  local ws = {}
  local total = 8
  for i, a in ipairs(ABAS) do ws[i] = largura(a[2], 6) + 36; total = total + ws[i] end
  cor(C.panel); retangulo(x, y, total, 40, 20)
  x = x + 4
  for i, a in ipairs(ABAS) do
    local on = (S.abaConfig or "geral") == a[1]
    local sobre = dentro(x, y + 4, ws[i], 32)
    if on then cor(C.accent); retangulo(x, y + 4, ws[i], 32, 16) elseif sobre then cor(C.sel); retangulo(x, y + 4, ws[i], 32, 16) end
    centro(a[2], x, y + 4, ws[i], 32, 6, on and C.onAccent or C.text)
    if sobre and mouse.clicked then S.abaConfig = a[1]; aviso(nil) end
    x = x + ws[i]
  end
  local aba = S.abaConfig or "geral"
  local cy = y + 60
  if aba == "geral" then abaGeral(cy)
  elseif aba == "aovivo" then abaAoVivo(cy)
  elseif aba == "saidas" then abaSaidas(cy)
  elseif aba == "faixas" then abaFaixas(cy)
  elseif aba == "conferencia" then abaConferencia(cy)
  else abaPartes(cy) end
end
T.telaConfig = telaConfig

--- Abre as Configurações (botão ⋯).
local function abrirConfig()
  S.abrirOpcoes = false
  if S.tela ~= "config" then S.telaAntes = S.tela end
  S.tela = "config"
  cfgSaidas = saidas.carregar()
  if S.mini then alternarMini() end
  aviso(nil)
end
T.abrirConfig = abrirConfig

-- Celular -------------------------------------------------------------------------------------------
local function hexDe(n)
  local r, g, b = reaper.ColorFromNative((n or 0) & 0xFFFFFF)
  return string.format("#%02X%02X%02X", r, g, b)
end

--- O estado do ao vivo para a página do celular (louvor/remoto.lua › publicar).
local function estadoRemoto(E, pos, mi, pi, m, p)
  if not m then return { aovivo = false } end
  local aj = tom.ajuste(mi)
  local bpm = tom.bpm(mi, m)
  local prox = E.musicas[mi + 1]
  local partesT = {}
  for k, x in ipairs(m.partes) do partesT[k] = { n = x.nome, c = hexDe(x.cor) } end
  local fila
  if E.fila then for k, x in ipairs(m.partes) do if x.idx == E.fila.idx then fila = k end end end
  local st, sth = statusAoVivo(E, p, pos)
  local dDia = tom.paraOTomDoDia(mi)
  local _, dia = tom.tons(mi)
  return {
    aovivo = true, mi = mi, total = #E.musicas, titulo = (tituloETom(m.nome)), depois = prox and (tituloETom(prox.nome)) or nil,
    tom = tom.soando(mi), semi = aj.semi, tomDia = dDia and dia or nil, bpm = bpm and math.floor(bpm + 0.5) or nil,
    taxa = math.floor(aj.taxa * 100 + 0.5), tocando = aovivo.tocando(), repetir = E.repetir, final = E.final,
    suave = E.suave ~= nil, pad = pad.ligado(), ordemLigada = ordem.ligada(),
    parte = p and p.nome or nil, faltam = p and (p.fim - pos) or nil,
    prog = p and math.max(0, math.min(1, (pos - p.ini) / math.max(0.01, p.fim - p.ini))) or 0,
    pi = pi, fila = fila, partes = partesT, ordem = ordem.nomes(mi), passo = aovivo.passoDaOrdem(),
    status = st, statusCor = sth,
  }
end

-- Laço ----------------------------------------------------------------------------------------------
-- Um quadro da janela. Erros viram mensagem no rodapé (e vão para LouvorStudio/erros.txt), sem a tela de erro do REAPER.
local function quadro(ch)
  -- trava: sem conta ou sem o plano, nada de escalas nem ao vivo
  if not nuvem.userId() then S.liberado = false end
  if not S.liberado and (S.tela == "aovivo" or S.tela == "escalas" or S.tela == "preparar") then
    S.tela = nuvem.userId() and "semPlano" or "entrar"
  end
  atualizarEscala()
  lerMouse()
  cor(C.bg); R(0, 0, VW, VH, 1)
  if S.tela == "aovivo" then
    -- o projeto mudou (regiões arrastadas, renomeadas…): relê e vê se as partes mudaram
    local cc = tostring(reaper.EnumProjects(-1)) .. ":" .. reaper.GetProjectStateChangeCount(0)
    local agora = reaper.time_precise()
    if cc ~= S.mudancas or agora - (S.lidoEm or 0) > 1 then
      S.mudancas, S.lidoEm = cc, agora
      aovivo.ler()
      if partes.colorir(aovivo.estado.musicas) > 0 then aovivo.ler() end
      S.partesMudadas = partes.mudadas(aovivo.estado.musicas)
    end
    teclaAoVivo(ch)
    for _, c in ipairs(controles.lerMidi()) do executar(c) end
    local cmdCel = remoto.comando()
    if cmdCel then executar(cmdCel) end
    aovivo.passo()
    local E = aovivo.estado
    local pos = aovivo.posicao()
    local mi, pi, m, p = aovivo.onde(pos)
    tom.sincronizar(m and mi)
    pad.sincronizar(pad.ligado() and m and not aovivo.tocando() and not E.suave and tom.soando(mi) or nil)
    luzes.passo({ m = m, pi = pi, fila = E.fila, tocando = aovivo.tocando(), repetir = E.repetir, final = E.final,
      pad = pad.ligado(), pisca = pisca < 15 })
    remoto.publicar(estadoRemoto(E, pos, mi, pi, m, p))
    telaAoVivo()
    if S.menuPara then menuLigar() end
  else
    pad.sincronizar(nil)
    remoto.comando()
    remoto.publicar({ aovivo = false })
    controles.lerMidi()
    passoDownload()
    if compacto() then
      telaMiniSimples(S.baixando and "Baixando as músicas…" or (S.tela == "preparar" and S.escala and S.escala.titulo) or
        (S.tela == "escalas" and "Escolha a escala (expanda)") or (S.tela == "config" and "Configurações (expanda)") or (S.tela == "semPlano" and "Sua banda ainda não tem o LS Live (expanda)") or "Entre na sua conta (expanda)")
    elseif S.tela == "entrar" then telaEntrar()
    elseif S.tela == "escalas" then telaEscalas()
    elseif S.tela == "preparar" then telaPreparar()
    elseif S.tela == "config" then telaConfig()
    elseif S.tela == "semPlano" then telaSemPlano() end
    if not compacto() then rodape() end
  end
  if S.abrirOpcoes then abrirConfig() end
  if S.enviarPartes then enviarPartes() end
  if not mouse.down then S.segura = nil end
end
T.quadro = quadro

local function registrarErro(e)
  local f = io.open(http.pasta() .. (http.WIN and "\\" or "/") .. "erros.txt", "a")
  if f then f:write(os.date("%Y-%m-%d %H:%M:%S ") .. tostring(e) .. "\n"); f:close() end
  S.baixando = false
  aviso("Algo deu errado: " .. tostring(e):match("^[^\n]*"), C.bad)
end
T.registrarErro = registrarErro

function T.abrir()
  controles.carregar()
  local okV, v = pcall(instalar.verificarVersao)
  S.versaoNova = okV and v or nil
  pcall(instalar.garantirBarra)
  pcall(remoto.instalarPagina)   -- a página do celular sempre na versão deste LS Live   -- a barrinha com o ícone volta se tiver sido fechada
  local dock = tonumber(reaper.GetExtState("LouvorStudio", "dock")) or 0
  S.mini = reaper.GetExtState("LouvorStudio", "mini") == "1"
  local t = S.mini and TAM_MINI or TAM_NORMAL
  gfx.init("LS Live", t[1], t[2], dock)
  -- precisa da conta e do plano com o LS Live
  if nuvem.carregar() then
    local okA, liberado = pcall(verificarAcesso)
    if not okA or not liberado then
      S.tela = "semPlano"
    elseif textoTeste() and aovivo.ler() and #aovivo.estado.musicas > 0 and reaper.GetProjExtState(0, "LouvorStudio", "escala") > 0 then
      S.tela = "aovivo"
      S.avisoAoVivo = { texto = textoTeste(), cor = C.warn, ate = reaper.time_precise() + 10 }
    elseif aovivo.ler() and #aovivo.estado.musicas > 0 and reaper.GetProjExtState(0, "LouvorStudio", "escala") > 0 then
      S.tela = "aovivo"
    else
      S.tela = "escalas"
      local ok, e = pcall(function() carregarBandas(); carregarEscalas() end)
      if not ok then registrarErro(e) end
      if textoTeste() then aviso(textoTeste(), C.warn) end
    end
  else
    S.tela = "entrar"
  end
  if S.versaoNova then
    aviso("Saiu uma versão nova do LS Live (" .. S.versaoNova .. "). Atualize em ⋯ › Geral.", C.warn)
    if S.tela == "aovivo" then S.avisoAoVivo = { texto = "Versão nova do LS Live: atualize em ⋯ › Geral (depois do culto).", cor = C.warn, ate = reaper.time_precise() + 8 } end
  end
  local function laco()
    local ch = gfx.getchar()
    if ch < 0 then
      reaper.SetExtState("LouvorStudio", "dock", tostring(gfx.dock(-1)), true)
      pcall(pad.silenciar); pcall(luzes.apagar)
      reaper.SetExtState("LouvorStudio", "remoto_estado", "", false)
      return
    end
    local ok, e = xpcall(quadro, debug.traceback, ch)
    if not ok then registrarErro(e) end
    gfx.update()
    reaper.defer(laco)
  end
  laco()
end

return T
