-- Louvor Studio para o REAPER — JSON simples (ler e escrever), sem bibliotecas de fora.
local M = {}

M.null = setmetatable({}, { __tostring = function() return "null" end })

local function kind(v)
  if type(v) ~= "table" or v == M.null then return type(v) end
  if next(v) == nil then return getmetatable(v) == M.object_mt and "object" or "array" end
  local n = 0
  for k in pairs(v) do
    if type(k) ~= "number" then return "object" end
    n = n + 1
  end
  for i = 1, n do if v[i] == nil then return "object" end end
  return "array"
end

M.object_mt = {}
function M.object(t) return setmetatable(t or {}, M.object_mt) end

local escapes = { ['"'] = '\\"', ['\\'] = '\\\\', ['\b'] = '\\b', ['\f'] = '\\f', ['\n'] = '\\n', ['\r'] = '\\r', ['\t'] = '\\t' }
local function str(s)
  return '"' .. s:gsub('[%c"\\]', function(c) return escapes[c] or string.format("\\u%04x", c:byte()) end) .. '"'
end

function M.encode(v)
  local t = type(v)
  if v == nil or v == M.null then return "null" end
  if t == "boolean" then return tostring(v) end
  if t == "number" then
    if v ~= v or v == math.huge or v == -math.huge then return "null" end
    if math.type and math.type(v) == "integer" then return tostring(v) end
    if v == math.floor(v) and math.abs(v) < 1e15 then return string.format("%d", v) end
    return string.format("%.14g", v)
  end
  if t == "string" then return str(v) end
  if t == "table" then
    local out = {}
    if kind(v) == "array" then
      for i = 1, #v do out[#out + 1] = M.encode(v[i]) end
      return "[" .. table.concat(out, ",") .. "]"
    end
    for k, x in pairs(v) do out[#out + 1] = str(tostring(k)) .. ":" .. M.encode(x) end
    return "{" .. table.concat(out, ",") .. "}"
  end
  error("não dá para virar JSON: " .. t)
end

-- Leitor -------------------------------------------------------------------
local function utf8char(c)
  if c < 0x80 then return string.char(c) end
  if c < 0x800 then return string.char(0xC0 | (c >> 6), 0x80 | (c & 0x3F)) end
  if c < 0x10000 then return string.char(0xE0 | (c >> 12), 0x80 | ((c >> 6) & 0x3F), 0x80 | (c & 0x3F)) end
  return string.char(0xF0 | (c >> 18), 0x80 | ((c >> 12) & 0x3F), 0x80 | ((c >> 6) & 0x3F), 0x80 | (c & 0x3F))
end

function M.decode(s)
  local i = 1
  local function err(m) error("JSON inválido (" .. m .. ") na posição " .. i) end
  local function ws() i = s:find("[^ \t\r\n]", i) or (#s + 1) end
  local value
  local function string_()
    i = i + 1
    local buf = {}
    while true do
      local j = s:find('["\\]', i)
      if not j then err("texto sem fim") end
      buf[#buf + 1] = s:sub(i, j - 1)
      if s:sub(j, j) == '"' then i = j + 1; break end
      local e = s:sub(j + 1, j + 1)
      if e == "u" then
        local c = tonumber(s:sub(j + 2, j + 5), 16) or err("\\u")
        i = j + 6
        if c >= 0xD800 and c <= 0xDBFF and s:sub(i, i + 1) == "\\u" then
          local lo = tonumber(s:sub(i + 2, i + 5), 16)
          if lo and lo >= 0xDC00 and lo <= 0xDFFF then c = 0x10000 + ((c - 0xD800) << 10) + (lo - 0xDC00); i = i + 6 end
        end
        buf[#buf + 1] = utf8char(c)
      else
        local map = { b = "\b", f = "\f", n = "\n", r = "\r", t = "\t", ['"'] = '"', ["\\"] = "\\", ["/"] = "/" }
        buf[#buf + 1] = map[e] or err("escape")
        i = j + 2
      end
    end
    return table.concat(buf)
  end
  function value()
    ws()
    local c = s:sub(i, i)
    if c == "{" then
      i = i + 1
      local o = M.object()
      ws()
      if s:sub(i, i) == "}" then i = i + 1; return o end
      while true do
        ws()
        if s:sub(i, i) ~= '"' then err("chave") end
        local k = string_()
        ws()
        if s:sub(i, i) ~= ":" then err(":") end
        i = i + 1
        o[k] = value()
        ws()
        local d = s:sub(i, i)
        i = i + 1
        if d == "}" then return o end
        if d ~= "," then err(",") end
      end
    elseif c == "[" then
      i = i + 1
      local a = {}
      ws()
      if s:sub(i, i) == "]" then i = i + 1; return a end
      while true do
        a[#a + 1] = value()
        ws()
        local d = s:sub(i, i)
        i = i + 1
        if d == "]" then return a end
        if d ~= "," then err(",") end
      end
    elseif c == '"' then return string_()
    elseif s:sub(i, i + 3) == "true" then i = i + 4; return true
    elseif s:sub(i, i + 4) == "false" then i = i + 5; return false
    elseif s:sub(i, i + 3) == "null" then i = i + 4; return M.null
    else
      local num = s:match("^-?%d+%.?%d*[eE]?[-+]?%d*", i)
      if not num or num == "" then err("valor") end
      i = i + #num
      return tonumber(num)
    end
  end
  local ok, v = pcall(value)
  if not ok then return nil, v end
  return v
end

--- nulo do JSON vira nil
function M.get(t, k) local v = t and t[k]; if v == M.null then return nil end; return v end

return M
