-- Louvor Studio para o REAPER — as partes (regiões) de volta para a nuvem, e da nuvem para o REAPER.
--  * Na montagem, cada música guarda no projeto: qual é a música no app, a duração e como as partes estavam
--    (aqui e na nuvem). Assim dá para saber o que mudou aqui e se alguém mudou no app nesse meio-tempo.
--  * Enviar: as regiões da música viram as partes do app (song_markers). Só o líder da banda pode (regra do banco).
--  * Atualizar pela nuvem: as regiões da música são trocadas pelas partes que estão no app.
-- Tempos no app são da linha do tempo da música (0 = começo), em ms; aqui, a música começa no marcador "♪".
local json = require("louvor.json")
local nuvem = require("louvor.nuvem")
local montar = require("louvor.montar")
local M = {}

local EXT = "LouvorStudio"

local function ms(s) return math.floor(s * 1000 + 0.5) end

--- Partes do app como texto comparável (início|fim|nome; fim vazio = até a próxima).
function M.assinaturaNuvem(lista)
  local t = {}
  for _, p in ipairs(lista) do t[#t + 1] = ms(p.ini) .. "|" .. (p.fim and ms(p.fim) or "") .. "|" .. p.nome end
  table.sort(t)
  return table.concat(t, "\n")
end

--- Regiões de uma música do projeto como texto comparável (início|fim|nome, relativos ao começo da música).
function M.assinaturaAqui(m)
  local t = {}
  for _, r in ipairs(m.partes) do t[#t + 1] = ms(r.ini - m.ini) .. "|" .. ms(r.fim - m.ini) .. "|" .. r.nome end
  return table.concat(t, "\n")
end

function M.guardar(n, info) reaper.SetProjExtState(0, EXT, "musica" .. n, json.encode(info)) end
function M.info(n)
  local _, s = reaper.GetProjExtState(0, EXT, "musica" .. n)
  local t = s ~= "" and json.decode(s) or nil
  return type(t) == "table" and t or nil
end

--- Músicas do projeto (aovivo.estado.musicas) cujas partes mudaram aqui desde a montagem/último envio.
function M.mudadas(musicas)
  local out = {}
  for n, m in ipairs(musicas) do
    local info = M.info(n)
    if info and info.projeto and info.aqui ~= M.assinaturaAqui(m) then out[#out + 1] = { n = n, m = m, info = info } end
  end
  return out
end

--- As regiões viram a lista do app: nome (1–40 letras), início e fim em ms (fim vazio quando emenda na próxima).
function M.paraNuvem(m, dur)
  local lista = {}
  for i, r in ipairs(m.partes) do
    local ini = math.max(0, ms(r.ini - m.ini))
    local fim = ms(r.fim - m.ini)
    if dur and dur > 0 then ini = math.min(ini, ms(dur)); fim = math.min(fim, ms(dur)) end
    local nome = (r.nome or ""):gsub("^%s+", ""):gsub("%s+$", "")
    if nome == "" then nome = "Parte " .. i end
    if utf8 and utf8.len(nome) and utf8.len(nome) > 40 then nome = nome:sub(1, utf8.offset(nome, 41) - 1) end
    lista[#lista + 1] = { nome = nome, at = ini, fim = fim }
  end
  table.sort(lista, function(a, b) return a.at < b.at end)
  for i, p in ipairs(lista) do
    local prox = lista[i + 1]
    local emenda = (prox and math.abs(p.fim - prox.at) <= 5) or (not prox and dur and math.abs(p.fim - ms(dur)) <= 5)
    if emenda or p.fim <= p.at then p.fim = nil end
  end
  return lista
end

local function lerNuvem(projeto)
  return nuvem.consulta("song_markers", "select=id,name,at_ms,end_ms&order=at_ms,id&project_id=eq." .. projeto)
end

local function nuvemComoPartes(rows)
  local l = {}
  for _, x in ipairs(rows) do
    l[#l + 1] = { id = x.id, nome = json.get(x, "name") or "Parte", ini = (tonumber(x.at_ms) or 0) / 1000,
      fim = json.get(x, "end_ms") and tonumber(x.end_ms) / 1000 or nil }
  end
  return l
end

--- Alguém mudou as partes desta música no app depois que ela foi montada/enviada aqui?
function M.mudouNaNuvem(n)
  local info = M.info(n)
  if not info then return false end
  local rows = lerNuvem(info.projeto)
  if not rows then return false end
  return M.assinaturaNuvem(nuvemComoPartes(rows)) ~= (info.nuvem or "")
end

local function semPermissao(e, code)
  return code == 401 or code == 403 or tostring(e):find("permissão") or tostring(e):find("row%-level")
end
local MSG_LIDER = "Só o líder da banda pode mudar as partes no app."

--- Envia as partes da música n (m = a música do aovivo). Devolve true ou false + mensagem.
function M.enviar(n, m)
  local info = M.info(n)
  if not info or not info.projeto then return false, "Esta música não foi montada pelo Louvor Studio." end
  local novas = M.paraNuvem(m, info.dur)
  local rows, e = lerNuvem(info.projeto)
  if not rows then return false, e end
  -- troca no lugar (mesma quantidade), cria as que sobram e apaga as que faltam
  for i, p in ipairs(novas) do
    local body = { name = p.nome, at_ms = p.at, end_ms = p.fim or json.null }
    local old = rows[i]
    if old then
      local mesmo = old.name == p.nome and tonumber(old.at_ms) == p.at and (tonumber(json.get(old, "end_ms") or -1) == (p.fim or -1))
      if not mesmo then
        local r, err, code = nuvem.escrever("PATCH", "song_markers", "id=eq." .. old.id, body)
        if not r then return false, semPermissao(err, code) and MSG_LIDER or err end
        if #r == 0 then return false, MSG_LIDER end
      end
    else
      body.project_id = info.projeto
      local r, err, code = nuvem.escrever("POST", "song_markers", nil, body)
      if not r then return false, semPermissao(err, code) and MSG_LIDER or err end
    end
  end
  if #rows > #novas then
    local ids = {}
    for i = #novas + 1, #rows do ids[#ids + 1] = rows[i].id end
    local r, err, code = nuvem.escrever("DELETE", "song_markers", "id=in.(" .. table.concat(ids, ",") .. ")", nil)
    if not r then return false, semPermissao(err, code) and MSG_LIDER or err end
    if #r == 0 then return false, MSG_LIDER end
  end
  -- guarda o novo estado (aqui e na nuvem)
  local depois = lerNuvem(info.projeto) or {}
  info.aqui = M.assinaturaAqui(m)
  info.nuvem = M.assinaturaNuvem(nuvemComoPartes(depois))
  M.guardar(n, info)
  return true, #novas
end

--- Troca as regiões da música n pelas partes que estão no app. Devolve true ou false + mensagem.
function M.atualizar(n, m)
  local info = M.info(n)
  if not info or not info.projeto then return false, "Esta música não foi montada pelo Louvor Studio." end
  local rows, e = lerNuvem(info.projeto)
  if not rows then return false, e end
  local lista = nuvemComoPartes(rows)
  local fimMusica = (info.dur and info.dur > 0) and info.dur or (m.fim - m.ini)
  local partes = montar.partes(lista, fimMusica)
  if #partes == 0 then partes = { { nome = "Música inteira", ini = 0, fim = fimMusica } } end
  reaper.Undo_BeginBlock()
  for k = #m.partes, 1, -1 do
    local r = m.partes[k]
    reaper.DeleteProjectMarker(0, r.num, true)
  end
  for _, p in ipairs(partes) do
    reaper.AddProjectMarker2(0, true, m.ini + p.ini, m.ini + p.fim, p.nome, -1, montar.cor(montar.corDaParte(p.nome)))
  end
  reaper.Undo_EndBlock("Louvor Studio: atualizar as partes pela nuvem", -1)
  reaper.UpdateTimeline()
  info.nuvem = M.assinaturaNuvem(lista)
  info.aqui = nil   -- recalculado depois de reler o projeto
  M.guardar(n, info)
  return true, #partes
end

--- Depois de atualizar e reler, grava como as regiões ficaram (para não aparecer "mudou aqui").
function M.marcarAqui(n, m)
  local info = M.info(n)
  if info then info.aqui = M.assinaturaAqui(m); M.guardar(n, info) end
end

return M
