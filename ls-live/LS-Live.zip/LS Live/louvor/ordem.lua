-- LS Live — a ordem das partes que o líder define (ex.: Intro, Verso, Refrão, Refrão, Ponte, Final).
--  * Guardada pelos nomes das partes, no projeto ("ordem<n>") e neste computador pela música do app
--    ("ordem:<id da música>"), para valer de novo na próxima escala que tiver a mesma música.
--  * Tocando com a ordem ligada, no fim de cada parte o LS Live já põe a próxima da ordem na fila (o mesmo pulo
--    sem corte de quando a pessoa escolhe a parte). Escolher outra parte à mão continua valendo.
--  * Partes com o mesmo nome (dois "Verso"): cada vez vai na próxima delas, na ordem da música.
local json = require("louvor.json")
local montar = require("louvor.montar")
local M = {}

local EXT = "LouvorStudio"

local function projetoDa(n)
  local info = require("louvor.partes").info(n)
  return info and info.projeto
end

--- Os nomes na ordem da música n (lista vazia se não tem ordem).
function M.nomes(n)
  local _, s = reaper.GetProjExtState(0, EXT, "ordem" .. n)
  if s == "" then
    local p = projetoDa(n)
    if p then s = reaper.GetExtState(EXT, "ordem:" .. p) end
  end
  local t = s ~= "" and json.decode(s) or nil
  local out = {}
  if type(t) == "table" then for _, v in ipairs(t) do if type(v) == "string" then out[#out + 1] = v end end end
  return out
end

function M.salvar(n, nomes)
  local s = json.encode(nomes)
  if #nomes == 0 then s = "[]" end
  reaper.SetProjExtState(0, EXT, "ordem" .. n, s)
  local p = projetoDa(n)
  if p then
    if #nomes == 0 then reaper.DeleteExtState(EXT, "ordem:" .. p, true) else reaper.SetExtState(EXT, "ordem:" .. p, s, true) end
  end
end

--- Seguir a ordem (liga/desliga para todas as músicas). Ligado por padrão.
function M.ligada() return reaper.GetExtState(EXT, "ordem_ligada") ~= "0" end
function M.alternar() reaper.SetExtState(EXT, "ordem_ligada", M.ligada() and "0" or "1", true) end

--- Os nomes viram as partes da música (índices k em m.partes). Nomes que a música não tem ficam de fora.
function M.resolver(m, nomes)
  local seq, ultimo = {}, 0
  for _, nome in ipairs(nomes) do
    local alvo = montar.norm(nome)
    local achou
    for k = ultimo + 1, #m.partes do if montar.norm(m.partes[k].nome) == alvo then achou = k break end end
    if not achou then for k = 1, #m.partes do if montar.norm(m.partes[k].nome) == alvo then achou = k break end end end
    if achou then seq[#seq + 1] = achou; ultimo = achou end
  end
  return seq
end

--- Onde estamos na ordem: dado o passo anterior e a parte que ACABOU de começar, o novo passo (nil = fora da ordem).
--- Chamar só quando uma parte começa (inclusive a mesma parte de novo, como em "Refrão, Refrão").
function M.acompanhar(seq, passo, pi)
  if not pi then return passo end
  passo = passo or 0
  for j = passo + 1, #seq do if seq[j] == pi then return j end end
  for j = 1, #seq do if seq[j] == pi then return j end end
  return nil
end

return M
