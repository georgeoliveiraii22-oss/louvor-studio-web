-- Louvor Studio para o REAPER — grade pelo click (porte de web/beatgrid.js, o mesmo método do app):
-- não é um BPM fixo; cada batida da régua do REAPER cai no ataque de um "tic" do click. Se o click acelera,
-- atrasa ou muda de andamento, a régua acompanha. O primeiro tempo do compasso é o tic diferente (mais forte ou
-- mais agudo). A detecção roda aqui, no áudio que o próprio REAPER decodificou, então a grade cai certinha nele.
-- Mudou a regra em web/beatgrid.js? Mude aqui também.
local M = {}

local MIN_GAP_MS, RISE, FLOOR, DECAY_TO, DECAY_MS, ATTACK_AT, ECHO_MS, ECHO_MIN = 60, 3, 0.05, 0.3, 150, 0.1, 200, 0.35
local STRICT = { floor = FLOOR, rise = RISE, decayTo = DECAY_TO, decayMs = DECAY_MS }
local LOOSE = { floor = 0.02, rise = 2, decayTo = 0.5, decayMs = 300 }

M.NOME_CLICK = { "click", "metro", "clique", "clic", "clk", "bpm" }

function M.ehClick(nome)
  local n = " " .. tostring(nome or ""):lower() .. " "
  for _, k in ipairs(M.NOME_CLICK) do if n:find(k, 1, true) then return true end end
  return false
end

-- Leitor de amostras do item (por pedaços, sem guardar a música inteira na memória).
local function leitor(take)
  local acc = reaper.CreateTakeAudioAccessor(take)
  local src = reaper.GetMediaItemTake_Source(take)
  local sr = math.floor(reaper.GetMediaSourceSampleRate(src))
  if sr <= 0 then sr = 44100 end
  local nch = math.max(1, math.min(2, reaper.GetMediaSourceNumChannels(src)))
  local L = { acc = acc, sr = sr, nch = nch }
  --- amostras [s0, s1) de todos os canais: devolve uma tabela plana (intercalada)
  function L.ler(s0, s1)
    local n = math.max(0, s1 - s0)
    if n == 0 then return {}, 0 end
    local arr = reaper.new_array(n * nch)
    reaper.GetAudioAccessorSamples(acc, sr, nch, s0 / sr, n, arr)
    return arr.table(), n
  end
  function L.fechar() reaper.DestroyAudioAccessor(acc) end
  return L
end

--- Detecta as batidas no take (em segundos, contados do começo do item). Devolve { beats, downbeats, beatsPerBar }.
function M.detectar(take, duracao)
  local L = leitor(take)
  local sr, nch = L.sr, L.nch
  local total = math.floor(duracao * sr)
  local hop = math.max(1, math.floor(sr / 1000 + 0.5))
  local frames = math.floor(total / hop)
  local env = {}
  local gmax = 0
  -- 1) envelope de pico em janelas de 1 ms, lendo de 2 em 2 segundos
  local passo = hop * 2000
  local f = 0
  for s0 = 0, frames * hop - 1, passo do
    local s1 = math.min(frames * hop, s0 + passo)
    local a = L.ler(s0, s1)
    local nf = math.floor((s1 - s0) / hop)
    for k = 0, nf - 1 do
      local m = 0
      local base = k * hop * nch
      for x = base + 1, base + hop * nch do
        local v = a[x]
        if v < 0 then v = -v end
        if v > m then m = v end
      end
      env[f] = m
      if m > gmax then gmax = m end
      f = f + 1
    end
  end
  frames = f
  local vazio = { beats = {}, downbeats = {}, beatsPerBar = nil }
  if frames == 0 or gmax < 0.003 then L.fechar() return vazio end

  local function scan(P)
    local floor = gmax * P.floor
    local found = {}
    local last, lastPk, lastPv = -1e9, -1e9, 0
    local k = 3
    while k < frames do
      local v = env[k]
      if v < floor or k - last < MIN_GAP_MS then k = k + 1
      else
        local a0, b0 = math.max(0, k - 14), math.max(0, k - 2)
        local sum = 0
        for j = a0, b0 - 1 do sum = sum + env[j] end
        local pre = b0 > a0 and sum / (b0 - a0) or 0
        if v < pre * P.rise + gmax * 0.01 then k = k + 1
        else
          local pk, pv = k, v
          for j = k, math.min(frames, k + 25) - 1 do if env[j] > pv then pv = env[j]; pk = j end end
          if pk - lastPk < ECHO_MS and pv < lastPv * ECHO_MIN then k = pk + 1
          else
            local fim = -1
            for j = pk, math.min(frames, pk + P.decayMs) - 1 do if env[j] < pv * P.decayTo then fim = j; break end end
            if fim < 0 then
              local j = pk
              while j < frames and env[j] >= pv * P.decayTo do j = j + 1 end
              k = j
            else
              -- ataque: primeira amostra com 10% do pico; brilho: cruzamentos por zero nos 8 ms seguintes
              local x0 = math.max(0, (k - 3) * hop)
              local x1 = math.min(total, (pk + 1) * hop)
              local w8 = math.max(1, math.floor(sr * 0.008 + 0.5))
              local amostras = L.ler(x0, x1 + w8)
              local thr = pv * ATTACK_AT
              local at = x0
              for x = x0, x1 - 1 do
                local achou = false
                for c = 1, nch do
                  local d = amostras[(x - x0) * nch + c]
                  if d and (d >= thr or d <= -thr) then achou = true break end
                end
                if achou then at = x break end
              end
              local w1 = math.min(total, at + w8)
              local hyst, zc, prev = pv * 0.05, 0, 0
              for x = at, w1 - 1 do
                local y = amostras[(x - x0) * nch + 1] or 0
                local sg = y > hyst and 1 or (y < -hyst and -1 or 0)
                if sg ~= 0 then
                  if prev ~= 0 and sg ~= prev then zc = zc + 1 end
                  prev = sg
                end
              end
              found[#found + 1] = { t = at / sr, amp = pv, zcr = zc / math.max(1e-3, ((w1 - at) / sr) * 1000) }
              last, lastPk, lastPv = k, pk, pv
              k = fim
            end
          end
        end
      end
    end
    return found
  end

  local function steady(fd)
    if #fd < 8 then return false end
    local ok = 0
    for i = 3, #fd do
      local r = (fd[i].t - fd[i - 1].t) / (fd[i - 1].t - fd[i - 2].t)
      if r > 0.85 and r < 1.15 then ok = ok + 1 end
    end
    return ok / (#fd - 2) >= 0.6
  end

  local found = scan(STRICT)
  if #found < math.max(8, duracao / 4) then
    local loose = scan(LOOSE)
    if #loose > #found and steady(loose) then found = loose end
  end
  L.fechar()

  local cls = M.classificar(found)
  local beats = {}
  for i, b in ipairs(found) do beats[i] = b.t end
  return { beats = beats, downbeats = cls.downbeats, beatsPerBar = cls.beatsPerBar, accent = cls.accent }
end

local function split(values, minGap, preferHigh)
  local s = {}
  for i, v in ipairs(values) do s[i] = v end
  table.sort(s)
  local best, idx = 0, -1
  for i = 1, #s - 1 do
    local g = s[i + 1] - s[i]
    if g > best then best = g; idx = i end
  end
  if idx < 0 or best < minGap then return nil end
  local thr = (s[idx] + s[idx + 1]) / 2
  local highFrac = (#s - idx) / #s
  local high
  if highFrac <= 0.45 then high = true elseif highFrac >= 0.55 then high = false else high = preferHigh end
  local frac = high and highFrac or 1 - highFrac
  if frac < 0.05 then return nil end
  return { thr = thr, high = high, score = best / minGap }
end

local function periodicity(down)
  if #down < 3 then return nil end
  local count = {}
  for i = 2, #down do
    local g = down[i] - down[i - 1]
    count[g] = (count[g] or 0) + 1
  end
  local best, bestN = 0, 0
  for g, n in pairs(count) do if n > bestN or (n == bestN and g < best) then bestN = n; best = g end end
  if best < 2 or best > 16 then return nil end
  return bestN / (#down - 1) >= 0.5 and best or nil
end

--- Acha o primeiro tempo de cada compasso (índices começando em 0, como no app).
function M.classificar(found)
  local none = { downbeats = {}, beatsPerBar = nil, accent = nil }
  if #found < 8 then return none end
  local function log10(x) return math.log(x) / math.log(10) end
  local function log2(x) return math.log(x) / math.log(2) end
  local opts = {}
  local vals = {}
  for i, b in ipairs(found) do vals[i] = 20 * log10(b.amp) end
  local vol = split(vals, 2.5, true)
  if vol then opts[#opts + 1] = { accent = "volume", s = vol, key = function(b) return 20 * log10(b.amp) end } end
  vals = {}
  for i, b in ipairs(found) do vals[i] = log2(b.zcr + 0.05) end
  local tone = split(vals, 0.2, true)
  if tone then opts[#opts + 1] = { accent = "tom", s = tone, key = function(b) return log2(b.zcr + 0.05) end } end
  table.sort(opts, function(p, q) return p.s.score > q.s.score end)
  for _, opt in ipairs(opts) do
    local down = {}
    for i, b in ipairs(found) do
      local v = opt.key(b)
      if (opt.s.high and v > opt.s.thr) or (not opt.s.high and v < opt.s.thr) then down[#down + 1] = i - 1 end
    end
    local bpb = periodicity(down)
    if bpb then return { downbeats = down, beatsPerBar = bpb, accent = opt.accent } end
  end
  return none
end

--- Faz a régua do REAPER seguir as batidas: um marcador de andamento em cada batida (o BPM daquela batida até a
--- próxima) e o compasso nos primeiros tempos. `beats` em segundos do projeto. O áudio não estica (fica no tempo).
function M.mapaDeAndamento(beats, downbeats, beatsPerBar, compassoPadrao)
  if #beats < 2 then return 0 end
  local ehDown = {}
  for _, i in ipairs(downbeats or {}) do ehDown[i + 1] = true end
  local num0, den = (compassoPadrao or "4/4"):match("(%d+)/(%d+)")
  num0, den = tonumber(num0) or 4, tonumber(den) or 4
  local temDown = beatsPerBar and #downbeats > 0
  local primeiroDown = temDown and (downbeats[1] + 1) or 1
  local compassoAtual = nil
  local n = 0
  for i = 1, #beats - 1 do
    local dt = beats[i + 1] - beats[i]
    if dt > 0.12 and dt < 3 then
      local bpm = 60 / dt
      local num, d = -1, -1
      if temDown and ehDown[i] and i >= primeiroDown then
        -- quantos tempos até o próximo primeiro tempo (compasso irregular também fica certo)
        local j = i + 1
        while j <= #beats and not ehDown[j] do j = j + 1 end
        local tempos = (j <= #beats) and (j - i) or beatsPerBar
        if tempos ~= compassoAtual or i == primeiroDown then num, d = tempos, den; compassoAtual = tempos end
      elseif not temDown and i == 1 then
        num, d = num0, den
      end
      -- Primeiro só o andamento, no lugar exato. Com o compasso junto, o REAPER puxaria o marcador para o começo do
      -- compasso anterior. Depois: permite compasso incompleto antes dele e só então põe o compasso (começa aqui).
      reaper.SetTempoTimeSigMarker(0, -1, beats[i], -1, -1, bpm, 0, 0, false)
      if num > 0 then
        local idx = reaper.FindTempoTimeSigMarker(0, beats[i] + 1e-6)
        if idx >= 0 then
          if reaper.GetSetTempoTimeSigMarkerFlag then reaper.GetSetTempoTimeSigMarkerFlag(0, idx, 4, true) end
          reaper.SetTempoTimeSigMarker(0, idx, beats[i], -1, -1, bpm, num, d, false)
        end
      end
      n = n + 1
    end
  end
  return n
end

return M
