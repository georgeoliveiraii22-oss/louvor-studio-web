-- LS Live — acende os pads do controlador MIDI: o da parte que está tocando fica aceso, o da parte na fila pisca,
-- e os botões de Tocar, Repetir, Final e Pad acendem quando estão ligados.
--  * Manda a mesma nota (ou CC) que o pad envia, de volta para o controlador (velocidade 127 = aceso, 0 = apagado).
--    Quase todo controlador com luz entende assim; os que não têm luz simplesmente ignoram.
--  * O controlador precisa estar ligado também como SAÍDA em Opções › Preferências › Áudio › Dispositivos MIDI.
--  * Só manda o que mudou (não fica enchendo o cabo de mensagens).
local controles = require("louvor.controles")
local montar = require("louvor.montar")
local M = {}

local EXT = "LouvorStudio"
local enviado = {}          -- chave → valor já mandado
local saida, saidaNome, procuradoEm = nil, nil, -100

function M.ligado() return reaper.GetExtState(EXT, "luzes") ~= "0" end
function M.alternar()
  local on = not M.ligado()
  reaper.SetExtState(EXT, "luzes", on and "1" or "0", true)
  if not on then M.apagar() end
end

--- Lembra qual controlador a pessoa usa (chamado quando chega um botão dele).
function M.lembrarAparelho(nome)
  if nome and nome ~= "" and nome ~= reaper.GetExtState(EXT, "midi_aparelho") then
    reaper.SetExtState(EXT, "midi_aparelho", nome, true)
    procuradoEm = -100
  end
end

local function norm(s) return (tostring(s or ""):lower():gsub("[^%w]", "")) end

--- Índice da saída MIDI do controlador (ou nil se não está ligada como saída).
function M.saida()
  local agora = reaper.time_precise()
  if agora - procuradoEm < 5 then return saida end
  procuradoEm = agora
  local alvo = norm(reaper.GetExtState(EXT, "midi_aparelho"))
  saida, saidaNome = nil, nil
  if alvo == "" then return nil end
  for i = 0, reaper.GetMaxMidiOutputs() - 1 do
    local ok, nome = reaper.GetMIDIOutputName(i, "")
    if ok and nome ~= "" then
      local n = norm(nome)
      if n == alvo or n:find(alvo, 1, true) or alvo:find(n, 1, true) then saida, saidaNome = i, nome break end
    end
  end
  return saida
end
function M.nomeSaida() return saidaNome end

local function mandar(chave, valor)
  if enviado[chave] == valor then return end
  local tipo, canal, num = chave:match("^(%a+):(%d+):(%d+)$")
  if not tipo or not saida then return end
  local st = (tipo == "nota" and 0x90 or 0xB0) + (tonumber(canal) - 1)
  reaper.StuffMIDIMessage(16 + saida, st, tonumber(num), valor)
  enviado[chave] = valor
end

function M.apagar()
  if saida then for chave, v in pairs(enviado) do if v ~= 0 then mandar(chave, 0) end end end
  enviado = {}
end

--- Chamado sempre pela tela no ao vivo. info = { m, pi, fila (parte), tocando, repetir, final, pad, pisca (bool) }
function M.passo(info)
  if not M.ligado() or not M.saida() then return end
  local atual = info.m and info.pi and info.m.partes[info.pi]
  for chave, cmd in pairs(controles.mapa) do
    local v = 0
    local k = tonumber(cmd:match("^p(%d+)$") or "")
    local nome = cmd:match("^n:(.+)$")
    local alvo = k and info.m and info.m.partes[k]
    if nome and info.m then
      for _, p in ipairs(info.m.partes) do if montar.norm(p.nome) == montar.norm(nome) then alvo = alvo or p end end
      if atual and montar.norm(atual.nome) == montar.norm(nome) then alvo = atual end
    end
    if alvo then
      if atual and alvo.idx == atual.idx then v = 127
      elseif info.fila and alvo.idx == info.fila.idx then v = info.pisca and 127 or 0 end
    elseif cmd == "tocar" then v = info.tocando and 127 or 0
    elseif cmd == "repetir" then v = info.repetir and 127 or 0
    elseif cmd == "final" then v = info.final and 127 or 0
    elseif cmd == "pad" then v = info.pad and 127 or 0 end
    mandar(chave, v)
  end
end

return M
