-- LS Live — contagem antes da música (1-2-3-4 só no fone da banda).
--  * Liga/desliga em Configurações › Geral (guardado neste computador: ExtState "contagem").
--  * Para cada música, um compasso de contagem no andamento e no compasso do começo dela, terminando exatamente no
--    começo da música (o "1" mais agudo). O áudio é gerado aqui (um .wav por andamento) e vai numa faixa
--    "Contagem (LS Live)" do tipo click: com as saídas configuradas, sai junto com o click.
--  * Tocar parado no começo de uma música (ou no espaço antes dela) começa pela contagem.
--  * A primeira música começa no 0 do projeto: para caber a contagem, o projeto ganha alguns segundos no começo
--    (o REAPER empurra tudo: faixas, partes, marcadores e andamento).
local http = require("louvor.http")
local M = {}

local EXT = "LouvorStudio"
local NOME_FAIXA = "Contagem (LS Live)"
local SEP = package.config:sub(1, 1)

function M.ligada() return reaper.GetExtState(EXT, "contagem") == "1" end
function M.ligar(sim) reaper.SetExtState(EXT, "contagem", sim and "1" or "0", true) end

--- Onde começa a contagem da música n (nil se não tem).
function M.inicio(n)
  local _, s = reaper.GetProjExtState(0, EXT, "contagem" .. n)
  return tonumber(s)
end

-- .wav de um compasso de contagem: `tempos` bipes de 45 ms, o primeiro mais agudo.
local function gerarWav(bpm, tempos)
  local pasta = http.pasta("contagem")
  local nome = pasta .. SEP .. string.format("contagem_%.2f_%d.wav", bpm, tempos)
  if reaper.file_exists(nome) then return nome end
  local sr = 44100
  local beat = 60 / bpm
  local total = math.floor(beat * tempos * sr)
  local amostras = {}
  for i = 1, total do amostras[i] = 0 end
  for t = 0, tempos - 1 do
    local f = t == 0 and 1760 or 1175
    local ini = math.floor(t * beat * sr)
    local dur = math.floor(0.045 * sr)
    for k = 0, dur - 1 do
      local idx = ini + k + 1
      if idx <= total then
        local env = math.exp(-k / (0.012 * sr))
        amostras[idx] = 0.7 * env * math.sin(2 * math.pi * f * k / sr)
      end
    end
  end
  local partes = {}
  for i = 1, total do
    local v = math.floor(math.max(-1, math.min(1, amostras[i])) * 32767 + 0.5)
    if v < 0 then v = v + 65536 end
    partes[#partes + 1] = string.char(v % 256, math.floor(v / 256))
  end
  local dados = table.concat(partes)
  local function u32(n) return string.char(n % 256, math.floor(n / 256) % 256, math.floor(n / 65536) % 256, math.floor(n / 16777216) % 256) end
  local function u16(n) return string.char(n % 256, math.floor(n / 256) % 256) end
  local cab = "RIFF" .. u32(36 + #dados) .. "WAVE" .. "fmt " .. u32(16) .. u16(1) .. u16(1) .. u32(sr) .. u32(sr * 2) .. u16(2) .. u16(16)
    .. "data" .. u32(#dados)
  local f = io.open(nome, "wb")
  if not f then return nil end
  f:write(cab .. dados)
  f:close()
  return nome
end

local function faixaContagem(criar)
  for i = 0, reaper.CountTracks(0) - 1 do
    local tr = reaper.GetTrack(0, i)
    local _, n = reaper.GetSetMediaTrackInfo_String(tr, "P_NAME", "", false)
    if n == NOME_FAIXA then return tr end
  end
  if not criar then return nil end
  reaper.InsertTrackAtIndex(0, true)
  local tr = reaper.GetTrack(0, 0)
  reaper.GetSetMediaTrackInfo_String(tr, "P_NAME", NOME_FAIXA, true)
  reaper.GetSetMediaTrackInfo_String(tr, "P_EXT:louvor_tipo", "click", true)
  reaper.SetMediaTrackInfo_Value(tr, "I_CUSTOMCOLOR", reaper.ColorToNative(255, 122, 112) | 0x1000000)
  return tr
end

--- Tira a contagem do projeto (a faixa e o que ficou guardado).
function M.tirar(musicas)
  local tr = faixaContagem(false)
  if tr then reaper.DeleteTrack(tr) end
  for n = 1, #(musicas or {}) + 5 do reaper.SetProjExtState(0, EXT, "contagem" .. n, "") end
  reaper.UpdateArrange()
end

--- Põe a contagem antes de cada música. `ler` = função que relê as músicas do projeto (aovivo.ler).
--- Devolve quantas músicas ganharam contagem e a lista das que não couberam.
function M.aplicar(ler)
  local musicas = ler()
  if #musicas == 0 then return 0, {} end
  reaper.Undo_BeginBlock()
  reaper.PreventUIRefresh(1)
  -- espaço no começo para a contagem da primeira música
  local m1 = musicas[1]
  local bpm1 = reaper.TimeMap2_GetDividedBpmAtTime(0, m1.ini + 0.01)
  local num1 = reaper.TimeMap_GetTimeSigAtTime(0, m1.ini + 0.01)
  local precisa = (60 / math.max(20, bpm1)) * math.max(1, num1 or 4) + 1
  if m1.ini < precisa then
    local folga = math.ceil(precisa - m1.ini)
    local a, b = reaper.GetSet_LoopTimeRange2(0, false, false, 0, 0, false)
    reaper.GetSet_LoopTimeRange2(0, true, false, 0, folga, false)
    reaper.Main_OnCommand(40200, 0)   -- Time selection: Insert empty space at time selection (empurra tudo)
    reaper.GetSet_LoopTimeRange2(0, true, false, a, b, false)
    musicas = ler()
  end
  local tr = faixaContagem(true)
  for k = reaper.CountTrackMediaItems(tr) - 1, 0, -1 do reaper.DeleteTrackMediaItem(tr, reaper.GetTrackMediaItem(tr, k)) end
  local feitas, sem = 0, {}
  for n, m in ipairs(musicas) do
    local bpm = reaper.TimeMap2_GetDividedBpmAtTime(0, m.ini + 0.01)
    local num = reaper.TimeMap_GetTimeSigAtTime(0, m.ini + 0.01)
    num = math.max(1, math.min(12, num or 4))
    local len = (60 / math.max(20, bpm)) * num
    local ini = m.ini - len
    local anterior = musicas[n - 1]
    if ini < 0 or (anterior and ini < anterior.fim + 0.2) then
      sem[#sem + 1] = m.nome
      reaper.SetProjExtState(0, EXT, "contagem" .. n, "")
    else
      local wav = gerarWav(bpm, num)
      local src = wav and reaper.PCM_Source_CreateFromFile(wav)
      if src then
        local it = reaper.AddMediaItemToTrack(tr)
        local tk = reaper.AddTakeToMediaItem(it)
        reaper.SetMediaItemTake_Source(tk, src)
        reaper.SetMediaItemInfo_Value(it, "C_BEATATTACHMODE", 0)
        reaper.SetMediaItemInfo_Value(it, "D_POSITION", ini)
        reaper.SetMediaItemInfo_Value(it, "D_LENGTH", len)
        reaper.GetSetMediaItemTakeInfo_String(tk, "P_NAME", "1-2-3-4", true)
        reaper.SetProjExtState(0, EXT, "contagem" .. n, tostring(ini))
        feitas = feitas + 1
      end
    end
  end
  -- com as saídas configuradas, a contagem sai junto com o click
  local okS, saidas = pcall(require, "louvor.saidas")
  if okS then
    local cfg = saidas.carregar()
    if saidas.configurado(cfg) then saidas.aplicar(cfg) end
  end
  reaper.PreventUIRefresh(-1)
  reaper.Undo_EndBlock("LS Live: contagem antes das músicas", -1)
  reaper.UpdateArrange()
  return feitas, sem
end

return M
