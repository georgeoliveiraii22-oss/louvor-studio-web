-- Louvor Studio para o REAPER — deixar a janela "à mão":
--  * abrir sozinho quando o REAPER abrir (uma linha marcada no Scripts/__startup.lua, sem mexer no resto do arquivo);
--  * um botão com o ícone do app numa barra pequena só dele (a barra flutuante 16; a barra principal não é tocada);
--  * o atalho de teclado (a janela de atalhos do próprio REAPER).
local M = {}

-- Versão do LS Live. Mudou o código para as bandas? Suba aqui: o empacotar.py grava o mesmo número em
-- mobile/ls-live/versao.json, e o LS Live de cada um avisa que tem versão nova.
M.VERSAO = "1.2.2"
M.SITE_VERSAO = "https://louvorstudio.app.br/ls-live/versao.json"
M.SITE_ZIP = "https://louvorstudio.app.br/ls-live/LS-Live.zip"

M.cmd = nil        -- número da ação deste script (vem do arquivo de entrada)
M.entrada = nil    -- nome do arquivo de entrada ("LS Live.lua" ou "Louvor Studio.lua")
M.pastaScript = nil
local MARCA = "-- louvor-studio-inicio"
local BARRA = "Floating toolbar 16"
local ABRIR_BARRA = 41943   -- Toolbar: Open/close toolbar 16

local SEP = package.config:sub(1, 1)
local function recurso(...) return table.concat({ reaper.GetResourcePath(), ... }, SEP) end
local function ler(p) local f = io.open(p, "rb") if not f then return nil end local s = f:read("*a") f:close() return s end
local function escrever(p, s) local f = io.open(p, "wb") if not f then return false end f:write(s) f:close() return true end

--- "_RSxxxx" da ação (o mesmo em qualquer abertura do REAPER).
function M.nomeDaAcao()
  if not M.cmd or M.cmd <= 0 then return nil end
  local n = reaper.ReverseNamedCommandLookup(M.cmd)
  return n and ("_" .. n) or nil
end

-- Abrir junto com o REAPER ---------------------------------------------------------------------------
function M.inicioLigado()
  local s = ler(recurso("Scripts", "__startup.lua")) or ""
  return s:find(MARCA, 1, true) ~= nil
end

function M.alternarInicio()
  local p = recurso("Scripts", "__startup.lua")
  local s = ler(p) or ""
  if s:find(MARCA, 1, true) then
    local linhas = {}
    for l in (s .. "\n"):gmatch("(.-)\r?\n") do if not l:find(MARCA, 1, true) then linhas[#linhas + 1] = l end end
    while #linhas > 0 and linhas[#linhas] == "" do linhas[#linhas] = nil end
    escrever(p, #linhas > 0 and (table.concat(linhas, "\n") .. "\n") or "")
    return false
  end
  local nome = M.nomeDaAcao()
  if not nome then return false, "Abra o LS Live pela lista de ações uma vez e tente de novo." end
  local linha = string.format('reaper.defer(function() local c = reaper.NamedCommandLookup("%s") if c > 0 then reaper.Main_OnCommand(c, 0) end end) %s', nome, MARCA)
  if s ~= "" and not s:match("\n$") then s = s .. "\n" end
  escrever(p, s .. linha .. "\n")
  return true
end

-- Botão na barra ----------------------------------------------------------------------------------
local function copiar(de, para)
  local s = ler(de)
  if s then escrever(para, s) return true end
  return false
end

function M.botaoInstalado()
  local s = ler(recurso("reaper-menu.ini")) or ""
  local nome = M.nomeDaAcao()
  return nome ~= nil and s:find("[" .. BARRA .. "]", 1, true) ~= nil and s:find(nome, 1, true) ~= nil
end

--- Põe o botão. Devolve true, ou false e o motivo. Se a barra 16 já for usada para outra coisa, não mexe.
function M.instalarBotao()
  local nome = M.nomeDaAcao()
  if not nome then return false, "Abra o LS Live pela lista de ações uma vez e tente de novo." end
  -- ícone (30, 45 e 60 px) vai para a pasta de ícones das barras
  local ic = (M.pastaScript or "") .. "icones" .. SEP
  copiar(ic .. "louvor_studio.png", recurso("Data", "toolbar_icons", "louvor_studio.png"))
  copiar(ic .. "louvor_studio_150.png", recurso("Data", "toolbar_icons", "150", "louvor_studio.png"))
  copiar(ic .. "louvor_studio_200.png", recurso("Data", "toolbar_icons", "200", "louvor_studio.png"))
  local p = recurso("reaper-menu.ini")
  local s = ler(p) or ""
  if not s:find("[" .. BARRA .. "]", 1, true) then
    if s ~= "" and not s:match("\n$") then s = s .. "\n" end
    s = s .. "[" .. BARRA .. "]\nicon_0=louvor_studio.png\nitem_0=" .. nome .. " Abrir o LS Live\ntitle=LS Live\n"
    if not escrever(p, s) then return false, "Não deu para gravar o arquivo de menus do REAPER." end
  elseif not s:find(nome, 1, true) then
    return false, "A barra 16 do REAPER já está sendo usada. Ponha o botão à mão: clique com o botão direito numa barra › Personalizar."
  end
  M.garantirBarra()
  return true
end

-- Linha do __startup.lua que reabre a barrinha toda vez que o REAPER abre (fechar no X sem querer não some com ela).
local MARCA_BARRA = "-- louvor-studio-barra"
local function linhaDaBarraNoInicio()
  local p = recurso("Scripts", "__startup.lua")
  local s = ler(p) or ""
  if s:find(MARCA_BARRA, 1, true) then return end
  if s ~= "" and not s:match("\n$") then s = s .. "\n" end
  escrever(p, s .. string.format("reaper.defer(function() if reaper.GetToggleCommandState(%d) ~= 1 then reaper.Main_OnCommand(%d, 0) end end) %s\n",
    ABRIR_BARRA, ABRIR_BARRA, MARCA_BARRA))
end

--- Se o botão está instalado: deixa a barrinha aberta agora e ao abrir o REAPER.
function M.garantirBarra()
  if not M.botaoInstalado() then return false end
  linhaDaBarraNoInicio()
  if reaper.GetToggleCommandState(ABRIR_BARRA) ~= 1 then reaper.Main_OnCommand(ABRIR_BARRA, 0) end
  return true
end

--- Lê um arquivo que vem junto com o LS Live (ao lado do script de entrada).
function M.lerArquivo(nome)
  return ler((M.pastaScript or "") .. nome)
end

--- Abre a tela grande do ministro (cria a ação na primeira vez). Devolve true ou false + mensagem.
function M.abrirMinistro()
  local caminho = (M.pastaScript or "") .. "LS Live - Tela do ministro.lua"
  if not reaper.file_exists(caminho) then return false, "Falta o arquivo da tela do ministro. Atualize o LS Live (Geral › Versão)." end
  local cmd = reaper.AddRemoveReaScript(true, 0, caminho, true)
  if not cmd or cmd == 0 then return false, "O REAPER não abriu a tela do ministro." end
  reaper.Main_OnCommand(cmd, 0)
  return true
end

-- Versão nova ---------------------------------------------------------------------------------------
--- "1.10.0" > "1.9.2"?
function M.maisNova(a, b)
  local x, y = {}, {}
  for n in tostring(a):gmatch("%d+") do x[#x + 1] = tonumber(n) end
  for n in tostring(b):gmatch("%d+") do y[#y + 1] = tonumber(n) end
  for i = 1, math.max(#x, #y) do
    local p, q = x[i] or 0, y[i] or 0
    if p ~= q then return p > q end
  end
  return false
end

--- Confere no site se há versão nova (no máximo uma vez a cada 12 h, a não ser com `agora`). Devolve a versão nova ou nil.
function M.verificarVersao(agora)
  local ultima = tonumber(reaper.GetExtState("LouvorStudio", "versao_conferida")) or 0
  if not agora and os.time() - ultima < 12 * 3600 then
    local v = reaper.GetExtState("LouvorStudio", "versao_site")
    return (v ~= "" and M.maisNova(v, M.VERSAO)) and v or nil
  end
  local http = require("louvor.http")
  local code, d = http.pedido(M.SITE_VERSAO .. "?t=" .. os.time(), { timeout = 5 })
  if code ~= 200 or type(d) ~= "table" or type(d.versao) ~= "string" then return nil end
  reaper.SetExtState("LouvorStudio", "versao_conferida", tostring(os.time()), true)
  reaper.SetExtState("LouvorStudio", "versao_site", d.versao, true)
  return M.maisNova(d.versao, M.VERSAO) and d.versao or nil
end

--- Baixa o .zip do site e troca os arquivos desta instalação. Devolve true ou false + mensagem.
--- (O LS Live que está aberto continua o antigo até fechar e abrir de novo.)
function M.atualizar()
  local http = require("louvor.http")
  if not M.pastaScript or M.pastaScript == "" then return false, "Não achei a pasta do LS Live." end
  local tmp = http.pasta("atualizacao")
  local zip = tmp .. SEP .. "LS-Live.zip"
  local dest = tmp .. SEP .. "novo"
  os.remove(zip)
  local curl = http.WIN and "curl.exe" or "/usr/bin/curl"
  local r = reaper.ExecProcess('"' .. curl .. '" -sSfL --max-time 120 -o "' .. zip .. '" "' .. M.SITE_ZIP .. '"', 130000)
  if not reaper.file_exists(zip) then return false, "Não deu para baixar a versão nova. Confira a internet." end
  if http.WIN then
    reaper.ExecProcess('powershell.exe -NoProfile -Command "Remove-Item -Recurse -Force -ErrorAction SilentlyContinue \'' .. dest ..
      '\'; Expand-Archive -Force \'' .. zip .. '\' \'' .. dest .. '\'"', 60000)
  else
    reaper.ExecProcess('/bin/sh -c "rm -rf \'' .. dest .. '\' && /usr/bin/unzip -o -q \'' .. zip .. '\' -d \'' .. dest .. '\'"', 60000)
  end
  local origem = dest .. SEP .. "LS Live" .. SEP
  if not reaper.file_exists(origem .. "LS Live.lua") then return false, "O arquivo baixado veio incompleto. Tente de novo." end
  local copiados = 0
  local function copiarDe(rel, para)
    local s = ler(origem .. rel)
    if s and escrever(M.pastaScript .. para, s) then copiados = copiados + 1 end
  end
  copiarDe("LS Live.lua", M.entrada or "LS Live.lua")
  local i = 0
  while true do
    local n = reaper.EnumerateFiles(origem .. "louvor", i)
    if not n then break end
    if n:match("%.lua$") then copiarDe("louvor" .. SEP .. n, "louvor" .. SEP .. n) end
    i = i + 1
  end
  i = 0
  reaper.RecursiveCreateDirectory(M.pastaScript .. "icones", 0)
  while true do
    local n = reaper.EnumerateFiles(origem .. "icones", i)
    if not n then break end
    copiarDe("icones" .. SEP .. n, "icones" .. SEP .. n)
    i = i + 1
  end
  for n in ("Instalar o LS Live.lua|LS Live - Tela do ministro.lua"):gmatch("[^|]+") do
    if reaper.file_exists(origem .. n) then copiarDe(n, n) end
  end
  if copiados < 5 then return false, "Não deu para trocar os arquivos (" .. copiados .. " copiados)." end
  reaper.SetExtState("LouvorStudio", "versao_conferida", "", true)
  return true, copiados
end

-- Atalho de teclado ---------------------------------------------------------------------------------
function M.atalho()
  if not M.cmd then return nil end
  local n = reaper.CountActionShortcuts(0, M.cmd)
  if n == 0 then return nil end
  local ok, d = reaper.GetActionShortcutDesc(0, M.cmd, 0, "")
  return ok and d ~= "" and d or nil
end

function M.trocarAtalho()
  if not M.cmd then return end
  local sec = reaper.SectionFromUniqueID and reaper.SectionFromUniqueID(0) or 0
  reaper.DoActionShortcutDialog(reaper.GetMainHwnd(), sec, M.cmd, reaper.CountActionShortcuts(0, M.cmd) > 0 and 0 or 0)
end

return M
