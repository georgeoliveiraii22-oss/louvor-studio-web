-- Louvor Studio para o REAPER — deixar a janela "à mão":
--  * abrir sozinho quando o REAPER abrir (uma linha marcada no Scripts/__startup.lua, sem mexer no resto do arquivo);
--  * um botão com o ícone do app numa barra pequena só dele (a barra flutuante 16; a barra principal não é tocada);
--  * o atalho de teclado (a janela de atalhos do próprio REAPER).
local M = {}

M.cmd = nil        -- número da ação deste script (vem do arquivo de entrada)
M.pastaScript = nil
local MARCA = "-- louvor-studio-inicio"
local BARRA = "Floating toolbar 16"
local ABRIR_BARRA = 41943   -- Toolbar: Open/close toolbar 16

local SEP = package.config:sub(1, 1)
local function recurso(...) return table.concat({ reaper.GetResourcePath(), ... }, SEP) end
local function ler(p) local f = io.open(p, "rb") if not f then return nil end local s = f:read("*a") f:close() return s end
local function escrever(p, s) local f = io.open(p, "wb") if not f then return false end f:write(s) f:close() return true end

--- "_RSxxxx" da ação (o mesmo em qualquer abertura do REAPER).
function M.nomeDaAcao()
  if not M.cmd or M.cmd <= 0 then return nil end
  local n = reaper.ReverseNamedCommandLookup(M.cmd)
  return n and ("_" .. n) or nil
end

-- Abrir junto com o REAPER ---------------------------------------------------------------------------
function M.inicioLigado()
  local s = ler(recurso("Scripts", "__startup.lua")) or ""
  return s:find(MARCA, 1, true) ~= nil
end

function M.alternarInicio()
  local p = recurso("Scripts", "__startup.lua")
  local s = ler(p) or ""
  if s:find(MARCA, 1, true) then
    local linhas = {}
    for l in (s .. "\n"):gmatch("(.-)\r?\n") do if not l:find(MARCA, 1, true) then linhas[#linhas + 1] = l end end
    while #linhas > 0 and linhas[#linhas] == "" do linhas[#linhas] = nil end
    escrever(p, #linhas > 0 and (table.concat(linhas, "\n") .. "\n") or "")
    return false
  end
  local nome = M.nomeDaAcao()
  if not nome then return false, "Abra o LS Live pela lista de ações uma vez e tente de novo." end
  local linha = string.format('reaper.defer(function() local c = reaper.NamedCommandLookup("%s") if c > 0 then reaper.Main_OnCommand(c, 0) end end) %s', nome, MARCA)
  if s ~= "" and not s:match("\n$") then s = s .. "\n" end
  escrever(p, s .. linha .. "\n")
  return true
end

-- Botão na barra ----------------------------------------------------------------------------------
local function copiar(de, para)
  local s = ler(de)
  if s then escrever(para, s) return true end
  return false
end

function M.botaoInstalado()
  local s = ler(recurso("reaper-menu.ini")) or ""
  local nome = M.nomeDaAcao()
  return nome ~= nil and s:find("[" .. BARRA .. "]", 1, true) ~= nil and s:find(nome, 1, true) ~= nil
end

--- Põe o botão. Devolve true, ou false e o motivo. Se a barra 16 já for usada para outra coisa, não mexe.
function M.instalarBotao()
  local nome = M.nomeDaAcao()
  if not nome then return false, "Abra o LS Live pela lista de ações uma vez e tente de novo." end
  -- ícone (30, 45 e 60 px) vai para a pasta de ícones das barras
  local ic = (M.pastaScript or "") .. "icones" .. SEP
  copiar(ic .. "louvor_studio.png", recurso("Data", "toolbar_icons", "louvor_studio.png"))
  copiar(ic .. "louvor_studio_150.png", recurso("Data", "toolbar_icons", "150", "louvor_studio.png"))
  copiar(ic .. "louvor_studio_200.png", recurso("Data", "toolbar_icons", "200", "louvor_studio.png"))
  local p = recurso("reaper-menu.ini")
  local s = ler(p) or ""
  if not s:find("[" .. BARRA .. "]", 1, true) then
    if s ~= "" and not s:match("\n$") then s = s .. "\n" end
    s = s .. "[" .. BARRA .. "]\nicon_0=louvor_studio.png\nitem_0=" .. nome .. " Abrir o LS Live\ntitle=LS Live\n"
    if not escrever(p, s) then return false, "Não deu para gravar o arquivo de menus do REAPER." end
  elseif not s:find(nome, 1, true) then
    return false, "A barra 16 do REAPER já está sendo usada. Ponha o botão à mão: clique com o botão direito numa barra › Personalizar."
  end
  M.garantirBarra()
  return true
end

-- Linha do __startup.lua que reabre a barrinha toda vez que o REAPER abre (fechar no X sem querer não some com ela).
local MARCA_BARRA = "-- louvor-studio-barra"
local function linhaDaBarraNoInicio()
  local p = recurso("Scripts", "__startup.lua")
  local s = ler(p) or ""
  if s:find(MARCA_BARRA, 1, true) then return end
  if s ~= "" and not s:match("\n$") then s = s .. "\n" end
  escrever(p, s .. string.format("reaper.defer(function() if reaper.GetToggleCommandState(%d) ~= 1 then reaper.Main_OnCommand(%d, 0) end end) %s\n",
    ABRIR_BARRA, ABRIR_BARRA, MARCA_BARRA))
end

--- Se o botão está instalado: deixa a barrinha aberta agora e ao abrir o REAPER.
function M.garantirBarra()
  if not M.botaoInstalado() then return false end
  linhaDaBarraNoInicio()
  if reaper.GetToggleCommandState(ABRIR_BARRA) ~= 1 then reaper.Main_OnCommand(ABRIR_BARRA, 0) end
  return true
end

-- Atalho de teclado ---------------------------------------------------------------------------------
function M.atalho()
  if not M.cmd then return nil end
  local n = reaper.CountActionShortcuts(0, M.cmd)
  if n == 0 then return nil end
  local ok, d = reaper.GetActionShortcutDesc(0, M.cmd, 0, "")
  return ok and d ~= "" and d or nil
end

function M.trocarAtalho()
  if not M.cmd then return end
  local sec = reaper.SectionFromUniqueID and reaper.SectionFromUniqueID(0) or 0
  reaper.DoActionShortcutDialog(reaper.GetMainHwnd(), sec, M.cmd, reaper.CountActionShortcuts(0, M.cmd) > 0 and 0 or 0)
end

return M
