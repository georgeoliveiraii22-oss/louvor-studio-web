-- LS Live — tom e andamento de cada música, na hora.
--  * Tom: sobe ou desce meio tom em todas as faixas da música (menos o click e a guia, que não têm nota), sem mudar
--    o andamento. É o "pitch" de cada take do REAPER; o áudio original não muda.
--  * Andamento: mais rápido ou mais lento sem mudar o tom. É a velocidade geral do REAPER (master playrate) com
--    "manter o tom" ligado; muda sozinha quando a música muda, para cada música tocar no andamento escolhido.
--  * O ajuste de cada música fica guardado no projeto ("ajuste<n>").
--  * Tom da multitrack (musical_key) e tom do dia (o da escala) vêm da montagem (louvor/partes.lua › info).
local json = require("louvor.json")
local M = {}

local EXT = "LouvorStudio"
local MANTER_TOM = 40671   -- Transport: Toggle preserve pitch in audio items when changing master playrate
local SEM_NOTA = { click = true, guia = true }

local LETRA = { C = 0, D = 2, E = 4, F = 5, G = 7, A = 9, B = 11 }
local MAIOR = { "C", "C#", "D", "Eb", "E", "F", "F#", "G", "Ab", "A", "Bb", "B" }
local MENOR = { "C", "C#", "D", "Eb", "E", "F", "F#", "G", "G#", "A", "Bb", "B" }

--- "F#m" → 6, true, "m". Devolve nil se não for um tom.
function M.ler(tom)
  if type(tom) ~= "string" then return nil end
  local l, resto = tom:match("^%s*([A-Ga-g])(.-)%s*$")
  if not l then return nil end
  local ac = ""
  if resto:sub(1, 1) == "#" or resto:sub(1, 1) == "b" then ac, resto = resto:sub(1, 1), resto:sub(2)
  elseif resto:sub(1, 3) == "♯" then ac, resto = "#", resto:sub(4)
  elseif resto:sub(1, 3) == "♭" then ac, resto = "b", resto:sub(4) end
  local pc = LETRA[l:upper()] + (ac == "#" and 1 or ac == "b" and -1 or 0)
  pc = pc % 12
  local menor = resto:sub(1, 1) == "m" and resto:sub(1, 3) ~= "maj"
  return pc, menor, resto
end

--- O tom "tom" mudado "semi" meios tons ("G", 2 → "A"; "Em", 1 → "Fm").
function M.transpor(tom, semi)
  local pc, menor, resto = M.ler(tom)
  if not pc then return tom end
  local n = (pc + (semi or 0)) % 12
  return (menor and MENOR or MAIOR)[n + 1] .. resto
end

--- Quantos meios tons de "de" para "para", pelo caminho mais curto (−5 a +6).
function M.diferenca(de, para)
  local a, b = M.ler(de), M.ler(para)
  if not a or not b then return nil end
  local d = (b - a) % 12
  if d > 6 then d = d - 12 end
  return d
end

-- Ajuste guardado da música n: { semi = 0, taxa = 1 }.
function M.ajuste(n)
  local _, s = reaper.GetProjExtState(0, EXT, "ajuste" .. n)
  local t = s ~= "" and json.decode(s) or nil
  t = type(t) == "table" and t or {}
  return { semi = tonumber(t.semi) or 0, taxa = tonumber(t.taxa) or 1 }
end
local function guardar(n, a)
  reaper.SetProjExtState(0, EXT, "ajuste" .. n, json.encode(json.object({ semi = a.semi, taxa = a.taxa })))
end

--- Tom da multitrack e tom do dia da música n (da montagem). Qualquer um pode ser nil.
function M.tons(n)
  local partes = require("louvor.partes")
  local info = partes.info(n) or {}
  return info.tomMultitrack, info.tomDia
end

--- O tom que está soando na música n (o da multitrack com o ajuste), ou nil se a ficha não tem tom.
function M.soando(n)
  local multi, dia = M.tons(n)
  local base = multi or dia
  if not base then return nil end
  return M.transpor(base, M.ajuste(n).semi)
end

--- Meios tons para chegar ao tom do dia (nil se não dá para saber ou se já está nele).
function M.paraOTomDoDia(n)
  local multi, dia = M.tons(n)
  if not multi or not dia then return nil end
  local d = M.diferenca(multi, dia)
  if not d or d == M.ajuste(n).semi then return nil end
  return d
end

local function tipo(tr)
  local _, t = reaper.GetSetMediaTrackInfo_String(tr, "P_EXT:louvor_tipo", "", false)
  return t
end

--- Põe o tom em todos os itens da música m (de aovivo.ler), menos click e guia.
local function aplicarSemi(m, semi)
  for i = 0, reaper.CountMediaItems(0) - 1 do
    local it = reaper.GetMediaItem(0, i)
    local pos = reaper.GetMediaItemInfo_Value(it, "D_POSITION")
    if pos >= m.ini - 1 and pos < m.fim then
      local tr = reaper.GetMediaItem_Track(it)
      if not SEM_NOTA[tipo(tr)] and not select(2, reaper.GetSetMediaTrackInfo_String(tr, "P_EXT:louvor_pad", "", false)):find("1") then
        for k = 0, reaper.CountTakes(it) - 1 do
          local tk = reaper.GetTake(it, k)
          if tk and not reaper.TakeIsMIDI(tk) then
            reaper.SetMediaItemTakeInfo_Value(tk, "D_PITCH", semi)
            reaper.SetMediaItemTakeInfo_Value(tk, "B_PPITCH", 1)
          end
        end
      end
    end
  end
  reaper.UpdateArrange()
end

--- Muda o tom da música n (m = a música lida por aovivo) para "semi" meios tons (−6 a +6).
function M.definirSemi(n, m, semi)
  semi = math.max(-6, math.min(6, math.floor(semi + 0.5)))
  local a = M.ajuste(n)
  if a.semi == semi then return semi end
  a.semi = semi
  guardar(n, a)
  aplicarSemi(m, semi)
  return semi
end

function M.mudarTom(n, m, delta) return M.definirSemi(n, m, M.ajuste(n).semi + delta) end

--- Andamento do projeto no começo da música (segue o click), sem a velocidade geral.
function M.bpmBase(m)
  local b = reaper.TimeMap2_GetDividedBpmAtTime(0, m.ini + 0.05)
  return (b and b > 0) and b or nil
end

--- BPM que a música vai tocar (com o ajuste), ou nil sem andamento.
function M.bpm(n, m)
  local b = M.bpmBase(m)
  return b and (b * M.ajuste(n).taxa) or nil
end

--- Mais rápido / mais lento: 1 BPM por toque (sem BPM conhecido, 2% por toque). Entre 75% e 125%.
function M.mudarAndamento(n, m, delta)
  local a = M.ajuste(n)
  local b = M.bpmBase(m)
  local taxa
  if b then
    local alvo = math.floor(b * a.taxa + 0.5) + delta
    taxa = alvo / b
  else
    taxa = a.taxa + 0.02 * delta
  end
  taxa = math.max(0.75, math.min(1.25, taxa))
  if math.abs(taxa - 1) < 0.004 then taxa = 1 end
  a.taxa = math.floor(taxa * 10000 + 0.5) / 10000
  guardar(n, a)
  M.sincronizar(n, true)
  return a.taxa
end

--- Volta o andamento da música n ao original.
function M.andamentoOriginal(n)
  local a = M.ajuste(n)
  a.taxa = 1
  guardar(n, a)
  M.sincronizar(n, true)
end

local ultimaMusica = nil
--- Chamado sempre pela tela: a velocidade geral acompanha a música onde o cursor está.
function M.sincronizar(n, forcar)
  if not n then return end
  if n == ultimaMusica and not forcar then return end
  ultimaMusica = n
  if reaper.GetToggleCommandState(MANTER_TOM) == 0 then reaper.Main_OnCommand(MANTER_TOM, 0) end
  local taxa = M.ajuste(n).taxa
  if math.abs(reaper.Master_GetPlayRate(0) - taxa) > 0.0005 then reaper.CSurf_OnPlayRateChange(taxa) end
end

--- Esquece a música da velocidade (ao montar outra escala ou trocar de projeto).
function M.reiniciar() ultimaMusica = nil end

return M
