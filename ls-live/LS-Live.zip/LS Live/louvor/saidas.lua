-- Louvor Studio para o REAPER — saídas de áudio (placa de som).
--  * Cada saída da placa recebe um nome ("Click/Guia", "VS", "Teclado L", "Teclado R"…). Nomes que terminam em
--    " L" e " R" formam um par estéreo ("Teclado" = saídas 3 e 4).
--  * Cada tipo de faixa (click, guia, bateria, teclados…) vai para um desses destinos; dá para mudar faixa por
--    faixa (fica na própria faixa, P_EXT:louvor_saida).
--  * Opcional: tirar as faixas do master, para saírem só pelas saídas escolhidas.
-- Só mexe nas faixas montadas pelo Louvor Studio (as que têm P_EXT:louvor_tipo). Fica guardado neste computador.
local json = require("louvor.json")
local M = {}

local EXT = "LouvorStudio"
M.MASTER = "Master"   -- destino "sem saída direta" (segue pelo master, como sempre)

M.SUGESTOES = { "Click/Guia", "Click", "Guia", "VS", "VS L", "VS R", "Teclado L", "Teclado R", "Bateria", "Baixo",
  "Guitarra", "Violão", "Vozes", "Fone L", "Fone R" }

function M.padrao()
  return { nomes = {}, tipos = {}, semMaster = false }
end

function M.carregar()
  local s = reaper.GetExtState(EXT, "saidas")
  local t = s ~= "" and json.decode(s) or nil
  local c = M.padrao()
  if type(t) == "table" then
    if type(t.nomes) == "table" then for k, v in pairs(t.nomes) do if tonumber(k) and type(v) == "string" then c.nomes[tonumber(k)] = v end end end
    if type(t.tipos) == "table" then for k, v in pairs(t.tipos) do if type(v) == "string" then c.tipos[k] = v end end end
    c.semMaster = t.semMaster == true
  end
  return c
end

function M.salvar(c)
  local nomes = {}
  for k, v in pairs(c.nomes) do if v ~= "" then nomes[tostring(k)] = v end end
  reaper.SetExtState(EXT, "saidas", json.encode({ nomes = json.object(nomes), tipos = json.object(c.tipos), semMaster = c.semMaster }), true)
end

--- O modelo da igreja do usuário: 1 Click/Guia, 2 VS, 3 Teclado L, 4 Teclado R.
function M.modelo4()
  return { nomes = { [1] = "Click/Guia", [2] = "VS", [3] = "Teclado L", [4] = "Teclado R" },
    tipos = { click = "Click/Guia", guia = "Click/Guia", teclas = "Teclado", bateria = "VS", percussao = "VS", baixo = "VS",
      guitarras = "VS", vozes = "VS", outros = "VS" }, semMaster = true }
end

--- Saídas da placa aberta no REAPER: { {n = 1, nome = "Speakers 1"}, ... } (vazio se a placa estiver fechada).
function M.saidasDaPlaca()
  local out = {}
  for i = 0, (reaper.GetNumAudioOutputs() or 0) - 1 do
    local nome = reaper.GetOutputChannelName(i) or ""
    out[#out + 1] = { n = i + 1, nome = nome ~= "" and nome or ("Saída " .. (i + 1)) }
  end
  return out
end

--- Destinos a partir dos nomes: { {nome, l = canal (1…), r = canal ou nil} }, na ordem das saídas.
function M.destinos(c)
  local porNome, ordem = {}, {}
  local ns = {}
  for k in pairs(c.nomes) do ns[#ns + 1] = k end
  table.sort(ns)
  for _, k in ipairs(ns) do
    local nome = (c.nomes[k] or ""):gsub("^%s+", ""):gsub("%s+$", "")
    if nome ~= "" then
      local base, lado = nome:match("^(.-)%s+([LRlr])$")
      if base and base ~= "" then
        local d = porNome[base]
        if not d then d = { nome = base }; porNome[base] = d; ordem[#ordem + 1] = d end
        if lado:upper() == "L" then d.l = d.l or k else d.r = d.r or k end
      elseif not porNome[nome] then
        local d = { nome = nome, l = k }
        porNome[nome] = d; ordem[#ordem + 1] = d
      end
    end
  end
  -- só R (sem L): vira mono naquela saída
  for _, d in ipairs(ordem) do if not d.l then d.l, d.r = d.r, nil end end
  return ordem, porNome
end

--- Texto curto das saídas de um destino ("1", "3+4").
function M.canais(d) return d.r and (d.l .. "+" .. d.r) or tostring(d.l) end

local function tipo(tr)
  local _, t = reaper.GetSetMediaTrackInfo_String(tr, "P_EXT:louvor_tipo", "", false)
  return t ~= "" and t or nil
end
M.tipo = tipo

function M.destinoDaFaixa(c, tr)
  local _, s = reaper.GetSetMediaTrackInfo_String(tr, "P_EXT:louvor_saida", "", false)
  if s ~= "" then return s, true end
  local t = tipo(tr)
  return t and c.tipos[t] or nil, false
end

--- Muda o destino só desta faixa (nil = volta a seguir o tipo).
function M.destinoDaFaixaDefinir(tr, nome)
  reaper.GetSetMediaTrackInfo_String(tr, "P_EXT:louvor_saida", nome or "", true)
end

--- Faixas do projeto montadas pelo Louvor Studio.
function M.faixas()
  local out = {}
  for i = 0, reaper.CountTracks(0) - 1 do
    local tr = reaper.GetTrack(0, i)
    if tipo(tr) then out[#out + 1] = tr end
  end
  return out
end

local function limpar(tr)
  for k = reaper.GetTrackNumSends(tr, 1) - 1, 0, -1 do reaper.RemoveTrackSend(tr, 1, k) end
end

local function envio(tr, src, dst)
  local k = reaper.CreateTrackSend(tr, nil)
  if k < 0 then return end
  reaper.SetTrackSendInfo_Value(tr, 1, k, "I_SRCCHAN", src)
  reaper.SetTrackSendInfo_Value(tr, 1, k, "I_DSTCHAN", dst)
  reaper.SetTrackSendInfo_Value(tr, 1, k, "D_VOL", 1)
end

--- Liga as faixas às saídas. Devolve { ligadas, noMaster, semDestino }.
function M.aplicar(c)
  local _, porNome = M.destinos(c)
  local r = { ligadas = 0, noMaster = 0, semDestino = 0 }
  reaper.Undo_BeginBlock()
  for _, tr in ipairs(M.faixas()) do
    limpar(tr)
    local nome = M.destinoDaFaixa(c, tr)
    local d = nome and nome ~= M.MASTER and porNome[nome] or nil
    if d then
      if d.r and d.r == d.l + 1 then
        envio(tr, 0, d.l - 1)                                  -- estéreo: faixa 1/2 → saídas L/R
      elseif d.r then
        envio(tr, 0 | 1024, (d.l - 1) | 1024)                  -- L e R separados (não vizinhas)
        envio(tr, 1 | 1024, (d.r - 1) | 1024)
      else
        envio(tr, 0, (d.l - 1) | 1024)                         -- mono: as duas metades somadas numa saída
      end
      r.ligadas = r.ligadas + 1
    else
      r.semDestino = r.semDestino + 1
    end
    -- sem master só quando a faixa tem para onde ir (senão ela ficaria muda)
    local semMaster = c.semMaster and d ~= nil
    reaper.SetMediaTrackInfo_Value(tr, "B_MAINSEND", semMaster and 0 or 1)
    if not semMaster then r.noMaster = r.noMaster + 1 end
  end
  reaper.Undo_EndBlock("Louvor Studio: saídas de áudio", -1)
  reaper.TrackList_AdjustWindows(false)
  return r
end

--- Alguma saída configurada?
function M.configurado(c) local ds = M.destinos(c) return #ds > 0 end

return M
