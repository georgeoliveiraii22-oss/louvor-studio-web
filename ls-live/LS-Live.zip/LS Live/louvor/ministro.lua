-- LS Live — tela grande do ministro: uma janela separada (para um segundo monitor ou TV) só com a música, a parte
-- de agora bem grande, quanto falta e a próxima. Lê o mesmo estado que o LS Live publica para o celular
-- (ExtState "LouvorStudio/remoto_estado", louvor/remoto.lua). Abre pelo LS Live (Configurações › Ao vivo e celular ›
-- Tela grande do ministro) ou pela ação "LS Live - Tela do ministro".
local json = require("louvor.json")
local M = {}

local FONTE = reaper.GetOS():find("Win") and "Segoe UI" or "Helvetica"
local function cor(hex, a)
  local r, g, b = (hex or "#DCE8F2"):match("#?(%x%x)(%x%x)(%x%x)")
  gfx.set(tonumber(r, 16) / 255, tonumber(g, 16) / 255, tonumber(b, 16) / 255, a or 1)
end
local function fonte(id, tam, negrito) gfx.setfont(id, FONTE, math.max(8, math.floor(tam)), negrito and string.byte("b") or 0) end
local function cortar(s, larg)
  if gfx.measurestr(s) <= larg then return s end
  while #s > 1 and gfx.measurestr(s .. "…") > larg do s = s:sub(1, -2) end
  return s .. "…"
end
local function centro(s, x, y, w)
  local tw = gfx.measurestr(s)
  gfx.x, gfx.y = x + (w - tw) / 2, y
  gfx.drawstr(s)
end
local function tempo(s) s = math.max(0, s or 0) return string.format("%d:%02d", math.floor(s / 60), math.floor(s % 60)) end

function M.abrir()
  local d = tonumber(reaper.GetExtState("LouvorStudio", "ministro_dock")) or 0
  gfx.init("LS Live · Tela do ministro", 960, 540, d)
  local function quadro()
    local W, H = gfx.w, gfx.h
    local u = math.min(W / 960, H / 540)
    cor("#050B12"); gfx.rect(0, 0, W, H, 1)
    local s = reaper.GetExtState("LouvorStudio", "remoto_estado")
    local st = s ~= "" and json.decode(s) or nil
    if type(st) ~= "table" or not st.aovivo or (st.titulo or "") == "" then
      fonte(1, 34 * u, true); cor("#8FA9BF")
      centro("Abra o modo ao vivo do LS Live", 0, H / 2 - 20 * u, W)
      return
    end
    -- música e posição
    fonte(1, 30 * u, true); cor("#F5FAFF")
    gfx.x, gfx.y = 40 * u, 28 * u
    gfx.drawstr(cortar(st.titulo, W - 300 * u))
    fonte(2, 22 * u, false); cor("#8FA9BF")
    local pos = "Música " .. (st.mi or 0) .. " de " .. (st.total or 0)
    if st.tom then pos = pos .. "  ·  Tom " .. st.tom
    elseif (st.semi or 0) ~= 0 then pos = pos .. "  ·  " .. (st.semi > 0 and "+" or "") .. st.semi .. " tom" end
    gfx.x, gfx.y = W - 40 * u - gfx.measurestr(pos), 34 * u
    gfx.drawstr(pos)
    -- a parte de agora, enorme, na cor dela
    local partes = type(st.partes) == "table" and st.partes or {}
    local atual = st.pi and partes[st.pi]
    st.cor = atual and atual.c or nil
    st.falta = st.faltam or 0
    st.progresso = st.prog or 0
    st.parte = st.parte or ""
    local parte = st.parte ~= "" and st.parte or "Entre as músicas"
    local tam = 150 * u
    fonte(3, tam, true)
    while gfx.measurestr(parte) > W - 80 * u and tam > 40 do tam = tam - 6; fonte(3, tam, true) end
    cor(st.cor or "#DCE8F2")
    local _, th = gfx.measurestr(parte)
    centro(parte, 0, H * 0.42 - th / 2, W)
    -- barra da parte e quanto falta
    local by = H * 0.62
    cor("#123650"); gfx.rect(40 * u, by, W - 80 * u, 14 * u, 1)
    cor(st.cor or "#08A9F5"); gfx.rect(40 * u, by, math.max(4, (W - 80 * u) * (st.progresso or 0)), 14 * u, 1)
    fonte(2, 26 * u, false); cor("#DCE8F2")
    if st.parte ~= "" then centro("faltam " .. tempo(st.falta), 0, by + 24 * u, W) end
    -- próxima (amarela quando está na fila) e repetir
    fonte(4, 46 * u, true)
    local prox, hex
    local naFila = st.fila and partes[st.fila] and partes[st.fila].n
    local seguinte = st.pi and partes[st.pi + 1] and partes[st.pi + 1].n
    if st.suave then prox, hex = "Parando…", "#FFB547"
    elseif st.repetir then prox, hex = "↻ Repetindo esta parte", "#08A9F5"
    elseif naFila then prox, hex = "Próxima: " .. naFila, "#FFB547"
    elseif st.final then prox, hex = "Indo para o Final", "#FFB547"
    elseif seguinte then prox, hex = "Depois: " .. seguinte, "#8FA9BF"
    elseif (st.depois or "") ~= "" then prox, hex = "Próxima música: " .. st.depois, "#8FA9BF" end
    if prox then cor(hex); centro(cortar(prox, W - 80 * u), 0, H - 100 * u, W) end
  end
  local function laco()
    local ch = gfx.getchar()
    if ch < 0 then
      reaper.SetExtState("LouvorStudio", "ministro_dock", tostring(gfx.dock(-1)), true)
      return
    end
    quadro()
    gfx.update()
    reaper.defer(laco)
  end
  laco()
end

return M
