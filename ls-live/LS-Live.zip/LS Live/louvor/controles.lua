-- Louvor Studio para o REAPER — teclado e controladores MIDI no modo ao vivo.
--  * Teclado: 1…9 e 0 = quadradinhos 1…10; espaço = tocar/parar; R = repetir; ← → = parte anterior/próxima;
--    ↑ ↓ = música anterior/próxima; Home = começo da parte; E = final; S = parar suave; P = pad.
--  * MIDI: "aprender" liga qualquer pad, tecla ou botão (nota ou CC) a um comando. Fica guardado neste computador.
--    O controlador precisa estar ligado como entrada em Opções › Preferências › Áudio › Dispositivos MIDI.
local json = require("louvor.json")
local M = {}

local EXT = "LouvorStudio"

M.PADRAO = {
  [49] = "p1", [50] = "p2", [51] = "p3", [52] = "p4", [53] = "p5", [54] = "p6", [55] = "p7", [56] = "p8", [57] = "p9", [48] = "p10",
  [32] = "tocar", [114] = "repetir", [82] = "repetir",
  [1818584692] = "parte-", [1919379572] = "parte+", [30064] = "musica-", [1685026670] = "musica+", [1752132965] = "inicio",
  [101] = "final", [69] = "final", [115] = "suave", [83] = "suave", [112] = "pad", [80] = "pad",
  [109] = "marcar", [77] = "marcar",
}
-- Teclas que entraram depois (LS Live 1.1): somadas às teclas guardadas de quem já usava, se estiverem livres.
local NOVAS = { [101] = "final", [69] = "final", [115] = "suave", [83] = "suave", [112] = "pad", [80] = "pad",
  [109] = "marcar", [77] = "marcar" }
-- Teclas em uso (o padrão + o que a pessoa ligou com o botão direito). Fica guardado neste computador.
M.TECLAS = {}

local ESPECIAIS = { [32] = "Espaço", [13] = "Enter", [9] = "Tab", [8] = "Backspace", [27] = "Esc",
  [1818584692] = "←", [1919379572] = "→", [30064] = "↑", [1685026670] = "↓", [1752132965] = "Home", [6647396] = "End",
  [1885828464] = "PgUp", [1885824110] = "PgDn", [6909555] = "Ins", [6579564] = "Del" }
for i = 1, 9 do ESPECIAIS[26160 + i] = "F" .. i end
for i = 0, 2 do ESPECIAIS[6697264 + i] = "F1" .. i end

--- Nome curto da tecla (para mostrar no quadradinho).
function M.nomeTecla(ch)
  if ESPECIAIS[ch] then return ESPECIAIS[ch] end
  if ch >= 1 and ch <= 26 then return "Ctrl+" .. string.char(64 + ch) end
  if ch > 32 and ch < 127 then return string.char(ch):upper() end
  return "tecla " .. ch
end

--- Nome curto do botão do controlador ("nota:1:36" → "Pad 36", "cc:1:20" → "CC 20").
function M.nomeMidi(chave)
  local tipo, canal, num = chave:match("^(%a+):(%d+):(%d+)$")
  if not tipo then return chave end
  return (tipo == "nota" and "Pad " or "CC ") .. num .. (canal ~= "1" and (" (c" .. canal .. ")") or "")
end

M.NOMES = { marcar = "Marcar parte aqui", tocar = "Tocar / parar", repetir = "Repetir a parte", ["parte-"] = "Parte anterior", ["parte+"] = "Próxima parte",
  ["musica-"] = "Música anterior", ["musica+"] = "Próxima música", inicio = "Começo da parte", final = "Final",
  suave = "Parar suave", pad = "Pad entre as músicas", ["tom+"] = "Subir meio tom", ["tom-"] = "Descer meio tom",
  ["bpm+"] = "Mais rápido", ["bpm-"] = "Mais devagar", tomdia = "Ir para o tom do dia", ordem = "Seguir a ordem das partes" }
function M.nome(cmd)
  local n = cmd:match("^p(%d+)$")
  if n then return "Quadradinho " .. n end
  local nome = cmd:match("^n:(.+)$")
  if nome then return "a parte \"" .. nome .. "\" (em todas as músicas)" end
  return M.NOMES[cmd] or cmd
end

M.mapa = {}       -- "nota:canal:numero" → comando
M.aprendendo = nil -- comando esperando o botão do controlador
M.ultimo = nil    -- último botão recebido (para mostrar na tela)
local ultimaSeq = nil

local function padrao() local t = {} for k, v in pairs(M.PADRAO) do t[k] = v end return t end

function M.carregar()
  local s = reaper.GetExtState(EXT, "midi")
  local t = s ~= "" and json.decode(s) or nil
  M.mapa = type(t) == "table" and t or {}
  -- teclas: guardadas como { "49": "p1", ... } (chave texto por causa do JSON)
  s = reaper.GetExtState(EXT, "teclas")
  t = s ~= "" and json.decode(s) or nil
  if type(t) == "table" then
    M.TECLAS = {}
    for k, v in pairs(t) do if tonumber(k) and type(v) == "string" then M.TECLAS[tonumber(k)] = v end end
    if reaper.GetExtState(EXT, "teclas_v2") ~= "1" then
      for k, v in pairs(NOVAS) do if not M.TECLAS[k] then M.TECLAS[k] = v end end
      reaper.SetExtState(EXT, "teclas_v2", "1", true)
      local u = {}
      for k, v in pairs(M.TECLAS) do u[tostring(k)] = v end
      reaper.SetExtState(EXT, "teclas", json.encode(json.object(u)), true)
    end
  else
    M.TECLAS = padrao()
  end
end

local function salvar() reaper.SetExtState(EXT, "midi", json.encode(json.object(M.mapa)), true) end
local function salvarTeclas()
  local t = {}
  for k, v in pairs(M.TECLAS) do t[tostring(k)] = v end
  reaper.SetExtState(EXT, "teclas", json.encode(json.object(t)), true)
end

function M.limpar() M.mapa = {}; salvar() end

--- Liga a tecla a um comando (a tecla deixa de fazer o que fazia antes).
function M.ligarTecla(ch, cmd)
  M.TECLAS[ch] = cmd
  salvarTeclas()
end

--- Tira todas as teclas e botões do controlador ligados a este comando.
function M.tirar(cmd)
  for k, c in pairs(M.TECLAS) do if c == cmd then M.TECLAS[k] = nil end end
  for k, c in pairs(M.mapa) do if c == cmd then M.mapa[k] = nil end end
  salvarTeclas(); salvar()
end

--- Teclas do computador de volta ao padrão (os botões do controlador continuam).
function M.teclasPadrao() M.TECLAS = padrao(); salvarTeclas() end

function M.qualTecla(cmd)
  local out = {}
  for k, c in pairs(M.mapa) do if c == cmd then out[#out + 1] = k end end
  table.sort(out)
  return out
end

--- Teclas do computador ligadas ao comando (ordenadas, as mais simples primeiro).
function M.teclasDe(cmd)
  local out = {}
  for k, c in pairs(M.TECLAS) do if c == cmd then out[#out + 1] = k end end
  table.sort(out)
  return out
end

--- Rótulo curto com o que aciona o comando: "1 · Pad 36". Vazio se nada.
function M.rotulo(cmd, max)
  local partes = {}
  for _, k in ipairs(M.teclasDe(cmd)) do
    local n = M.nomeTecla(k)
    local repetido = false
    for _, p in ipairs(partes) do if p == n then repetido = true end end
    if not repetido then partes[#partes + 1] = n end
  end
  for _, k in ipairs(M.qualTecla(cmd)) do partes[#partes + 1] = M.nomeMidi(k) end
  max = max or 2
  while #partes > max do table.remove(partes) end
  return table.concat(partes, " · ")
end

--- Lê os eventos MIDI novos. Devolve a lista de comandos a executar (na ordem em que chegaram).
function M.lerMidi()
  if not reaper.MIDI_GetRecentInputEvent then return {} end
  local novos = {}
  local idx = 0
  local topo = nil
  while true do
    local seq, buf, _, dev = reaper.MIDI_GetRecentInputEvent(idx)
    if not seq or seq == 0 then break end
    topo = topo or seq
    if ultimaSeq == nil or seq == ultimaSeq then break end
    novos[#novos + 1] = { buf = buf, dev = dev }
    idx = idx + 1
    if idx > 64 then break end
  end
  if ultimaSeq == nil then ultimaSeq = topo or 0; return {} end   -- ao abrir, ignora o que já estava no histórico
  if topo then ultimaSeq = topo end
  local cmds = {}
  for i = #novos, 1, -1 do
    local b = novos[i].buf
    if b and #b >= 3 then
      local st, d1, d2 = b:byte(1), b:byte(2), b:byte(3)
      local tipo, canal = st & 0xF0, (st & 0x0F) + 1
      local chave
      if tipo == 0x90 and d2 > 0 then chave = "nota:" .. canal .. ":" .. d1
      elseif tipo == 0xB0 and d2 > 0 then chave = "cc:" .. canal .. ":" .. d1 end
      if chave then
        local dev = novos[i].dev or 0
        local _, nome = reaper.GetMIDIInputName(dev & 0xFFFF, "")
        M.ultimo = { chave = chave, aparelho = nome ~= "" and nome or "controlador" }
        -- lembra o controlador (para acender as luzes dos pads: louvor/luzes.lua)
        if nome ~= "" and nome ~= reaper.GetExtState(EXT, "midi_aparelho") then reaper.SetExtState(EXT, "midi_aparelho", nome, true) end
        if M.aprendendo then
          for k, c in pairs(M.mapa) do if k == chave then M.mapa[k] = nil end end
          M.mapa[chave] = M.aprendendo
          M.ligou = { texto = M.nomeMidi(chave) .. " → " .. M.nome(M.aprendendo), ate = reaper.time_precise() + 4 }
          M.aprendendo = nil
          salvar()
        elseif M.mapa[chave] then
          cmds[#cmds + 1] = M.mapa[chave]
        end
      end
    end
  end
  return cmds
end

return M
