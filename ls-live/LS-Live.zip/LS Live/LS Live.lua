-- Louvor Studio para o REAPER: baixa a escala da banda e monta no projeto, com o modo ao vivo.
-- Instalação: Actions › Show action list › New action › Load ReaScript… e escolha este arquivo.
-- A pasta "louvor" (e a pasta "icones") precisam ficar ao lado deste arquivo.
local _, info, _, cmd = reaper.get_action_context()
local pasta = info:match("^(.*[/\\])") or ""
package.path = pasta .. "?.lua;" .. package.path
local instalar = require("louvor.instalar")
instalar.cmd, instalar.pastaScript = cmd, pasta
require("louvor.tela").abrir()
