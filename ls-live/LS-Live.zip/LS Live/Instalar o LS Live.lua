-- LS Live (Louvor Studio Live) — instalador.
-- No REAPER: Actions › Show action list › New action › Load ReaScript… › escolha ESTE arquivo › Run.
-- Ele copia o LS Live para a pasta de scripts do REAPER, cria a ação "LS Live", põe o botão com o ícone
-- numa barrinha e abre a janela. Pode rodar de novo para atualizar (os arquivos são trocados pelos novos).
local SEP = package.config:sub(1, 1)
local aqui = (({ reaper.get_action_context() })[2]):match("^(.*[/\\])") or ""

local function ler(p) local f = io.open(p, "rb") if not f then return nil end local s = f:read("*a") f:close() return s end
local function escrever(p, s) local f = io.open(p, "wb") if not f then return false end f:write(s) f:close() return true end

local destino = reaper.GetResourcePath() .. SEP .. "Scripts" .. SEP .. "LS Live" .. SEP
reaper.RecursiveCreateDirectory(destino .. "louvor", 0)
reaper.RecursiveCreateDirectory(destino .. "icones", 0)

local ARQUIVOS = {
  "LS Live.lua",
  "louvor/aovivo.lua", "louvor/controles.lua", "louvor/grade.lua", "louvor/http.lua", "louvor/instalar.lua",
  "louvor/json.lua", "louvor/montar.lua", "louvor/nuvem.lua", "louvor/partes.lua", "louvor/saidas.lua", "louvor/tela.lua",
  "icones/louvor_studio.png", "icones/louvor_studio_150.png", "icones/louvor_studio_200.png",
}
local faltou = {}
for _, rel in ipairs(ARQUIVOS) do
  local de = aqui .. rel:gsub("/", SEP)
  local s = ler(de)
  if not s or not escrever(destino .. rel:gsub("/", SEP), s) then faltou[#faltou + 1] = rel end
end
if #faltou > 0 then
  reaper.ShowMessageBox("Não deu para copiar: " .. table.concat(faltou, ", ") ..
    "\n\nDescompacte o arquivo .zip inteiro antes e rode o instalador de dentro da pasta \"LS Live\".", "LS Live", 0)
  return
end

-- cria (ou atualiza) a ação "LS Live" e guarda o número dela
local cmd = reaper.AddRemoveReaScript(true, 0, destino .. "LS Live.lua", true)
if not cmd or cmd == 0 then
  reaper.ShowMessageBox("Os arquivos foram copiados, mas o REAPER não criou a ação. Abra Actions › Load ReaScript e escolha:\n" ..
    destino .. "LS Live.lua", "LS Live", 0)
  return
end

-- botão com o ícone numa barrinha própria (a barra principal do REAPER não é mexida)
package.path = destino .. "?.lua;" .. package.path
local okI, instalar = pcall(require, "louvor.instalar")
local avisoBotao = ""
if okI then
  instalar.cmd, instalar.pastaScript = cmd, destino
  local ok, e = instalar.instalarBotao()
  if not ok and e then avisoBotao = "\n\nSobre o botão: " .. e end
end

reaper.ShowMessageBox("O LS Live foi instalado!\n\n" ..
  "• Para abrir: o botão com o ícone do LS Live na barrinha, ou Actions › LS Live.\n" ..
  "• Entre com a mesma conta do Louvor Studio (e-mail e senha).\n" ..
  "• Dica: nas Configurações (botão ⋯) dá para abrir o LS Live junto com o REAPER." .. avisoBotao, "LS Live", 0)
reaper.Main_OnCommand(cmd, 0)
