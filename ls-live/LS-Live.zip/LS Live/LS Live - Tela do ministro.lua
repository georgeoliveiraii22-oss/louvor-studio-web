-- LS Live — tela grande do ministro (para um segundo monitor ou TV). Mostra o que o LS Live está tocando.
-- A pasta "louvor" precisa ficar ao lado deste arquivo (o instalador já põe).
local info = ({ reaper.get_action_context() })[2]
local pasta = info:match("^(.*[/\\])") or ""
package.path = pasta .. "?.lua;" .. package.path
require("louvor.ministro").abrir()
